package ar.edu.unlam.p;

public enum TipoDeMascota {

	exotica,
	domestica
}
