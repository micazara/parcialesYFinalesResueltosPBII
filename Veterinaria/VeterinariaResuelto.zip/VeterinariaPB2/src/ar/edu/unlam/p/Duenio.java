package ar.edu.unlam.p;

import java.awt.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class Duenio implements Comparable<Duenio> {

	private Integer dni;
	private String nombre;
	private Set<Mascota> mascotas;

	public Duenio(Integer dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
		this.mascotas = new TreeSet<>();
	}

	Integer getDni() {
		return dni;
	}

	void setDni(Integer dni) {
		this.dni = dni;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Set<Mascota> getMascotas() {
		return mascotas;
	}

	void setMascotas(Set<Mascota> mascotas) {
		this.mascotas = mascotas;
	}

	@Override
	public int compareTo(Duenio o) {
		return this.getDni().compareTo(o.getDni());
	}

	public void agregarMascota(Mascota nueva) throws MascotaDuplicadaException {
		if (!this.mascotas.add(nueva)) {
			throw new MascotaDuplicadaException("La mascota ya existe");
		}
	}

	public Integer obtenerCantidadDeMascotasAgregadas() {
		return this.mascotas.size();
	}

	public Mascota buscarMascota(Integer id) throws ElDuenioNoPoseeLaMascota {
		for (Mascota actual : this.mascotas) {
			if (actual.getId().equals(id)) {
				return actual;
			}
		}
		throw new ElDuenioNoPoseeLaMascota();
	}

	public TreeSet<Mascota> obtenerDeUnDuenioUnaListaDeMascotasDomesticasOrdenadasPorApodo() {
		TreeSet<Mascota> mascotasDomesticasOrdenadasPorApodo = new TreeSet<Mascota>(new MascotasOrdenadasPorApodo());
		for (Mascota actual : this.mascotas) {
			if (actual.getTipo().equals(TipoDeMascota.domestica)) {
				mascotasDomesticasOrdenadasPorApodo.add(actual);
			}
		}
		return mascotasDomesticasOrdenadasPorApodo;
	}

}
