package ar.edu.unlam.p;

public class MascotaDuplicadaException extends Exception {

	public MascotaDuplicadaException(String msg) {
		super(msg);
	}
}
