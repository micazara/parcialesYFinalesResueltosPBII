package ar.edu.unlam.p;

public class AtencionInexistente extends Exception {

}
