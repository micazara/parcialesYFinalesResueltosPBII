package ar.edu.unlam.p;

import java.util.ArrayList;
import java.util.List;

public class Atencion {

	private Duenio duenio;
	private Mascota mascota;
	private Double precio;
	private Integer id;
	private List<Medicamento> medicamentos;

	public Atencion(Integer id, Duenio duenio, Mascota mascota, Double precio) {
		this.duenio = duenio;
		this.mascota = mascota;
		this.precio = precio;
		this.id = id;
		this.medicamentos = new ArrayList<>();
	}

	Duenio getDuenio() {
		return duenio;
	}

	void setDuenio(Duenio duenio) {
		this.duenio = duenio;
	}

	Mascota getMascota() {
		return mascota;
	}

	void setMascota(Mascota mascota) {
		this.mascota = mascota;
	}

	Double getPrecio() {
		return precio;
	}

	void setPrecio(Double precio) {
		this.precio = precio;
	}

	Integer getId() {
		return id;
	}

	void setId(Integer id) {
		this.id = id;
	}

	List<Medicamento> getMedicamentos() {
		return medicamentos;
	}

	void setMedicamentos(List<Medicamento> medicamentos) {
		this.medicamentos = medicamentos;
	}

	public void asignarMedicamentos(Medicamento nuevo) {
		this.medicamentos.add(nuevo);
	}

	public Integer obtenerCantidadDeMedicamentos() {
		return this.medicamentos.size();
	}

	public Double calcularPrecioTotalDeUnaAtencion() {
		Double precioAtencion = this.getPrecio();
		Double precioTotalMedicamentos = 0d;

		for (Medicamento actual : medicamentos) {
			precioTotalMedicamentos += actual.getPrecio();
		}

		Double precioTotalAtencion = precioAtencion + precioTotalMedicamentos;

		return precioTotalAtencion;
	}

	@Override
	public String toString() {
		return "Atencion [duenio=" + duenio + ", mascota=" + mascota + ", precio=" + precio + ", id=" + id
				+ ", medicamentos=" + medicamentos + "]";
	}

}
