package ar.edu.unlam.p;

public class Mascota implements Comparable<Mascota> {

	private String nombre;
	private String apodo;
	private TipoDeMascota tipo;
	private Integer id;

	public Mascota(Integer id, String nombre, String apodo, TipoDeMascota tipo) {
		this.id = id;
		this.nombre = nombre;
		this.apodo = apodo;
		this.tipo = tipo;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	String getApodo() {
		return apodo;
	}

	void setApodo(String apodo) {
		this.apodo = apodo;
	}

	TipoDeMascota getTipo() {
		return tipo;
	}

	void setTipo(TipoDeMascota tipo) {
		this.tipo = tipo;
	}

	Integer getId() {
		return id;
	}

	void setId(Integer id) {
		this.id = id;
	}

	@Override
	public int compareTo(Mascota o) {
		return this.getId().compareTo(o.getId());
	}

}
