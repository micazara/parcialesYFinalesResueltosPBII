package ar.edu.unlam.p;

public class MascotaNoEncontradaException extends Exception {

	public MascotaNoEncontradaException(String msg) {
		super(msg);
	}
}
