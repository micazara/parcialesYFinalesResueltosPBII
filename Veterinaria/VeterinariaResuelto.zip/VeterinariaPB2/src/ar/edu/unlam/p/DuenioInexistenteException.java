package ar.edu.unlam.p;

public class DuenioInexistenteException extends Exception {

	public DuenioInexistenteException(String msg) {
		super(msg);
	}

}
