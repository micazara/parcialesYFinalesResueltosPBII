package ar.edu.unlam.p;

public class Medicamento {

	private Integer id;
	private String descripcion;
	private Double precio;

	public Medicamento(Integer id, String descripcion, Double precio) {
		this.id = id;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public Double getPrecio() {
		return precio;
	}

	Integer getId() {
		return id;
	}

	void setId(Integer id) {
		this.id = id;
	}

	String getDescripcion() {
		return descripcion;
	}

	void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	void setPrecio(Double precio) {
		this.precio = precio;
	}

}
