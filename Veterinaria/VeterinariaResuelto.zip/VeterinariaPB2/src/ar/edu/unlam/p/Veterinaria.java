package ar.edu.unlam.p;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Veterinaria {

	private String nombre;
	private Set<Duenio> duenios;
	private Set<Mascota> mascotas;
	private Map<Integer, Integer> atencionRealizada;
	private List<Atencion> atenciones;

	public Veterinaria(String nombre) {
		this.nombre = nombre;
		this.duenios = new TreeSet<>();
		this.atenciones = new ArrayList<>();
		this.mascotas = new TreeSet<>();
		this.atencionRealizada = new HashMap<>();
	}

	public void agregarDuenio(Duenio nuevo) {
		if (siElDuenioPoseeUnaMascota(nuevo)) {
			this.duenios.add(nuevo);
		}

	}

	private boolean siElDuenioPoseeUnaMascota(Duenio nuevo) {
		return !nuevo.getMascotas().isEmpty();
	}

	public void agregarMascota(Mascota mascota) {
		this.mascotas.add(mascota);
	}

	public Integer cantidadDeDuenios() {
		return this.duenios.size();
	}

	public Mascota buscarMascota(Integer id) throws MascotaNoEncontradaException {
		for (Mascota actual : this.mascotas) {
			if (actual.getId().equals(id)) {
				return actual;
			}
		}

		throw new MascotaNoEncontradaException("Mascota no encontrada");

	}

	public Duenio buscarDuenio(Integer dni) throws DuenioInexistenteException {
		for (Duenio actual : this.duenios) {
			if (actual.getDni().equals(dni)) {
				return actual;
			}
		}
		throw new DuenioInexistenteException("Dueno inexistente");
	}

	public void registroDeAtenciones(Integer idAtencion, Integer dniDuenio, Integer idMascota, Double precio)
			throws MascotaNoEncontradaException, DuenioInexistenteException {
		Duenio buscado = buscarDuenio(dniDuenio);
		Mascota buscada = buscarMascota(idMascota);
		this.atenciones.add(new Atencion(idAtencion, buscado, buscada, precio));

	}

	public Integer cantidadDeRegistrosDeAtencion() {
		return this.atenciones.size();
	}

	public Map<Integer, Integer> realizarAtencion(Integer idAtencion, Integer idMascota) {

		this.atencionRealizada.put(idAtencion, idMascota);
		return this.getAtencionRealizada();

	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Set<Duenio> getDuenios() {
		return duenios;
	}

	void setDuenios(Set<Duenio> duenios) {
		this.duenios = duenios;
	}

	Set<Mascota> getMascotas() {
		return mascotas;
	}

	void setMascotas(Set<Mascota> mascotas) {
		this.mascotas = mascotas;
	}

	Map<Integer, Integer> getAtencionRealizada() {
		return atencionRealizada;
	}

	void setAtencionRealizada(Map<Integer, Integer> atencionRealizada) {
		this.atencionRealizada = atencionRealizada;
	}

	List<Atencion> getAtenciones() {
		return atenciones;
	}

	void setAtenciones(List<Atencion> atenciones) {
		this.atenciones = atenciones;
	}

	public Atencion buscarAtencion(Integer idAtencion) throws AtencionInexistente {
		for (Atencion actual : this.atenciones) {
			if (actual.getId().equals(idAtencion)) {
				return actual;
			}
		}

		throw new AtencionInexistente();

	}



}
