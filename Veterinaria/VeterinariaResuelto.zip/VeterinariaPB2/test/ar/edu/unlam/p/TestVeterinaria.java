package ar.edu.unlam.p;

import static org.junit.Assert.*;

import java.util.Map;
import java.util.TreeSet;

import org.junit.Test;

public class TestVeterinaria {

	@Test
	public void queSePuedaAgregarDosMascotasAUnDuenio() throws MascotaDuplicadaException {

		// NECESTIO DOS MASCOTAS
		Mascota perra = new Mascota(1, "Bianca", "Bianca", TipoDeMascota.domestica);
		Mascota gata = new Mascota(2, "Gala", "Galaaaaa", TipoDeMascota.domestica);

		// UN DUEÑO
		Duenio mica = new Duenio(44892966, "Mica");

		mica.agregarMascota(perra);
		mica.agregarMascota(gata);

		Integer cantidadDeMascotasActual = mica.obtenerCantidadDeMascotasAgregadas();
		Integer cantidadDeMascotasEsperadas = 2;

		assertEquals(cantidadDeMascotasEsperadas, cantidadDeMascotasActual);
	}

	@Test(expected = MascotaDuplicadaException.class)
	public void queAlAgregarDosMascotasConMismoIdParaUnMismoDuenioLanceUnaExcepcionMascotaDuplicadaException()
			throws MascotaDuplicadaException {
		Mascota perra = new Mascota(1, "Bianca", "Bianca", TipoDeMascota.domestica);
		Mascota gata = new Mascota(1, "Gala", "Galaaaaa", TipoDeMascota.domestica);

		// UN DUEÑO
		Duenio mica = new Duenio(44892966, "Mica");

		mica.agregarMascota(perra);
		mica.agregarMascota(gata);
	}

	@Test
	public void queSePuedaCrearUnMedicamentoConIdDescripcionYPrecio() {
		Medicamento pastillas = new Medicamento(1, "Pastillas para la tos animal", 2500d);

		String descripcionActual = pastillas.getDescripcion();
		String descripcionEsperada = "Pastillas para la tos animal";
		Integer idActual = pastillas.getId();
		Integer idEsperado = 1;

		assertEquals(descripcionEsperada, descripcionActual);
		assertEquals(idEsperado, idActual);
		assertNotNull(pastillas);
	}

	@Test
	public void queSePuedanAgregarDueniosDeMascotasAUnaVeterinaria()
			throws MascotaDuplicadaException, ElDuenioNoPoseeLaMascota {
		Mascota perra = new Mascota(1, "Bianca", "Bianca", TipoDeMascota.domestica);

		Duenio mica = new Duenio(44892966, "Mica");

		mica.agregarMascota(perra);

		Mascota gata = new Mascota(2, "Gala", "Galaaaaa", TipoDeMascota.domestica);

		Duenio seba = new Duenio(1346545, "Seba");

		seba.agregarMascota(gata);

		Veterinaria vete = new Veterinaria("La mejor del oeste");

		vete.agregarDuenio(mica);
		vete.agregarDuenio(seba);

		Integer cantidadEsperadaDeDuenios = 2;
		Integer cantidadActualDeDuenios = vete.cantidadDeDuenios();

		assertEquals(cantidadEsperadaDeDuenios, cantidadActualDeDuenios);
		assertTrue(vete.getDuenios().contains(mica));
		assertTrue(vete.getDuenios().contains(seba));
	}

	@Test
	public void queSePuedaCrearUnaAtencionConDuenioYMascotaYPrecio()
			throws Exception {
// una atencion tiene duenio, mascota, precio, id, medicamentos
		// para poder crear una atencion necesitamos un duenio y una masvota q estan
		// regustrados en la vete

		Mascota perra = new Mascota(1, "Bianca", "Bianca", TipoDeMascota.domestica);

		Duenio mica = new Duenio(44892966, "Mica");

		mica.agregarMascota(perra);

		Veterinaria vete = new Veterinaria("La mejor del oeste");

		vete.agregarDuenio(mica);

		vete.agregarMascota(perra);

		vete.registroDeAtenciones(1, 44892966, 1, 2000d);

		Integer cantidadActualDeAtenciones = vete.cantidadDeRegistrosDeAtencion();
		Integer cantidadEsperadaDeAtenciones = 1;

		assertEquals(cantidadEsperadaDeAtenciones, cantidadActualDeAtenciones);
		assertEquals(mica, vete.getAtenciones().get(0).getDuenio());
		assertEquals(perra, vete.getAtenciones().get(0).getMascota());

	}

	@Test
	public void queSePuedaAsignarVariosMedicamentosAUnaAtencion() throws MascotaNoEncontradaException,
			DuenioInexistenteException, MascotaDuplicadaException, AtencionInexistente {

		Mascota perra = new Mascota(1, "Bianca", "Bianca", TipoDeMascota.domestica);

		Duenio mica = new Duenio(44892966, "Mica");

		mica.agregarMascota(perra);

		Veterinaria vete = new Veterinaria("La mejor del oeste");

		vete.agregarDuenio(mica);

		vete.agregarMascota(perra);

		vete.registroDeAtenciones(1, 44892966, 1, 2000d);

		Atencion buscada = vete.buscarAtencion(1);

		Medicamento pastillas = new Medicamento(1, "Pastillas para la tos animal", 2500d);
		Medicamento crema = new Medicamento(2, "Crema para perritos", 500d);

		buscada.asignarMedicamentos(pastillas);
		buscada.asignarMedicamentos(crema);

		Integer cantidadActualDeMedicamentos = buscada.obtenerCantidadDeMedicamentos();
		Integer cantidadEsperadaDeMedicamentos = 2;

		assertTrue(buscada.getMedicamentos().contains(pastillas));
		assertTrue(buscada.getMedicamentos().contains(crema));
		assertEquals(cantidadEsperadaDeMedicamentos, cantidadActualDeMedicamentos);

	}

	@Test
	public void queSePuedaCalcularElPrecioTotalDeUnaAtencion() throws MascotaNoEncontradaException,
			DuenioInexistenteException, AtencionInexistente, MascotaDuplicadaException {
		// El precio total de la atencion será la suma del precio de la
		// atencion mas la suma del precio de todos los medicamentos

		Mascota perra = new Mascota(1, "Bianca", "Bianca", TipoDeMascota.domestica);

		Duenio mica = new Duenio(44892966, "Mica");

		mica.agregarMascota(perra);

		Veterinaria vete = new Veterinaria("La mejor del oeste");

		vete.agregarDuenio(mica);

		vete.agregarMascota(perra);

		vete.registroDeAtenciones(1, 44892966, 1, 2000d);

		Atencion buscada = vete.buscarAtencion(1);

		Medicamento pastillas = new Medicamento(1, "Pastillas para la tos animal", 2500d);
		Medicamento crema = new Medicamento(2, "Crema para perritos", 500d);

		buscada.asignarMedicamentos(pastillas);
		buscada.asignarMedicamentos(crema);

		Double precioObtenido = buscada.calcularPrecioTotalDeUnaAtencion();

		Double precioEsperado = 5000d;

		assertEquals(precioEsperado, precioObtenido);

	}

	@Test
	public void queSePuedaObtenerDeUnDuenioUnaListaDeMascotasDomesticasOrdenadasPorApodo()
			throws MascotaDuplicadaException {
		Mascota perra = new Mascota(1, "Bianca", "Z", TipoDeMascota.domestica);
		Mascota gata = new Mascota(2, "Gala", "Galaaaaa", TipoDeMascota.domestica);
		Mascota loro = new Mascota(3, "Arturo", "Arti", TipoDeMascota.exotica);

		// UN DUEÑO
		Duenio mica = new Duenio(44892966, "Mica");

		mica.agregarMascota(perra);
		mica.agregarMascota(gata);
		mica.agregarMascota(loro);

		TreeSet<Mascota> mascotasOrdenadasPorApodo = mica
				.obtenerDeUnDuenioUnaListaDeMascotasDomesticasOrdenadasPorApodo();
		Mascota primerMascota = mascotasOrdenadasPorApodo.first();
		Mascota ultimaMascota = mascotasOrdenadasPorApodo.last();

		Integer cantidadDeMascotasOrdenadasPorApodoActual = mascotasOrdenadasPorApodo.size();
		Integer cantidadEsperadaDeMascotasOrdenadasPorApodo = (Integer) 2;

		assertEquals(primerMascota, gata);
		assertEquals(ultimaMascota, perra);
		assertFalse(mascotasOrdenadasPorApodo.contains(loro));
		assertEquals(cantidadEsperadaDeMascotasOrdenadasPorApodo, cantidadDeMascotasOrdenadasPorApodoActual);
	}

	@Test
	public void queSePuedaObtenerUnMapaConIdDeAtencionYIdDeMascota() throws Exception {

		Mascota perra = new Mascota(1, "Bianca", "Bianca", TipoDeMascota.domestica);

		Duenio mica = new Duenio(44892966, "Mica");

		mica.agregarMascota(perra);

		Veterinaria vete = new Veterinaria("La mejor del oeste");

		vete.agregarDuenio(mica);

		vete.agregarMascota(perra);

		vete.registroDeAtenciones(1, 44892966, 1, 2000d);

		Atencion buscada = vete.buscarAtencion(1);

		Medicamento pastillas = new Medicamento(1, "Pastillas para la tos animal", 2500d);
		Medicamento crema = new Medicamento(2, "Crema para perritos", 500d);

		buscada.asignarMedicamentos(pastillas);
		buscada.asignarMedicamentos(crema);

		Mascota mascotaBuscada = vete.buscarMascota(1);

		Map<Integer, Integer> atencionRealizada = vete.realizarAtencion(buscada.getId(), mascotaBuscada.getId());

		assertTrue(atencionRealizada.containsKey(buscada.getId()));
		assertTrue(atencionRealizada.containsValue(mascotaBuscada.getId()));

	}

}
