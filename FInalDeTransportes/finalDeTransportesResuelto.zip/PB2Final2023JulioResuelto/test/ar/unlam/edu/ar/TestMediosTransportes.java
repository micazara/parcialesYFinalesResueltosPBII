package ar.unlam.edu.ar;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestMediosTransportes {

	@Test
	public void queSepuedaCrearMedioTransportePasajero() {

		String patente = "AB123CD";
		Integer cantidadPasajerosMaximos = 50;
		MedioTransporte pasajero = new TransportePasajero(patente, cantidadPasajerosMaximos);

		final Integer CANTIDAD_ESPERADA_DE_PASAJEROS = 50;

		assertNotNull(pasajero);
		assertEquals(CANTIDAD_ESPERADA_DE_PASAJEROS, ((TransportePasajero) pasajero).obtenerCantidadMaximaDePasajeros());

	}

	@Test
	public void queSepuedaCrearMedioTransporteCarga() {

		Double cargaMaxima = 1000.0;
		String patente = "987RT";
		MedioTransporte transporteCarga = new TransporteCarga(patente, cargaMaxima);

		final Double CARGA_MAXIMA_ESPERADA = 1000.0;

		assertNotNull(transporteCarga);
		assertEquals(CARGA_MAXIMA_ESPERADA, ((TransporteCarga) transporteCarga).getCargaMaxima());
	}

	@Test
	public void queSepuedaCrearTransporteMixto() {

		Integer cantidadPasajerosMaximos = 50;
		Double cargaMaxima = 1000.0;
		String patente = "987RT";
		MedioTransporte transporteCarga = new TransporteMixto(patente, cantidadPasajerosMaximos, cargaMaxima);

		final Integer CANTIDAD_ESPERADA_DE_PASAJEROS = 50;
		final Double CARGA_MAXIMA_ESPERADA = 1000.0;

		assertNotNull(transporteCarga);
		assertEquals(CANTIDAD_ESPERADA_DE_PASAJEROS, ((TransporteMixto) transporteCarga).obtenerCargaMaxima());
		assertEquals(CARGA_MAXIMA_ESPERADA, ((TransporteMixto) transporteCarga).getCargaMaxima());
	}

}
