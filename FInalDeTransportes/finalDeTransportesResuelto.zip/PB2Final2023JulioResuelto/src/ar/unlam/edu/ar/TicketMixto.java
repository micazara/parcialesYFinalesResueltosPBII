package ar.unlam.edu.ar;

public class TicketMixto extends Ticket{

	public TicketMixto(Integer id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

}
