package ar.unlam.edu.ar;

public class TransportePasajero extends MedioTransporte implements ITransportable {

	private Integer cantidadPasajerosMaximos;

	public TransportePasajero(String patente, Integer cantidadPasajerosMaximos) {
		super(patente);
		this.cantidadPasajerosMaximos = cantidadPasajerosMaximos;
	}

	Integer getCantidadPasajerosMaximos() {
		return cantidadPasajerosMaximos;
	}

	void setCantidadPasajerosMaximos(Integer cantidadPasajerosMaximos) {
		this.cantidadPasajerosMaximos = cantidadPasajerosMaximos;
	}

	@Override
	public Integer obtenerCantidadMaximaDePasajeros() {
		// TODO Auto-generated method stub
		return this.cantidadPasajerosMaximos;
	}

	

}
