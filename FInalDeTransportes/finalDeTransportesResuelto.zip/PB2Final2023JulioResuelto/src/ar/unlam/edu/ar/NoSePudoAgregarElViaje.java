package ar.unlam.edu.ar;

public class NoSePudoAgregarElViaje extends Exception {

}
