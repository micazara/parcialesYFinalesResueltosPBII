package ar.unlam.edu.ar;

public class TicketPasajero extends Ticket {

	public TicketPasajero(Integer id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

}
