package ar.unlam.edu.ar;

public class CantidadPasajeroSobrepasadaException extends Exception {

}
