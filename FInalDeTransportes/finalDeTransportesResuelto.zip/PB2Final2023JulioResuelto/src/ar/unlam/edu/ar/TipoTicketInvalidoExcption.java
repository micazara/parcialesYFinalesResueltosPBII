package ar.unlam.edu.ar;

public class TipoTicketInvalidoExcption extends Exception {

}
