package ar.unlam.edu.ar;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Empresa {

	private String nombre;
	private Map<Integer, Viaje> viajes;
	private Integer keyAutoIncrementableDelViaje;
	// Se registran todas las ventas de pasajes de los pasajeros
	private Set<Ticket> tickets;
	private Integer idTicket;

	public Empresa(String nombre) {
		this.nombre = nombre;
		this.keyAutoIncrementableDelViaje = 0;
		this.viajes = new HashMap<Integer, Viaje>();
		this.tickets = new HashSet<Ticket>();
		this.idTicket = 0;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Map<Integer, Viaje> getViajes() {
		return viajes;
	}

	public void setViajes(Map<Integer, Viaje> viajes) {
		this.viajes = viajes;
	}

	/*
	 * Registra Un Nuevo viaje se debe guardar en un mapa donde la Key es un entero
	 * y es autoincremental arrancando de 0
	 */
	public void registrarViaje(Viaje viaje) throws NoSePudoAgregarElViaje {

//		if (!this.viajes.containsKey(this.keyAutoIncrementableDelViaje)) {
			this.keyAutoIncrementableDelViaje++;
			this.viajes.put(keyAutoIncrementableDelViaje, viaje);
//		} else {
//			throw new NoSePudoAgregarElViaje();
//		}

	}

	/*
	 * Registra Un ticket para carga TicketCarga.class Si el viaje no admite Carga
	 * lanza TipoTicketInvalidoExcption si supera El peso maximo que soporta el
	 * medioTransprte Lanza Una exception CapacidadExcedidaException
	 */

	public void registrarTicketcarga(Integer numeroViaje, Carga carga)
			throws ViajeInexistente, TipoTicketInvalidoExcption {

		// buscar el viaje por numero que se haya agregado a los viajes
		Viaje buscado = buscarViajePorNumero(numeroViaje);

		// busco el medio de transporte de carga de ese viaje
		MedioTransporte transporte = buscado.getMedioTransporte();

		// me aseguro que el transporte que obtenga sea cargable
		if (!(transporte instanceof iCargable)) {
			throw new TipoTicketInvalidoExcption();
		}

		// ahora que el peso del viaje no exceda el peso maximo del trasnporte
		if (buscado.getCarga() <= ((TransporteCarga) transporte).obtenerCargaMaxima()) {
			this.idTicket++;
			Ticket nuevo = new TicketCarga(this.idTicket);
			this.tickets.add(nuevo);
		}

	}

	public Integer obtenerCantidadDeTicketsCarga() {
		Integer cantidad = 0;
		for (Ticket actual : this.tickets) {
			if (actual instanceof TicketCarga) {
				cantidad++;
			}
		}

		return cantidad++;
	}

	/*
	 * Se registra un TicketPasajero TicketPasajero Si el viaje no admite pasajeros
	 * lanza TipoTicketInvalidoExcption si supera la cantidad de pasajero que
	 * soporta el medioTransprte Lanza Una exception
	 * CantidadPasajeroSobrepasadaException
	 */

	public void registrarTicketPasajero(Integer numeroViaje, Pasajero pasajero)
			throws ViajeInexistente, TipoTicketInvalidoExcption {
		// para registrar un ticket de pasajero tiene que ser en un viaje que tenga un
		// medio de transporte que sea transportable

		// busco que se haya registrado un viaje con un medio de transporte
		// transportable
		Viaje buscado = buscarViajePorNumero(numeroViaje);

		// a partir del viaje buscado obtengo el medio de transporte
		MedioTransporte transporte = buscado.getMedioTransporte();

		if (!(transporte instanceof ITransportable)) {
			throw new TipoTicketInvalidoExcption();
		}

		if (buscado.getCantidadPasajerosMaximos() <= ((TransportePasajero) transporte)
				.obtenerCantidadMaximaDePasajeros()) {
			this.idTicket++;
			Ticket ticketPasajero = new TicketPasajero(this.idTicket);
			this.tickets.add(ticketPasajero);
		}

	}

	public Integer obtenerCantidadDeTicketsPasajero() {
		Integer cantidad = 0;
		for (Ticket actual : this.tickets) {
			if (actual instanceof TicketPasajero) {
				cantidad++;
			}
		}

		return cantidad;
	}

	private Viaje buscarViajePorNumero(Integer numeroViaje) throws ViajeInexistente {

		if (this.viajes.get(numeroViaje) != null) {
			return this.viajes.get(numeroViaje);
		}
		throw new ViajeInexistente();
	}
	/*
	 * Se registra un TicketMixto TicketMixto.class si supera la cantidad de
	 * pasajero que soporta el medioTransprte Lanza Una exception
	 * CantidadPasajeroSobrepasadaException si supera El peso maximo que soporta el
	 * medioTransprte Lanza Una exception CapacidadExcedidaException
	 */

	public void registrarTicketMixto(Integer numeroViaje, Pasajero pasajero, Carga carga)
			throws ViajeInexistente, CantidadPasajeroSobrepasadaException, CapacidadExcedidaException {

		Viaje buscado = buscarViajePorNumero(numeroViaje);
		MedioTransporte transporte = buscado.getMedioTransporte();

		if (transporte instanceof ITransportable && transporte instanceof iCargable) {

			if (buscado.getCantidadPasajerosMaximos() > ((TransporteMixto) transporte)
					.obtenerCantidadMaximaDePasajeros()) {
				throw new CantidadPasajeroSobrepasadaException();
			}

			if (buscado.getCarga() > ((TransporteMixto) transporte).obtenerCargaMaxima()) {
				throw new CapacidadExcedidaException();
			}

			this.idTicket++;
			Ticket nuevo = new TicketMixto(idTicket);
			this.tickets.add(nuevo);
		}
	}

	public Integer obtenerCantidadDeTicketsMixtos() {
		Integer cantidad = 0;
		for (Ticket actual : this.tickets) {
			if (actual instanceof TicketMixto) {
				cantidad++;
			}
		}

		return cantidad;
	}

	/*
	 * retorna la lista de pasajero enforma Descendiente Lanza una exception si el
	 * viaje no existe o si el tipo de viaje No es compatible para trnssporte de
	 * pasajero lanza una exception si el viaje no existe
	 */

	public TreeSet<Pasajero> obtenerListaPasajeroOrdenadosPorDNIDescendiente(Integer numeroViaje)
			throws ViajeInexistente {

		Pasajero pasajero1 = new Pasajero(1234, "Zara");
		Pasajero pasajero2 = new Pasajero(1111, "Sepulveda");
		Pasajero pasajero3 = new Pasajero(9999, "Java");

		// buscar que el viaje exista
		Viaje buscado = buscarViajePorNumero(numeroViaje);
		buscado.agregarPasajeroAlViaje(pasajero1);
		buscado.agregarPasajeroAlViaje(pasajero2);
		buscado.agregarPasajeroAlViaje(pasajero3);

		TreeSet<Pasajero> pasajerosOrdenadosPorDni = new TreeSet<Pasajero>(new OrdenPorDniDescendente());

		pasajerosOrdenadosPorDni.addAll(buscado.getPasajeros());

//		mostrarPasajerosOrdenados(pasajerosOrdenadosPorDni);

		return pasajerosOrdenadosPorDni;
	}

//	private void mostrarPasajerosOrdenados(TreeSet<Pasajero> pasajerosOrdenadosPorDni) {
//		for (Pasajero actual : pasajerosOrdenadosPorDni) {
//			System.out.println(actual.toString());
//		}
//	}

	public Double obtenerELTotalDeCargaTransportadaEnTodosLosViajes() {
		Double totalCargaTransportada = 0d;

		for (Map.Entry<Integer, Viaje> entry : viajes.entrySet()) {
			Integer key = entry.getKey();
			Viaje val = entry.getValue();

			Double cargaDelViaje = val.getCarga();
			totalCargaTransportada += cargaDelViaje;
		}

//		System.out.println(totalCargaTransportada);
		return totalCargaTransportada;
	}

}
