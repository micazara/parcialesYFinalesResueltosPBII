package ar.unlam.edu.ar;

public class TicketCarga extends Ticket {

	public TicketCarga(Integer id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

}
