package ar.unlam.edu.ar;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

public class Viaje {

	private LocalDateTime salida;
	private LocalDateTime llegada;
	private String origen;
	private String destino;
	private MedioTransporte medioTransporte;
	private Integer cantidadPasajerosMaximos;
	private Double carga;
	private Set<Pasajero> pasajeros;

	public Viaje(LocalDateTime salida, LocalDateTime llegada, String origen, String destino,
			MedioTransporte medioTransporte, Integer cantidadPasajerosMaximos, Double carga) {
		this.salida = salida;
		this.llegada = llegada;
		this.origen = origen;
		this.destino = destino;
		this.medioTransporte = medioTransporte;
		this.cantidadPasajerosMaximos = cantidadPasajerosMaximos;
		this.carga = carga;
		this.pasajeros = new HashSet<Pasajero>();
	}

	LocalDateTime getSalida() {
		return salida;
	}

	void setSalida(LocalDateTime salida) {
		this.salida = salida;
	}

	LocalDateTime getLlegada() {
		return llegada;
	}

	void setLlegada(LocalDateTime llegada) {
		this.llegada = llegada;
	}

	String getOrigen() {
		return origen;
	}

	void setOrigen(String origen) {
		this.origen = origen;
	}

	String getDestino() {
		return destino;
	}

	void setDestino(String destino) {
		this.destino = destino;
	}

	MedioTransporte getMedioTransporte() {
		return medioTransporte;
	}

	void setMedioTransporte(MedioTransporte medioTransporte) {
		this.medioTransporte = medioTransporte;
	}

	Integer getCantidadPasajerosMaximos() {
		return cantidadPasajerosMaximos;
	}

	void setCantidadPasajerosMaximos(Integer cantidadPasajerosMaximos) {
		this.cantidadPasajerosMaximos = cantidadPasajerosMaximos;
	}

	Double getCarga() {
		return carga;
	}

	void setCarga(Double cargaMaxima) {
		this.carga = cargaMaxima;
	}

	public void agregarPasajeroAlViaje(Pasajero pasajero) {

		this.pasajeros.add(pasajero);

	}

	Set<Pasajero> getPasajeros() {
		return pasajeros;
	}

	void setPasajeros(Set<Pasajero> pasajeros) {
		this.pasajeros = pasajeros;
	}

}
