package ar.unlam.edu.ar;

public class ViajeInexistente extends Exception {

}
