package ar.unlam.edu.ar;

public interface iCargable {

	Double obtenerCargaMaxima();
}
