package ar.edu.unlam.pb2;

public class Activador extends Usuario implements Activable {

	public Activador(Integer dni, String nombre) {
		super(dni, nombre);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean activarDesactivarAlarma(Alarma alarma, String codigoActivacionAlarma, Usuario activador)
			throws LosSensoresEstanDesactivados {
		if (alarma.getCodActivacionODesactivacion().equals(codigoActivacionAlarma)) {
			if (alarma.losSensoresEstanActivados()) {
				alarma.activarDesactivar(alarma, activador);
				return true;
			}
		}
		return false;
	}

}
