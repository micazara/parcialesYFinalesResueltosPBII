package ar.edu.unlam.pb2;

public class SensorInexistente extends Exception {

}
