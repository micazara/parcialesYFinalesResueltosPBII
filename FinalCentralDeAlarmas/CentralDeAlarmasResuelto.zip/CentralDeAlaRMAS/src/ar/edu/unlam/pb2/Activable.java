package ar.edu.unlam.pb2;

public interface Activable {
	boolean activarDesactivarAlarma(Alarma alarma, String codigoActivacionAlarma, Usuario activador) throws LosSensoresEstanDesactivados;
}
