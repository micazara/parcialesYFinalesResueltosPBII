package ar.edu.unlam.pb2;

import java.nio.channels.AlreadyBoundException;
import java.util.HashSet;
import java.util.Set;

public class CentralDeAlarmas {

	private Set<Alarma> alarmas;
	private Set<Usuario> usuarios;

	public CentralDeAlarmas() {
		this.alarmas = new HashSet<Alarma>();
		this.usuarios = new HashSet<Usuario>();
	}

	Set<Alarma> getAlarmas() {
		return alarmas;
	}

	void setAlarmas(Set<Alarma> alarmas) {
		this.alarmas = alarmas;
	}

	Set<Usuario> getUsuarios() {
		return usuarios;
	}

	void setUsuarios(Set<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	public boolean agregarAlarma(Alarma alarma) {
		return this.alarmas.add(alarma);
	}

	public boolean agregarUsuario(Usuario usuario) {
		return this.usuarios.add(usuario);
	}

	public Usuario buscarUsuarioPorDNI(Integer dniUsuarioAAgregar) throws UsuarioInexistente {
		for (Usuario actual : this.usuarios) {
			if (actual.getDni().equals(dniUsuarioAAgregar)) {
				return actual;
			}
		}

		throw new UsuarioInexistente();

	}

	public Alarma buscarAlarmaPorIdYCodigoConfiguracion(Integer idAlarma, String codigoConfiguracionAlarma)
			throws AlarmaInexistente {
		for (Alarma actual : this.alarmas) {
			if (actual.getId().equals(idAlarma) && actual.getCodConfiguracion().equals(codigoConfiguracionAlarma)) {
				return actual;
			}
		}

		throw new AlarmaInexistente();
	}

	public Alarma buscarAlarmaPorIdYCodigoDeActivacion(Integer idAlarma, String codigoActivacionAlarma)
			throws AlarmaInexistente {
		for (Alarma actual : this.alarmas) {
			if (actual.getId().equals(idAlarma)
					&& actual.getCodActivacionODesactivacion().equals(codigoActivacionAlarma)) {
				return actual;
			}
		}

		throw new AlarmaInexistente();
	}

	public Usuario buscarUsuarioPorId(Integer dniBuscado) throws UsuarioInexistente {
		for (Usuario actual : this.usuarios) {
			if (actual.getDni().equals(dniBuscado)) {
				return actual;
			}
		}
		throw new UsuarioInexistente();
	}

	public Integer obtenerCantidadDeAlarmas() {
		return this.alarmas.size();
	}

	public Alarma buscarAlarmaPorId(Integer idAlarma) throws AlarmaInexistente {
		for (Alarma actual : this.alarmas) {
			if (actual.getId().equals(idAlarma)) {
				return actual;
			}
		}

		throw new AlarmaInexistente();
	}

	public void queUnConfiguradorAgregueUnUsuarioALaAlarma(Integer dniUserAAgregarALaAlarma, Integer idAlarma,
			String codigoConfig, Integer dniConfiguradorQueAgrega) throws Exception {
		// Buscar un usuario configurador que va a ser el que agregue otro usuario a la
		// alarma
		Usuario configuradorBuscado = buscarUsuarioPorDNI(dniConfiguradorQueAgrega);
		// buscar el usuario que tengo que agregar a la alarma
		Usuario usuarioAAgregarALaAlarmaBuscado = buscarUsuarioPorDNI(dniUserAAgregarALaAlarma);
		// Busca que la alarma que llega por parametro exista
		Alarma buscada = buscarAlarmaPorId(idAlarma);

		// Si el usuario encontrado es configurable entonces agrego el usuario a la
		// alarma
		if (configuradorBuscado instanceof Configurable) {
			((Configurable) configuradorBuscado).agregarUsuarioALaAlarma(usuarioAAgregarALaAlarmaBuscado.getDni(),
					buscada.getId(), codigoConfig);
			buscada.guardarAccionDeConfiguracion(buscada, configuradorBuscado);
		}
	}

	public void queUnConfiguradorAgregueUnSensorALaAlarma(Integer dniUserQueAgregaALaAlarma, Integer idAlarma,
			Sensor sensorAAgregar, String codConfigAlarma) throws Exception {
		// id alarma, cod ocnfig alarma, sensor
		Usuario configuradorBuscado = buscarUsuarioPorDNI(dniUserQueAgregaALaAlarma);
		Alarma buscada = buscarAlarmaPorId(idAlarma);

		if (configuradorBuscado instanceof Configurable) {
			if (buscada.getCodConfiguracion().equals(codConfigAlarma)) {
				((Configurable) configuradorBuscado).agregarSensorAUnaAlarma(idAlarma, codConfigAlarma, sensorAAgregar);
				buscada.guardarAccionDeConfiguracion(buscada, configuradorBuscado);
			}
		}
	}

	public void queUnConfiguradorActiveElSensorDeUnaAlarma(Integer dniUserQueActiva, Integer idAlarma)  throws Exception{
		Usuario configuradorBuscado = buscarUsuarioPorDNI(dniUserQueActiva);
		Alarma buscada = buscarAlarmaPorId(idAlarma);
		
		if (configuradorBuscado instanceof Configurador) {
			((Configurador)configuradorBuscado).activarSensorDeAlarma(dniUserQueActiva, idAlarma, null);
		}
	}

}
