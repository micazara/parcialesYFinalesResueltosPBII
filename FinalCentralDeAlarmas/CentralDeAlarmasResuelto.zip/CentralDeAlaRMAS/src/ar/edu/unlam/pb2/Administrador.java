package ar.edu.unlam.pb2;

public class Administrador extends Usuario {

	private CentralDeAlarmas central;

	public Administrador(Integer dni, String nombre) {
		super(dni, nombre);
		this.central = new CentralDeAlarmas();
	}

	public boolean agregarAlarma(Alarma alarma) {
		return central.agregarAlarma(alarma);
	}

	public boolean agregarUsuario(Usuario usuario) {
		return central.agregarUsuario(usuario);
	}

	public void agregarUsuarioAUnaAlarma(Integer dniUsuarioAAgregar, Integer idAlarma, String codigoConfiguracionAlarma)
			throws Exception {
		Usuario usuarioAAgregar = central.buscarUsuarioPorDNI(dniUsuarioAAgregar);
		Alarma alarma = central.buscarAlarmaPorIdYCodigoConfiguracion(idAlarma, codigoConfiguracionAlarma);

		if (usuarioAAgregar != null && alarma != null) {
			alarma.agregarUsuario(usuarioAAgregar);
		}
	}

	public void agregarSensorAAlarma(Integer idAlarma, String codigoConfiguracionAlarma, Sensor sensor)
			throws AlarmaInexistente, UsuarioInexistente, SensorDuplicadoException {
		Alarma alarma = central.buscarAlarmaPorId(idAlarma);

		alarma.agregarSensor(sensor);

//		alarma.guardarAccionDeConfiguracion(alarma, null);
	}

	public void activarSensorDeAlarma(Integer idSensor, Integer idAlarma, String codigoConfiguracion) throws Exception {
		// todos los sensores de la alarma tienen q estar activados (en true)
		// el codigo de activacion que llega tiene que ser igual al de la alarma que ya
		// esta guardada en la central
		Alarma alarma = central.buscarAlarmaPorIdYCodigoConfiguracion(idAlarma, codigoConfiguracion);
		// para activar el sensor tiene que estar en la alarma
		Sensor buscado = alarma.buscarSensor(idSensor);

		alarma.activarSensor(buscado);

	}

	public void activarDesactivarAlarma(Integer idAlarma, String codigoActivacionAlarma, Usuario usuario)
			throws Exception {

		if (usuario instanceof Administrador || usuario instanceof Activador) {
			Alarma alarma = central.buscarAlarmaPorIdYCodigoDeActivacion(idAlarma, codigoActivacionAlarma);
			Usuario buscado = alarma.buscarUsuarioPorDni(usuario.getDni());
			((Activable) buscado).activarDesactivarAlarma(alarma, codigoActivacionAlarma, buscado);
		}
	}

	public CentralDeAlarmas getCentral() {
		return central;
	}

	void setCentral(CentralDeAlarmas central) {
		this.central = central;
	}

}
