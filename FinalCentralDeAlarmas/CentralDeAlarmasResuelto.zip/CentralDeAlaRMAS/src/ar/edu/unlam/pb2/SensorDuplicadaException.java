package ar.edu.unlam.pb2;

public class SensorDuplicadaException extends Exception {

}
