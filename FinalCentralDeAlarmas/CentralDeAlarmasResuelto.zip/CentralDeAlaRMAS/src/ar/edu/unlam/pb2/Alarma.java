package ar.edu.unlam.pb2;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Alarma {

	private Integer id;
	private String codConfiguracion;
	private String nombre;
	private Set<Accion> accionesRealizadas;
	private Set<Usuario> usuariosOperadores;
	private String codActivacionODesactivacion;
	private Set<Sensor> sensores;
	private Integer idAccion;
	private boolean estadoActualAlarma;

	public Alarma(Integer id, String codConfiguracion, String nombre, String codActivacionODesactivacion) {
		this.id = id;
		this.codConfiguracion = codConfiguracion;
		this.nombre = nombre;
		this.accionesRealizadas = new HashSet<Accion>();
		this.usuariosOperadores = new HashSet<Usuario>();
		this.codActivacionODesactivacion = codActivacionODesactivacion;
		this.sensores = new HashSet<Sensor>();
		this.idAccion = 1;
	}

	Integer getId() {
		return id;
	}

	void setId(Integer id) {
		this.id = id;
	}

	String getCodConfiguracion() {
		return codConfiguracion;
	}

	void setCodConfiguracion(String codConfiguracion) {
		this.codConfiguracion = codConfiguracion;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Set<Accion> getAccionesRealizadas() {
		return accionesRealizadas;
	}

	void setAccionesRealizadas(Set<Accion> accionesRealizadas) {
		this.accionesRealizadas = accionesRealizadas;
	}

	Set<Usuario> getUsuariosOperadores() {
		return usuariosOperadores;
	}

	void setUsuariosOperadores(Set<Usuario> usuariosOperadores) {
		this.usuariosOperadores = usuariosOperadores;
	}

	String getCodActivacionODesactivacion() {
		return codActivacionODesactivacion;
	}

	void setCodActivacionODesactivacion(String codActivacionODesactivacion) {
		this.codActivacionODesactivacion = codActivacionODesactivacion;
	}

	Set<Sensor> getSensores() {
		return sensores;
	}

	void setSensores(Set<Sensor> sensores) {
		this.sensores = sensores;
	}

	public void agregarUsuario(Usuario usuarioAAgregar) {
		this.usuariosOperadores.add(usuarioAAgregar);

	}

	public Integer obtenerCantidadDeUsuariosEnLaAlarma() {
		return this.usuariosOperadores.size();
	}

	public boolean agregarSensor(Sensor nuevo) throws SensorDuplicadoException {
		if (this.sensores.add(nuevo)) {

			return true;
		} else {
			throw new SensorDuplicadoException();
		}
	}

	public Integer obtenerCantidadDeSensores() {
		return this.sensores.size();
	}

	public Usuario buscarUsuarioPorDni(Integer dniABuscar) throws UsuarioInexistenteEnLaAlarma {
		for (Usuario actual : this.usuariosOperadores) {
			if (actual.getDni().equals(dniABuscar)) {
				return actual;
			}
		}
		return null;

	}

	public Sensor buscarSensor(Integer idSensor) throws SensorInexistente {
		for (Sensor actual : this.sensores) {
			if (actual.getId().equals(idSensor)) {
				return actual;
			}
		}
		throw new SensorInexistente();

	}

	public Boolean activarDesactivar(Alarma alarma, Usuario activador) throws LosSensoresEstanDesactivados {
		if (losSensoresEstanActivados()) {
			// se activa
			this.estadoActualAlarma = true;
			// guardar que se activo
			guardarAccion(alarma, activador);
			this.incrementarIdAccion();
			return true;
		}
		return null;

	}

	private void guardarAccion(Alarma alarma, Usuario activador) {
		Accion accion = new Accion(this.idAccion, TipoDeOperacion.ACTIVIACION, alarma, LocalDate.now(), activador);
		this.accionesRealizadas.add(accion);
	}

	private void incrementarIdAccion() {
		this.idAccion++;
	}

	public boolean losSensoresEstanActivados() throws LosSensoresEstanDesactivados {
		for (Sensor actual : this.sensores) {
			if (actual.getEstado() == true) {
				return true;
			}
		}

		throw new LosSensoresEstanDesactivados();
	}

	public void activarSensor(Sensor sensorAActivar) {
		sensorAActivar.setEstado(true);
	}

	public Integer obtenerCantidadDeSensoresActivados() {
		int sensor = 0;
		for (Sensor actual : this.sensores) {
			if (actual.getEstado() == true) {
				sensor++;
			}
		}

		return sensor;
	}

	public void guardarAccionDeConfiguracion(Alarma alarma, Usuario realizador) {
		Accion nueva = new Accion(this.idAccion, TipoDeOperacion.CONFIGURACION, alarma, LocalDate.now(), realizador);
		this.accionesRealizadas.add(nueva);
		this.incrementarIdAccion();

	}

	public TreeSet<Accion> obtenerAccionesDeTipoConfiguracionOrdenadasPorIdDeAccion() {
		TreeSet<Accion> accionesOrdenadas = new TreeSet<Accion>(new AccionesOrdenadasPorId());
		for (Accion actual : this.accionesRealizadas) {
			if (actual.getTipoDeOperacion().equals(TipoDeOperacion.CONFIGURACION)) {
				accionesOrdenadas.add(actual);
			}
		}
		return accionesOrdenadas;

	}

	public boolean seGuardoElSensor(Sensor aAgregar) {
		return this.sensores.contains(aAgregar);
	}

	public Accion buscarAtencionPorId(Integer id) throws AccionInexistente {
		for (Accion actual : this.accionesRealizadas) {
			if (actual.getId().equals(id)) {
				return actual;
			}
		}
		throw new AccionInexistente();
	}

}
