package ar.edu.unlam.pb2;

public class AccionInexistente extends Exception {

}
