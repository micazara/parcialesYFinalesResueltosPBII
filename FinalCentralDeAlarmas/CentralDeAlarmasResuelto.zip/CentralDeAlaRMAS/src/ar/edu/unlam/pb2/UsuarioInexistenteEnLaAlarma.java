package ar.edu.unlam.pb2;

public class UsuarioInexistenteEnLaAlarma extends Exception {

}
