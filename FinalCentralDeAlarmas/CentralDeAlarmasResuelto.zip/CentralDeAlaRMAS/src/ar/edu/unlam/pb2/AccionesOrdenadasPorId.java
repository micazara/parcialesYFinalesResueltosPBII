package ar.edu.unlam.pb2;

import java.util.Comparator;

public class AccionesOrdenadasPorId implements Comparator<Accion> {

	@Override
	public int compare(Accion o1, Accion o2) {
		return o1.getId().compareTo(o2.getId());
	}

}
