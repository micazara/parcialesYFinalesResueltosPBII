package ar.edu.unlam.pb2;

import java.util.Set;

public class Configurador extends Usuario implements Configurable {

	private CentralDeAlarmas central;

	public Configurador(Integer dni, String nombre, CentralDeAlarmas central) {
		super(dni, nombre);
		this.central = central;
	}

	@Override
	public void agregarSensorAUnaAlarma(Integer idAlarma, String codConfigDeLaAlarma, Sensor aAgregar)
			throws Exception {
		Alarma alarma = central.buscarAlarmaPorId(idAlarma);
		if (alarma.getCodConfiguracion().equals(codConfigDeLaAlarma)) {
// se puede agregar el sensor
			if (!alarma.seGuardoElSensor(aAgregar)) {
				alarma.agregarSensor(aAgregar);
			}
		}
	}

	@Override
	public void activarSensorDeAlarma(Integer idSensor, Integer idAlarma, String codActivacionDeLaAlarma)
			throws AlarmaInexistente, SensorInexistente {
		// buscar una alarma con ese id
		// buscar q el cod de config coincida con el de la alarma
		Alarma alarma = central.buscarAlarmaPorIdYCodigoDeActivacion(idAlarma, codActivacionDeLaAlarma);

		// buscar un sensor con ese id
		Sensor buscado = alarma.buscarSensor(idSensor);

		// activo ese sensor en la alarma
		alarma.activarSensor(buscado);

	}

	@Override
	public void agregarUsuarioALaAlarma(Integer dniUserAAgregar, Integer idAlarma, String codConfigDeLaAlarma)
			throws CodigoAlarmaIncorrecto, AlarmaInexistente, UsuarioInexistenteEnLaAlarma, UsuarioInexistente {

		// obtengo la alarma segun el id ingresado
		Alarma alarma = central.buscarAlarmaPorId(idAlarma);
		// me fijo que no haya en la alarma un usuario con ese dni
		Usuario encontrado = alarma.buscarUsuarioPorDni(dniUserAAgregar);
		// si no hay en la alarma un usuario con ese dni, lo busco en la central de
		// alarmas para obtenerlo y poder agregarlo a la alarma
		if (encontrado == null) {
			Usuario usuarioAAgregarALaAlarma = central.buscarUsuarioPorDNI(dniUserAAgregar);
			// sino, si son iguales, puede agregar un usuario a la alarma
			if (alarma.getCodConfiguracion().equals(codConfigDeLaAlarma)) {
				alarma.agregarUsuario(usuarioAAgregarALaAlarma);
			} else {
				// si el codigo de esa alarma que encontre es distinto al codigo q llega por
				// parametor lanzo la excepcion
				throw new CodigoAlarmaIncorrecto();
			}
		}

	}

	@Override
	public String toString() {
		return "Configurador [central=" + central + ", getDni()=" + getDni() + ", getNombre()=" + getNombre()
				+ ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]"
				+ "\n";
	}

}
