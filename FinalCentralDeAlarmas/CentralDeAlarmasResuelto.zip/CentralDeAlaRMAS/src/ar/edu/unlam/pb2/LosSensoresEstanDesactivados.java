package ar.edu.unlam.pb2;

public class LosSensoresEstanDesactivados extends Exception {

}
