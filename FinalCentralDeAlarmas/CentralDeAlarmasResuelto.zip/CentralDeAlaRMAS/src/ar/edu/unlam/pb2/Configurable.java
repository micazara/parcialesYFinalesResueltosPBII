package ar.edu.unlam.pb2;

public interface Configurable {

	void agregarUsuarioALaAlarma(Integer dniUserAAgregar, Integer idAlarma, String codConfigDeLaAlarma)
			throws CodigoAlarmaIncorrecto, AlarmaInexistente, UsuarioInexistenteEnLaAlarma, UsuarioInexistente;

	void agregarSensorAUnaAlarma(Integer idAlarma, String codConfigDeLaAlarma, Sensor aAgregar)
			throws SensorDuplicadaException, Exception;

	void activarSensorDeAlarma(Integer idSensor, Integer idAlarma, String codConfigDeLaAlarma) throws AlarmaInexistente, SensorInexistente;

}
