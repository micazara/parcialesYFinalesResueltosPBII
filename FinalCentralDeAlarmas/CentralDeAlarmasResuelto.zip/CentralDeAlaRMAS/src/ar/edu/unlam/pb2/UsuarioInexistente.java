package ar.edu.unlam.pb2;

public class UsuarioInexistente extends Exception {

}
