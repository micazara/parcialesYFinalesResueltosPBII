package ar.edu.unlam.pb2;

import java.time.LocalDate;
import java.util.Objects;

public class Accion {

	private Integer id;
	private TipoDeOperacion tipoDeOperacion;
	private Alarma alarma;
	private LocalDate fecha;
	private Usuario realizador;

	public Accion(Integer id, TipoDeOperacion tipoDeOperacion, Alarma alarma, LocalDate fecha, Usuario realizador) {
		this.id = id;
		this.tipoDeOperacion = tipoDeOperacion;
		this.alarma = alarma;
		this.fecha = fecha;
		this.realizador = realizador;
	}

	Integer getId() {
		return id;
	}

	void setId(Integer id) {
		this.id = id;
	}

	TipoDeOperacion getTipoDeOperacion() {
		return tipoDeOperacion;
	}

	void setTipoDeOperacion(TipoDeOperacion tipoDeOperacion) {
		this.tipoDeOperacion = tipoDeOperacion;
	}

	Alarma getAlarma() {
		return alarma;
	}

	void setAlarma(Alarma alarma) {
		this.alarma = alarma;
	}

	LocalDate getFecha() {
		return fecha;
	}

	void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	Usuario getRealizador() {
		return realizador;
	}

	void setRealizador(Usuario realizador) {
		this.realizador = realizador;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Accion other = (Accion) obj;
		return Objects.equals(id, other.id);
	}

	@Override
	public String toString() {
		return "Accion [id=" + id + ", tipoDeOperacion=" + tipoDeOperacion + ", alarma=" + alarma + ", fecha=" + fecha
				+ ", realizador=" + realizador + "]" + "\n";
	}

}
