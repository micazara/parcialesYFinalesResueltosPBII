package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import java.util.TreeSet;

import org.junit.Test;

public class TestCasesCentralDeAlarmas {

	/*
	 * queSePueda Registrar UnaAlarmaEnLaCentral(). LISTO
	 * 
	 * 
	 * queSePuedaAgregar UnUsuarioConfiguradorAUnaAlarma(). LISTO
	 * 
	 * alAgregar UnUsuarioAUnaAlarmaConCodigoDeConfiguracionDeAlarmalnvalidoSeLa nce
	 * CodigoAlarmalncorrectoException(). LISTO
	 * 
	 * alAgregarUnSensor Duplicado EnUnaAlarmaSelanceUnaSensorDuplicadoExceptio n().
	 * LISTO
	 * 
	 * queNoSePueda Activar UnaAlarmaSiHayAlMenos UnSensorDesactivado(). LISTO 6.
	 * quePara UnaAlarmaDeterminadaSePueda Obtener Una Coleccion OrdenadaDeAcccion
	 * esDe TipoConfiguracionOdenadas PorldDeAccion().
	 */

	@Test
	public void queSePuedaRegistrarUnaAlarmaEnLaCentral() {
		Usuario admin = new Administrador(44892966, "Micaela");
		Alarma alarma = new Alarma(1, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);
		Integer cantidadActualDeAlarmas = ((Administrador) admin).getCentral().obtenerCantidadDeAlarmas();
		Integer cantidadEsperadaDeAlarmas = 1;

		assertEquals(cantidadEsperadaDeAlarmas, cantidadActualDeAlarmas);
	}

	@Test
	public void queSePuedaAgregarUnUsuarioConfiguradorAUnaAlarma() throws Exception {
		// quien puede agregar usuarios a la alarma? el usuario config y el usuario
		// admin
		// para poder agregar un user config a la alarma necesito tener una alarma y un
		// usuario config en la central de alarma
		Usuario admin = new Administrador(44892966, "Micaela");

		Alarma alarma = new Alarma(1, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);

		Usuario configurador = new Configurador(12345678, "Franco", ((Administrador) admin).getCentral());
		((Administrador) admin).agregarUsuario(configurador);

		((Administrador) admin).agregarUsuarioAUnaAlarma(12345678, 1, "Config");

		Integer cantidadActualDeUsuariosEnLaAlarma = alarma.obtenerCantidadDeUsuariosEnLaAlarma();

		Integer cantidadEsperadaDeUsuariosEnLaAlarma = 1;

		assertEquals(cantidadEsperadaDeUsuariosEnLaAlarma, cantidadActualDeUsuariosEnLaAlarma);

	}

	@Test(expected = CodigoAlarmaIncorrecto.class)
	public void queAlAgregarUnUsuarioAUnaAlarmaConCodigoDeConfiguracionDeAlarmalnvalidoSeLanceCodigoAlarmalncorrectoException()
			throws Exception {
		Usuario admin = new Administrador(44892966, "Micaela");

		Integer idAlarma = 1;
		Alarma alarma = new Alarma(idAlarma, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);

		Usuario configurador = new Configurador(12345678, "Franco", ((Administrador) admin).getCentral());
		((Administrador) admin).agregarUsuario(configurador);

// ahora yo quiero q el user configurador agregue un usuario activador a la alarma
		// agregar otro usuario a la central
		Usuario activador = new Usuario(1, "Andres Puto");
		((Administrador) admin).agregarUsuario(activador);

		// si el usuario configurador esta en la central hago que agregue un uausrio a
		// la alarma

		Integer dniUserAAgregarALaAlarma = 1;
		String codigoConfig = "NOT CONFIG";
		Integer dniConfiguradorQueAgrega = 12345678;
		((Administrador) admin).getCentral().queUnConfiguradorAgregueUnUsuarioALaAlarma(dniUserAAgregarALaAlarma,
				idAlarma, codigoConfig, dniConfiguradorQueAgrega);

	}

	@Test(expected = SensorDuplicadoException.class)
	public void queAlAgregarUnSensorDuplicadoEnUnaAlarmaSeLanceUnaSensorDuplicadoException()
			throws AlarmaInexistente, UsuarioInexistente, SensorDuplicadoException {
		// quien puede agregar sensores a las alarmas? el admin y el config
		Usuario admin = new Administrador(44892966, "Micaela");

		// necesito una alarma
		Integer idAlarma = 1;
		Alarma alarma = new Alarma(idAlarma, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);

		// necesito un sensor
		Sensor sensor = new Sensor(1, true);
		Sensor otro = new Sensor(1, false);

		((Administrador) admin).agregarSensorAAlarma(idAlarma, "Config", sensor);
		((Administrador) admin).agregarSensorAAlarma(idAlarma, "Config", otro);
	}

	@Test(expected = LosSensoresEstanDesactivados.class)
	public void queNoSePuedaActivarUnaAlarmaSiHayAlMenosUnSensorDesactivado() throws Exception {
		Usuario admin = new Administrador(44892966, "Micaela");

		// necesito una alarma
		Integer idAlarma = 1;
		Alarma alarma = new Alarma(idAlarma, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);

		// necesito un sensor
		Sensor sensor = new Sensor(1, false);
		Sensor otro = new Sensor(2, false);

		((Administrador) admin).agregarSensorAAlarma(idAlarma, "Config", sensor);
		((Administrador) admin).agregarSensorAAlarma(idAlarma, "Config", otro);

		// necesito un usuario que active un sensor de la alarma
//		((Administrador) admin).activarSensorDeAlarma(1, idAlarma, "Config");

		Usuario activador = new Activador(44892966, "Mica");
		((Administrador) admin).agregarUsuario(activador);

		((Administrador) admin).agregarUsuarioAUnaAlarma(44892966, 1, "Config");

		// necesito un usuario que active la alarma
		((Administrador) admin).activarDesactivarAlarma(idAlarma, "AD", activador);
	}

	@Test
	public void queParaUnaAlarmaDeterminadaSePuedaObtenerUnaColeccionOrdenadaDeAccionesDeTipoConfiguracionOdenadasPorldDeAccion()
			throws Exception {
// hacer q un user configurador agregue un user a la alarma
		Usuario admin = new Administrador(44892966, "Micaela");

		Integer idAlarma = 1;
		Alarma alarma = new Alarma(idAlarma, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);

		Usuario configurador = new Configurador(12345678, "Franco", ((Administrador) admin).getCentral());
		((Administrador) admin).agregarUsuario(configurador);

		// agregar otro usuario a la central
		Usuario activador = new Usuario(1, "Andres Puto");
		((Administrador) admin).agregarUsuario(activador);

		Usuario otro = new Activador(3256151, "Yo");
		((Administrador) admin).agregarUsuario(otro);

		// si el usuario configurador esta en la central hago que agregue un uausrio a
		// la alarma

// ahora yo quiero q el user configurador agregue un usuario activador a la alarma
		Integer dniUserAAgregarALaAlarma = 1;
		String codigoConfig = "Config";
		Integer dniConfiguradorQueAgrega = 12345678;
		((Administrador) admin).getCentral().queUnConfiguradorAgregueUnUsuarioALaAlarma(dniUserAAgregarALaAlarma,
				idAlarma, codigoConfig, dniConfiguradorQueAgrega);

		((Administrador) admin).getCentral().queUnConfiguradorAgregueUnUsuarioALaAlarma(3256151, idAlarma, codigoConfig,
				dniConfiguradorQueAgrega);

		TreeSet<Accion> accionesOrdenadas = alarma.obtenerAccionesDeTipoConfiguracionOrdenadasPorIdDeAccion();
		System.out.println(accionesOrdenadas.toString());

		Accion primerAccion = accionesOrdenadas.first();
		Accion ultimaAccion = accionesOrdenadas.last();

		assertEquals((Integer) 1, primerAccion.getId());
		assertEquals((Integer) 2, ultimaAccion.getId());
		// verificar el dni del user que realiza la accion de agregar, que es franco
		assertEquals((Integer) 12345678, primerAccion.getRealizador().getDni());
	}

	@Test
	public void queUnConfiguradorPuedaAgregarUnSensorALaAlarma() throws Exception {
		Usuario admin = new Administrador(44892966, "Micaela");

		// AGREGO ALARMA A LA CENTRAL
		Integer idAlarma = 1;
		Alarma alarma = new Alarma(idAlarma, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);

		// AGREGO CONFIGURADOR A LA CENTRAL
		Usuario configurador = new Configurador(12345678, "Franco", ((Administrador) admin).getCentral());
		((Administrador) admin).agregarUsuario(configurador);

		Sensor sensor = new Sensor(1, true);
		// para que un configurador pueda agregar el sensor a la alarma necesito saber
		// que el user y la alarma estan en la central
		((Administrador) admin).getCentral().queUnConfiguradorAgregueUnSensorALaAlarma(configurador.getDni(),
				alarma.getId(), sensor, "Config");

		Integer cantidadActualDeSensoresEnLaAlarma = alarma.obtenerCantidadDeSensores();
		Integer cantidadEsperadaDeSensoresEnLaAlarma = 1;

		assertEquals(cantidadEsperadaDeSensoresEnLaAlarma, cantidadActualDeSensoresEnLaAlarma);
	}

	@Test
	public void queUnConfiguradorPuedaAgregarUnSensorALaAlarmaYQueSeGuardeCorrectamenteLaAccion() throws Exception {
		Usuario admin = new Administrador(44892966, "Micaela");

		// AGREGO ALARMA A LA CENTRAL
		Integer idAlarma = 1;
		Alarma alarma = new Alarma(idAlarma, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);

		// AGREGO CONFIGURADOR A LA CENTRAL
		Usuario configurador = new Configurador(12345678, "Franco", ((Administrador) admin).getCentral());
		((Administrador) admin).agregarUsuario(configurador);

		Sensor sensor = new Sensor(1, true);
		// para que un configurador pueda agregar el sensor a la alarma necesito saber
		// que el user y la alarma estan en la central
		((Administrador) admin).getCentral().queUnConfiguradorAgregueUnSensorALaAlarma(configurador.getDni(),
				alarma.getId(), sensor, "Config");

		Integer cantidadActualDeSensoresEnLaAlarma = alarma.obtenerCantidadDeSensores();
		Integer cantidadEsperadaDeSensoresEnLaAlarma = 1;

		Accion buscada = alarma.buscarAtencionPorId(1);

		Usuario realizadorEsperadoDeLaAccion = buscada.getRealizador();
		Usuario realizarActualDeLaAccion = configurador;

		assertEquals(cantidadEsperadaDeSensoresEnLaAlarma, cantidadActualDeSensoresEnLaAlarma); 
		
		assertEquals(realizadorEsperadoDeLaAccion, realizarActualDeLaAccion);
	}
	
	@Test
	public void queUnConfiguradorPuedaActivarElSensorDeUnaAlarmaYQueLaAccionSeGuardeCorrectamente() throws Exception{
		Usuario admin = new Administrador(44892966, "Micaela");

		// AGREGO ALARMA A LA CENTRAL
		Integer idAlarma = 1;
		Alarma alarma = new Alarma(idAlarma, "Config", "Alarma", "AD");
		((Administrador) admin).agregarAlarma(alarma);

		// AGREGO CONFIGURADOR A LA CENTRAL
		Usuario configurador = new Configurador(12345678, "Franco", ((Administrador) admin).getCentral());
		((Administrador) admin).agregarUsuario(configurador);
		
		// AGREGO SENSOR A LA ALARMA A TRAVES DE LA CENTRAL DE ALARMAS

		Sensor sensor = new Sensor(1, true);
		((Administrador) admin).getCentral().queUnConfiguradorActiveElSensorDeUnaAlarma(configurador.getDni(), alarma.getId());

		
	}
}
