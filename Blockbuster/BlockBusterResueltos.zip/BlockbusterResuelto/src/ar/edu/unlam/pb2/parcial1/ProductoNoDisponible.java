package ar.edu.unlam.pb2.parcial1;

public class ProductoNoDisponible extends Exception {

}
