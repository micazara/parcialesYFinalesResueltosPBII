package ar.edu.unlam.pb2.parcial1;

public enum Clasificacion {
	ATP, MayorA7, MayorA18
}
