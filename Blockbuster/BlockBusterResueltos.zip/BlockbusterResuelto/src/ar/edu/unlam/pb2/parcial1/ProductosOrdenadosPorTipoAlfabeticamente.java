package ar.edu.unlam.pb2.parcial1;

import java.util.Comparator;

public class ProductosOrdenadosPorTipoAlfabeticamente implements Comparator<Producto> {

	@Override
	public int compare(Producto o1, Producto o2) {
		return o1.getClass().getName().compareTo(o2.getClass().getName());
	}

}
