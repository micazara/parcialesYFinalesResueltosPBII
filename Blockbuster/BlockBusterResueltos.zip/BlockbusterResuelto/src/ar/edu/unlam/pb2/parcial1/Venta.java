package ar.edu.unlam.pb2.parcial1;

public class Venta {

	private Integer codigoVenta;
	private Cliente cliente;
	private Producto producto;

	public Venta(Integer codigoVenta, Cliente cliente, Producto producto) {
		this.codigoVenta = codigoVenta;
		this.cliente = cliente;
		this.producto = producto;
	}

	Integer getCodigoVenta() {
		return codigoVenta;
	}

	void setCodigoVenta(Integer codigoVenta) {
		this.codigoVenta = codigoVenta;
	}

	Cliente getCliente() {
		return cliente;
	}

	void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	Producto getProducto() {
		return producto;
	}

	void setProducto(Producto producto) {
		this.producto = producto;
	}

}
