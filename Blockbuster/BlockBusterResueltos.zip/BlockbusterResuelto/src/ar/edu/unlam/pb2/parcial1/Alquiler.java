package ar.edu.unlam.pb2.parcial1;

public class Alquiler {
	private Integer codigoAlquiler;
	private Cliente cliente;
	private Producto producto;

	public Alquiler(Integer codigoVenta, Cliente cliente, Producto producto) {
		this.codigoAlquiler = codigoVenta;
		this.cliente = cliente;
		this.producto = producto;
	}

	Integer getCodigoVenta() {
		return codigoAlquiler;
	}

	void setCodigoVenta(Integer codigoVenta) {
		this.codigoAlquiler = codigoVenta;
	}

	Cliente getCliente() {
		return cliente;
	}

	void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	Producto getProducto() {
		return producto;
	}

	void setProducto(Producto producto) {
		this.producto = producto;
	}
}
