package ar.edu.unlam.pb2.parcial1;

public class Libro extends Producto implements Vendible {

	public String autor;
	public String editorial;

	public Libro(Integer cod, String descripcion, Estado estado, String autor, String editorial) {
		super(cod, descripcion, estado);
		this.autor = autor;
		this.editorial = editorial;
	}

	public String getAutor() {
		return autor;
	}

	void setAutor(String autor) {
		this.autor = autor;
	}

	public String getEditorial() {
		return editorial;
	}

	void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	@Override
	public Double getPrecioDeVenta() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setPrecioVenta(Double precioVenta) {
		// TODO Auto-generated method stub

	}

}
