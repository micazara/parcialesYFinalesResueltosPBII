package ar.edu.unlam.pb2.parcial1;

public enum Estado {
DISPONIBLE,
VENDIDO,
ALQUILADO
}
