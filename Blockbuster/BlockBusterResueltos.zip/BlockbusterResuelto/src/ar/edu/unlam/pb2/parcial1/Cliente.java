package ar.edu.unlam.pb2.parcial1;

import java.util.Objects;

public class Cliente {

	private Integer codigo;
	private String apellido;
	private String nombre;
	private Integer edad;

	public Cliente(Integer codigo, String apellido, String nombre, Integer edad) {
		this.codigo = codigo;
		this.apellido = apellido;
		this.nombre = nombre;
		this.edad = edad;
	}

	Integer getCodigo() {
		return codigo;
	}

	void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	String getApellido() {
		return apellido;
	}

	void setApellido(String apellido) {
		this.apellido = apellido;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Integer getEdad() {
		return edad;
	}

	void setEdad(Integer edad) {
		this.edad = edad;
	}

	@Override
	public int hashCode() {
		return Objects.hash(codigo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		Cliente other = (Cliente) obj;
		return Objects.equals(codigo, other.codigo);
	}

}
