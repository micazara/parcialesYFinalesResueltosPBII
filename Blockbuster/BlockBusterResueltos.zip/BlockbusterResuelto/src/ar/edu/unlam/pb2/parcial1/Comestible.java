package ar.edu.unlam.pb2.parcial1;

public class Comestible extends Producto implements Vendible {

	public Comestible(Integer cod, String descripcion, Estado estado) {
		super(cod, descripcion, estado);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double getPrecioDeVenta() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setPrecioVenta(Double precioVenta) {
		// TODO Auto-generated method stub

	}

}
