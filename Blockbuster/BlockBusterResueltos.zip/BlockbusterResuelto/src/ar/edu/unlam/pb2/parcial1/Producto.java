package ar.edu.unlam.pb2.parcial1;

import java.util.Objects;

public class Producto {

	public Integer cod;
	public String descripcion;
	public Estado estado;
	public Cliente quienPoseeElProducto;

	public Producto(Integer cod, String descripcion, Estado estado) {
		this.cod = cod;
		this.descripcion = descripcion;
		this.estado = estado;
		this.quienPoseeElProducto = null;
	}

	public Integer getCod() {
		return cod;
	}

	void setCod(Integer cod) {
		this.cod = cod;
	}

	public String getDescripcion() {
		return descripcion;
	}

	void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Estado getEstadoActual() {
		return this.estado;
	}

	public Cliente getQuienPoseeElProducto() {
		return this.quienPoseeElProducto;
	}

	public void setEstadoActual(Estado estado) {
		this.estado = estado;

	}

	public void setQuienPoseeElProducto(Cliente quienPoseeElCliente) {
		this.quienPoseeElProducto = quienPoseeElCliente;

	}

	@Override
	public int hashCode() {
		return Objects.hash(cod);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		Producto other = (Producto) obj;
		return Objects.equals(cod, other.cod);
	}

}
