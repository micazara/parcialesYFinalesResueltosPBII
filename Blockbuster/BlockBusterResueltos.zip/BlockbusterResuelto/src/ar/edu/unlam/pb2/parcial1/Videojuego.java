package ar.edu.unlam.pb2.parcial1;

public class Videojuego extends Producto implements Alquilable {

	private TipoDeConsola consola;
	private Double precioAlquiler;
	private Clasificacion clasificacion;

	public Videojuego(Integer cod, String descripcion, Estado estado, TipoDeConsola consola, Double precioAlquiler,
			Clasificacion clasificacion) {
		super(cod, descripcion, estado);
		this.consola = consola;
		this.precioAlquiler = precioAlquiler;
		this.clasificacion = clasificacion;
	}

	public TipoDeConsola getTipo() {
		return this.consola;
	}

	void setTipo(TipoDeConsola consola) {
		this.consola = consola;
	}

	@Override
	public Double getPrecioDeAlquiler() {
		return this.precioAlquiler;
	}

	@Override
	public void setPrecioAlquiler(Double precioAlquiler) {
		this.precioAlquiler = precioAlquiler;

	}

	@Override
	public Clasificacion getClasificacion() {
		return this.clasificacion;
	}

	@Override
	public void setCalifiacion(Clasificacion clasificacion) {
		this.clasificacion = clasificacion;

	}

}
