package ar.edu.unlam.pb2.parcial1;

public enum Genero {
INFANTIL,
COMEDIA,
ACCION,
TERROR,
SUSPENSO
}
