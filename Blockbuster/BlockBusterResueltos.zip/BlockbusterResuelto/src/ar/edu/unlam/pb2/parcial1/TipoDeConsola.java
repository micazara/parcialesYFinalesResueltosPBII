package ar.edu.unlam.pb2.parcial1;

public enum TipoDeConsola {
PLAY_STATION,
WII,
PC
}
