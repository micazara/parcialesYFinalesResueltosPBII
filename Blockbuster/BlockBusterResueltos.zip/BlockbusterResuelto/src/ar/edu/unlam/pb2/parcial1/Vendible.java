package ar.edu.unlam.pb2.parcial1;

public interface Vendible {
	
	Double getPrecioDeVenta();

	void setPrecioVenta(Double precioVenta);
;
}
