package ar.edu.unlam.pb2.parcial1;

public class ProductoNoVendible extends Exception {

}
