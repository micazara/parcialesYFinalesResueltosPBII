package ar.edu.unlam.pb2.parcial1;

import java.util.HashSet;
import java.util.Set;

public class Pelicula extends Producto implements Vendible, Alquilable {

	public Integer codigo;
	public String descripcion;
	public Genero genero;
	public Integer anoEstreno;
	public String director;
	public Set<String> actores;
	public Double precioVenta;
	public Clasificacion clasificacion;

	public Pelicula(Integer cod, String descripcion, Estado estado, Genero genero, Integer anoEstreno, String director,
			Double precioVenta, Clasificacion clasificacion) {
		super(cod, descripcion, estado);
		this.genero = genero;
		this.anoEstreno = anoEstreno;
		this.director = director;
		this.actores = new HashSet<String>();
		this.precioVenta = precioVenta;
		this.clasificacion = clasificacion;
	}

	public void agregarActor(String nuevo) {
		this.actores.add(nuevo);

	}

	public Boolean actua(String actor) {
		return this.actores.contains(actor);
	}

	public Genero getGenero() {
		return genero;
	}

	void setGenero(Genero genero) {
		this.genero = genero;
	}

	public Integer getAnoEstreno() {
		return anoEstreno;
	}

	void setAnoEstreno(Integer anoEstreno) {
		this.anoEstreno = anoEstreno;
	}

	public String getDirector() {
		return director;
	}

	void setDirector(String director) {
		this.director = director;
	}

	public Set<String> getActores() {
		return actores;
	}

	void setActores(Set<String> actores) {
		this.actores = actores;
	}

	@Override
	public Double getPrecioDeAlquiler() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setPrecioVenta(Double precioVenta) {
		this.precioVenta = precioVenta;

	}

	@Override
	public Double getPrecioDeVenta() {
		return precioVenta;
	}

	@Override
	public void setPrecioAlquiler(Double pRECIO_ALQUILER) {
		// TODO Auto-generated method stub

	}

	@Override
	public Clasificacion getClasificacion() {
		return this.clasificacion;
	}

	@Override
	public void setCalifiacion(Clasificacion clasificacion) {
		this.clasificacion = clasificacion;

	}

}
