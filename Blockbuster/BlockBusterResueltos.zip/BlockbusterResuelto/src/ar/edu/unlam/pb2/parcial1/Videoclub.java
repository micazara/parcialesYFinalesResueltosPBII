package ar.edu.unlam.pb2.parcial1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Videoclub {

	// los productos se venden y/o se alquilan. Para poder vender un prod tengo q
	// asegurarme q sea vendible. Para alquilar un prod tengo q asegurarme q sea
	// alquilable.
	// tengo q llevar un registro de las ventas
	// tengo q llevar un registro de los alquileres

	private String nombre;
	private Set<Producto> productos;
	private Set<Cliente> clientes;
	private List<Venta> ventas;
	private Integer codigoVenta;
	private List<Alquiler> alquileres;
	private Integer codigoAlquiler;

	public Videoclub(String nombre) {
		this.nombre = nombre;
		this.productos = new HashSet<Producto>();
		this.clientes = new HashSet<Cliente>();
		this.ventas = new ArrayList<Venta>();
		this.codigoVenta = 0;
		this.alquileres = new ArrayList<Alquiler>();
		this.codigoAlquiler = 0;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void agregarProducto(Producto nuevoProducto) throws NoSePudoAgregarElProducto {
		if (!this.productos.add(nuevoProducto)) {
			throw new NoSePudoAgregarElProducto();
		}
	}

	public Producto buscarProducto(Producto nuevoProducto) throws ProductoNoEncontrado {
		for (Producto actual : productos) {
			if (actual.getCod().equals(nuevoProducto.getCod())) {
				return actual;
			}
		}

		throw new ProductoNoEncontrado();
	}

	public Boolean vender(Producto nuevoProducto, Cliente nuevoCliente)
			throws ProductoNoEncontrado, NoSeEncontroElCliente, ProductoNoVendible, ProductoNoDisponible {
		Cliente buscado = buscarCliente(nuevoCliente);
		Producto productoBuscado = buscarProducto(nuevoProducto);
		if (elProductoEsVendible(productoBuscado)) {
			if (estaDisponible(nuevoProducto)) {
				crearVenta(buscado, productoBuscado);
				incrementarCodigoVenta();
				actualizarEstadoDelProductoLuegoDeLaVenta(nuevoProducto);
				productoBuscado.setQuienPoseeElProducto(buscado);
				return true;
			}
			throw new ProductoNoDisponible();
		}

		throw new ProductoNoVendible();

	}

	private Boolean elProductoEsVendible(Producto nuevoProducto) {
		return nuevoProducto instanceof Vendible;
	}

	private void crearVenta(Cliente buscado, Producto productoBuscado) {
		Venta nueva = new Venta(this.codigoVenta, buscado, productoBuscado);
		this.ventas.add(nueva);
	}

	private void actualizarEstadoDelProductoLuegoDeLaVenta(Producto nuevoProducto) {
		nuevoProducto.setEstadoActual(Estado.VENDIDO);
	}

	private Boolean estaDisponible(Producto nuevoProducto) {
		return nuevoProducto.getEstadoActual().equals(Estado.DISPONIBLE);
	}

	private void incrementarCodigoVenta() {
		this.codigoVenta++;
	}

	private Cliente buscarCliente(Cliente nuevoCliente) throws NoSeEncontroElCliente {
		for (Cliente actual : this.clientes) {
			if (actual.getCodigo().equals(nuevoCliente.getCodigo())) {
				return actual;
			}
		}

		throw new NoSeEncontroElCliente();
	}

	public void agregarCliente(Cliente nuevoCliente) throws NoSePudoAgregarElCliente {
		if (!this.clientes.add(nuevoCliente)) {
			throw new NoSePudoAgregarElCliente();
		}

	}

	public Boolean alquilar(Producto nuevoProducto, Cliente nuevoCliente)
			throws NoSeEncontroElCliente, ProductoNoEncontrado, ProductoNoAlquilable, ProductoNoDisponible,
			NoSeLePuedeAlquilarUnaPeliculaMayorA18AUnMenor {

		Cliente buscado = buscarCliente(nuevoCliente);
		Producto productoBuscado = buscarProducto(nuevoProducto);

		if (elProductoEsAlquilable(productoBuscado)) {
			if (estaDisponible(nuevoProducto)
					&& laEdadDelClienteCorrespondeConLaClasificacion(buscado, productoBuscado)) {

				crearAlquiler(buscado, productoBuscado);
				incrementarCodigoDeAlquiler();
				actualizarElEstadoDelProductoLuegoDelAlquiler(productoBuscado);
				productoBuscado.setQuienPoseeElProducto(buscado);
				return true;
			}

			throw new ProductoNoDisponible();

		}
		throw new ProductoNoAlquilable();

	}

	private void actualizarElEstadoDelProductoLuegoDelAlquiler(Producto productoBuscado) {
		productoBuscado.setEstadoActual(Estado.ALQUILADO);
	}

	private void incrementarCodigoDeAlquiler() {
		this.codigoAlquiler++;
	}

	private void crearAlquiler(Cliente buscado, Producto productoBuscado) {
		Alquiler nuevo = new Alquiler(this.codigoAlquiler, buscado, productoBuscado);
		this.alquileres.add(nuevo);
	}

	private Boolean laEdadDelClienteCorrespondeConLaClasificacion(Cliente buscado, Producto productoBuscado)
			throws NoSeLePuedeAlquilarUnaPeliculaMayorA18AUnMenor {
		if (buscado.getEdad() >= 18
				&& ((Alquilable) productoBuscado).getClasificacion().equals(Clasificacion.MayorA18)) {
			return true;
		} else if (buscado.getEdad() < 18
				&& ((Alquilable) productoBuscado).getClasificacion().equals(Clasificacion.MayorA18)) {
			throw new NoSeLePuedeAlquilarUnaPeliculaMayorA18AUnMenor();
		} else if (buscado.getEdad() >= 7
				&& ((Alquilable) productoBuscado).getClasificacion().equals(Clasificacion.MayorA7)) {
			return true;
		} else {
			return true;
		}
	}

	private Boolean elProductoEsAlquilable(Producto productoBuscado) {
		return productoBuscado instanceof Alquilable;
	}

	public Boolean devolver(Producto nuevoProducto, Cliente nuevoCliente)
			throws ProductoNoEncontrado, ProductoNoAlquilable {
		// para devolver tengo que ver q el estado del producto no sea disponible.
		// Cuando no es disponible lo seteo en disponible
		Producto productoBuscado = buscarProducto(nuevoProducto);
		if (elProductoEsAlquilable(productoBuscado)) {
			if (elProductoFueAlquilado(productoBuscado)) {
				productoBuscado.setEstadoActual(Estado.DISPONIBLE);
				// ahora nadie posee el producto
				productoBuscado.setQuienPoseeElProducto(null);
				return true;
			}

		}
		throw new ProductoNoAlquilable();
	}

	private Boolean elProductoFueAlquilado(Producto productoBuscado) {
		return productoBuscado.getEstadoActual().equals(Estado.ALQUILADO);
	}

	public TreeSet<Producto> obtenerLosProductosOrdenadosPorTipoAlfabeticamente() {
		TreeSet<Producto> productosOrdenados = new TreeSet<Producto>(new ProductosOrdenadosPorTipoAlfabeticamente());
		productosOrdenados.addAll(this.productos);
		return productosOrdenados;

	}

}
