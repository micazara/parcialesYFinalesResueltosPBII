package ar.edu.unlam.pb2.parcial1;

public interface Alquilable {
	Double getPrecioDeAlquiler();
	void setPrecioAlquiler(Double pRECIO_ALQUILER);
	Clasificacion getClasificacion();
	void setCalifiacion(Clasificacion calificacion);
}
