package ar.edu.unlam.pb2.parcial1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.TreeSet;

import org.junit.Test;

import ar.edu.unlam.pb2.parcial1.Alquilable;
import ar.edu.unlam.pb2.parcial1.Comestible;
import ar.edu.unlam.pb2.parcial1.Estado;
import ar.edu.unlam.pb2.parcial1.Genero;
import ar.edu.unlam.pb2.parcial1.Libro;
import ar.edu.unlam.pb2.parcial1.Pelicula;
import ar.edu.unlam.pb2.parcial1.TipoDeConsola;
import ar.edu.unlam.pb2.parcial1.Vendible;
import ar.edu.unlam.pb2.parcial1.Videoclub;
import ar.edu.unlam.pb2.parcial1.Videojuego;

public class PrimerParcial2021 {

//	@Test
//	public void queSePuedaCrearUnaPelicula() {
//		// Preparaci�n
//		final Integer CODIGO_ESPERADO = 1;
//		final String DESCRIPCION_ESPERADA = "Exterminators II";
//		final Genero GENERO_ESPERADO = Genero.ACCION;
//		final Integer ANO_DE_ESTRENO_ESPERADO = 1993;
//		final String DIRECTOR_ESPERADO = "Carlos Galettini";
//		final String ACTOR_1_ESPERADO = "Guillermo Francella";
//		final String ACTOR_2_ESPERADO = "Emilio Disi";
//		final Double PRECIO_VENTA_ESPERADO = 2500D;
//
//		// Ejecucion
//		Pelicula pelicula = new Pelicula(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, GENERO_ESPERADO,
//				ANO_DE_ESTRENO_ESPERADO, DIRECTOR_ESPERADO, PRECIO_VENTA_ESPERADO);
//		pelicula.agregarActor(ACTOR_1_ESPERADO);
//		pelicula.agregarActor(ACTOR_2_ESPERADO);
//
//		// Validaci�n
//		assertEquals(CODIGO_ESPERADO, pelicula.getCod());
//		assertEquals(DESCRIPCION_ESPERADA, pelicula.getDescripcion());
//		assertEquals(GENERO_ESPERADO, pelicula.getGenero());
//		assertEquals(ANO_DE_ESTRENO_ESPERADO, pelicula.getAnoEstreno());
//		assertEquals(DIRECTOR_ESPERADO, pelicula.getDirector());
//		assertTrue(pelicula.actua(ACTOR_1_ESPERADO));
//		assertEquals(PRECIO_VENTA_ESPERADO, pelicula.getPrecioDeVenta());
//
//	}

//	@Test
//	public void queSePuedaCrearUnVideojuego() {
//		// Preparaci�n
//		final Integer CODIGO_ESPERADO = 1;
//		final String DESCRIPCION_ESPERADA = "Fornite";
//		final TipoDeConsola CONSOLA_ESPERADA = TipoDeConsola.PLAY_STATION;
//
//		// Ejecucion
//		Videojuego juego = new Videojuego(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, CONSOLA_ESPERADA);
//
//		// Validaci�n
//		assertEquals(CODIGO_ESPERADO, juego.getCod());
//		assertEquals(DESCRIPCION_ESPERADA, juego.getDescripcion());
//		assertEquals(CONSOLA_ESPERADA, juego.getTipo());
//
//	}

//	@Test
//	public void queSePuedaCrearUnLibro() {
//		// Preparaci�n
//		final Integer CODIGO_ESPERADO = 1;
//		final String DESCRIPCION_ESPERADA = "Fifty Shades of Grey";
//		final String AUTOR_ESPERADO = "E. L. James";
//		final String EDITORIAL_ESPERADA = "Vintage Books";
//
//		// Ejecucion
//		Libro libro = new Libro(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, AUTOR_ESPERADO, EDITORIAL_ESPERADA);
//
//		// Validaci�n
//		assertEquals(CODIGO_ESPERADO, libro.getCod());
//		assertEquals(DESCRIPCION_ESPERADA, libro.getDescripcion());
//		assertEquals(AUTOR_ESPERADO, libro.getAutor());
//		assertEquals(EDITORIAL_ESPERADA, libro.getEditorial());
//
//	}

//	@Test
//	public void queSePuedaCrearUnComestible() {
//		// Preparaci�n
//		final Integer CODIGO_ESPERADO = 1;
//		final String DESCRIPCION_ESPERADA = "Chomps";
//
//		// Ejecucion
//		Comestible comestible = new Comestible(CODIGO_ESPERADO, DESCRIPCION_ESPERADA);
//
//		// Validaci�n
//		assertEquals(CODIGO_ESPERADO, comestible.getCod());
//		assertEquals(DESCRIPCION_ESPERADA, comestible.getDescripcion());
//	}

//	@Test
//	public void queUnaPeliculaSeaVendible() {
//		// Preparacion
//		final Integer CODIGO_ESPERADO = 1;
//		final String DESCRIPCION_ESPERADA = "Exterminators II";
//		final Genero GENERO_ESPERADO = Genero.ACCION;
//		final Integer ANO_DE_ESTRENO_ESPERADO = 1993;
//		final String DIRECTOR_ESPERADO = "Carlos Galettini";
//		final Double PRECIO_VENTA = 5000.0;
//
//		// Ejecucion
//		Vendible pelicula = new Pelicula(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, GENERO_ESPERADO,
//				ANO_DE_ESTRENO_ESPERADO, DIRECTOR_ESPERADO, PRECIO_VENTA);
//		pelicula.setPrecioVenta(PRECIO_VENTA);
//
//		// Validaci�n
//		assertEquals(PRECIO_VENTA, pelicula.getPrecioDeVenta());
//	}

	@Test
	public void queUnJuegoSeaAlquilable() {
		// Preparaci�n
		final Integer CODIGO_ESPERADO = 1;
		final String DESCRIPCION_ESPERADA = "Fornite";
		final TipoDeConsola CONSOLA_ESPERADA = TipoDeConsola.PLAY_STATION;
		final Double PRECIO_ALQUILER = 500.0;
		final Estado ESTADO_ESPERADO = Estado.DISPONIBLE;

		// Ejecucion
		Alquilable juego = new Videojuego(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, ESTADO_ESPERADO, CONSOLA_ESPERADA,
				PRECIO_ALQUILER, Clasificacion.ATP);
		juego.setPrecioAlquiler(PRECIO_ALQUILER);

		// Validaci�n
		assertEquals(PRECIO_ALQUILER, juego.getPrecioDeAlquiler());
	}

	@Test
	public void queSePuedaCrearUnCliente() {
		// Preparaci�n
		final Integer CODIGO_ESPERADO = 1;
		final String NOMBRE_ESPERADO = "Camila";
		final String APELLIDO_ESPERADO = "Oculto";
		final Integer EDAD_ESPERADA = 23;

		// Ejecucion
		Cliente nuevoCliente = new Cliente(CODIGO_ESPERADO, APELLIDO_ESPERADO, NOMBRE_ESPERADO, EDAD_ESPERADA);

		// Validaci�n
		assertEquals(CODIGO_ESPERADO, nuevoCliente.getCodigo());
		assertEquals(NOMBRE_ESPERADO, nuevoCliente.getNombre());
		assertEquals(APELLIDO_ESPERADO, nuevoCliente.getApellido());
		assertEquals(EDAD_ESPERADA, nuevoCliente.getEdad());

	}

	@Test
	public void queSePuedaVenderUnLibro() throws ProductoNoEncontrado, NoSePudoAgregarElProducto,
			NoSePudoAgregarElCliente, NoSeEncontroElCliente, ProductoNoVendible, ProductoNoDisponible {
		// Preparaci�n
		final Integer CODIGO_ESPERADO = 1;
		final String DESCRIPCION_ESPERADA = "Fifty Shades of Grey";
		final String AUTOR_ESPERADO = "E. L. James";
		final String EDITORIAL_ESPERADA = "Vintage Books";
		final String NOMBRE_VIDEOCLUB = "Blockbuster";
		final Integer CODIGO_CLIENTE_ESPERADO = 1;
		final String NOMBRE_ESPERADO = "Camila";
		final String APELLIDO_ESPERADO = "Privado";
		final Integer EDAD_ESPERADA = 23;
		final Estado ESTADO_INICIAL_ESPERADO = Estado.DISPONIBLE;
		final Estado ESTADO_FINAL_ESPERADO = Estado.VENDIDO;

		// Ejecucion
		Videoclub video = new Videoclub(NOMBRE_VIDEOCLUB);
		Producto nuevoProducto = new Libro(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, ESTADO_INICIAL_ESPERADO,
				AUTOR_ESPERADO, EDITORIAL_ESPERADA);
		Cliente nuevoCliente = new Cliente(CODIGO_ESPERADO, APELLIDO_ESPERADO, NOMBRE_ESPERADO, EDAD_ESPERADA);

		video.agregarProducto(nuevoProducto);
		video.agregarCliente(nuevoCliente);

		// Validaci�n
		assertEquals(ESTADO_INICIAL_ESPERADO, video.buscarProducto(nuevoProducto).getEstadoActual());
		assertTrue(video.vender(nuevoProducto, nuevoCliente));
		assertEquals(NOMBRE_ESPERADO, video.buscarProducto(nuevoProducto).getQuienPoseeElProducto().getNombre());
		assertEquals(ESTADO_FINAL_ESPERADO, video.buscarProducto(nuevoProducto).getEstadoActual());
	}

	@Test
	public void queSePuedaAlquilarUnaPelicula()
			throws NoSePudoAgregarElProducto, NoSePudoAgregarElCliente, ProductoNoEncontrado, NoSeEncontroElCliente,
			ProductoNoAlquilable, ProductoNoDisponible, NoSeLePuedeAlquilarUnaPeliculaMayorA18AUnMenor {
		// Preparaci�n
		final Integer CODIGO_ESPERADO = 1;
		final String DESCRIPCION_ESPERADA = "El Cisne Negro";
		final Genero GENERO_ESPERADO = Genero.SUSPENSO;
		final Integer ANO_DE_ESTRENO_ESPERADO = 2010;
		final String DIRECTOR_ESPERADO = "Darren Aronofsky";
		final String ACTOR_1_ESPERADO = "Natalie Portman";
		final String NOMBRE_VIDEOCLUB = "Blockbuster";
		final Integer CODIGO_CLIENTE_ESPERADO = 1;
		final String NOMBRE_ESPERADO = "Camila";
		final String APELLIDO_ESPERADO = "Privado";
		final Integer EDAD_ESPERADA = 23;
		final Estado ESTADO_INICIAL_ESPERADO = Estado.DISPONIBLE;
		final Estado ESTADO_FINAL_ESPERADO = Estado.ALQUILADO;

		// Ejecucion
		Videoclub video = new Videoclub(NOMBRE_VIDEOCLUB);
		Producto nuevoProducto = new Pelicula(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, ESTADO_INICIAL_ESPERADO,
				GENERO_ESPERADO, ANO_DE_ESTRENO_ESPERADO, DIRECTOR_ESPERADO, 200d, Clasificacion.ATP);
		Cliente nuevoCliente = new Cliente(CODIGO_ESPERADO, APELLIDO_ESPERADO, NOMBRE_ESPERADO, EDAD_ESPERADA);

		video.agregarProducto(nuevoProducto);
		video.agregarCliente(nuevoCliente);

		// Validaci�n
		assertEquals(ESTADO_INICIAL_ESPERADO, video.buscarProducto(nuevoProducto).getEstadoActual());
		assertTrue(video.alquilar(nuevoProducto, nuevoCliente));
		assertEquals(NOMBRE_ESPERADO, video.buscarProducto(nuevoProducto).getQuienPoseeElProducto().getNombre());
		assertEquals(ESTADO_FINAL_ESPERADO, video.buscarProducto(nuevoProducto).getEstadoActual());
	}

	@Test(expected = ProductoNoDisponible.class)
	public void queSeNoSePuedaVenderUnComestibleVendido() throws NoSePudoAgregarElCliente, NoSePudoAgregarElProducto,
			ProductoNoEncontrado, NoSeEncontroElCliente, ProductoNoVendible, ProductoNoDisponible {
		// Preparaci�n
		final Integer CODIGO_ESPERADO = 1;
		final String DESCRIPCION_ESPERADA = "Chomps";
		final String NOMBRE_VIDEOCLUB = "Blockbuster";
		final Integer CODIGO_CLIENTE_ESPERADO = 1;
		final String NOMBRE_ESPERADO = "Camila";
		final String APELLIDO_ESPERADO = "Privado";
		final Integer EDAD_ESPERADA = 23;
		final Estado ESTADO_INICIAL_ESPERADO = Estado.DISPONIBLE;
		final Estado ESTADO_FINAL_ESPERADO = Estado.VENDIDO;
		// Ejecucion

		// tengo que vender un comestible y que cuando lo quiera volver a vender no se
		// pueda.

		Producto comestible = new Comestible(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, ESTADO_INICIAL_ESPERADO);
		Videoclub video = new Videoclub(NOMBRE_VIDEOCLUB);
		Cliente nuevoCliente = new Cliente(CODIGO_ESPERADO, APELLIDO_ESPERADO, NOMBRE_ESPERADO, EDAD_ESPERADA);

		video.agregarCliente(nuevoCliente);
		video.agregarProducto(comestible);

		// Validaci�n
		video.vender(comestible, nuevoCliente);
		video.vender(comestible, nuevoCliente);
	}

	@Test(expected = ProductoNoDisponible.class)
	public void queSeNoSePuedaAlquilarUnJuegoAlquilado()
			throws NoSeEncontroElCliente, ProductoNoEncontrado, ProductoNoAlquilable, ProductoNoDisponible,
			NoSePudoAgregarElCliente, NoSePudoAgregarElProducto, NoSeLePuedeAlquilarUnaPeliculaMayorA18AUnMenor {
		// Preparaci�n
		final Integer CODIGO_ESPERADO = 1;
		final String DESCRIPCION_ESPERADA = "Fornite";
		final TipoDeConsola CONSOLA_ESPERADA = TipoDeConsola.PLAY_STATION;
		final Double PRECIO_ALQUILER = 500.0;
		final Estado ESTADO_ESPERADO = Estado.DISPONIBLE;
		Clasificacion CLASIFICACION_ESPERADA = Clasificacion.ATP;

		final String NOMBRE_VIDEOCLUB = "Blockbuster";

		final Integer CODIGO_CLIENTE_ESPERADO = 1;
		final String NOMBRE_ESPERADO = "Camila";
		final String APELLIDO_ESPERADO = "Privado";
		final Integer EDAD_ESPERADA = 23;

		// Ejecucion
		Producto juego = new Videojuego(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, ESTADO_ESPERADO, CONSOLA_ESPERADA,
				PRECIO_ALQUILER, CLASIFICACION_ESPERADA);
		Videoclub video = new Videoclub(NOMBRE_VIDEOCLUB);
		Cliente nuevoCliente = new Cliente(CODIGO_ESPERADO, APELLIDO_ESPERADO, NOMBRE_ESPERADO, EDAD_ESPERADA);

		video.agregarCliente(nuevoCliente);
		video.agregarProducto(juego);

		// Validaci�n
		video.alquilar(juego, nuevoCliente);
		video.alquilar(juego, nuevoCliente);
	}

	@Test
	public void queLuegoDeDevueltaUnaPeliculaSePuedaAlquilar()
			throws NoSePudoAgregarElProducto, NoSePudoAgregarElCliente, NoSeEncontroElCliente, ProductoNoEncontrado,
			ProductoNoAlquilable, ProductoNoDisponible, NoSeLePuedeAlquilarUnaPeliculaMayorA18AUnMenor {
		// alquilar peli y despues devolverla
		// Preparaci�n
		final Integer CODIGO_ESPERADO = 1;
		final String DESCRIPCION_ESPERADA = "El Cisne Negro";
		final Genero GENERO_ESPERADO = Genero.SUSPENSO;
		final Integer ANO_DE_ESTRENO_ESPERADO = 2010;
		final String DIRECTOR_ESPERADO = "Darren Aronofsky";
		final String ACTOR_1_ESPERADO = "Natalie Portman";
		final String NOMBRE_VIDEOCLUB = "Blockbuster";
		final Integer CODIGO_CLIENTE_ESPERADO = 1;
		final String NOMBRE_ESPERADO = "Camila";
		final String APELLIDO_ESPERADO = "Privado";
		final Integer EDAD_ESPERADA = 23;
		final Estado ESTADO_FINAL_ESPERADO = Estado.ALQUILADO;

		// Ejecucion
		Videoclub video = new Videoclub(NOMBRE_VIDEOCLUB);
		Producto nuevoProducto = new Pelicula(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, Estado.DISPONIBLE, GENERO_ESPERADO,
				ANO_DE_ESTRENO_ESPERADO, DIRECTOR_ESPERADO, 200d, Clasificacion.ATP);
		Cliente nuevoCliente = new Cliente(CODIGO_ESPERADO, APELLIDO_ESPERADO, NOMBRE_ESPERADO, EDAD_ESPERADA);

		video.agregarProducto(nuevoProducto);
		video.agregarCliente(nuevoCliente);

		video.alquilar(nuevoProducto, nuevoCliente);
		video.devolver(nuevoProducto, nuevoCliente);
		Boolean resultado = video.alquilar(nuevoProducto, nuevoCliente);

		assertTrue(video.buscarProducto(nuevoProducto).getEstadoActual().equals(ESTADO_FINAL_ESPERADO));
		assertTrue(resultado);
		assertEquals(NOMBRE_ESPERADO, video.buscarProducto(nuevoProducto).getQuienPoseeElProducto().getNombre());

	}

	@Test(expected = NoSeLePuedeAlquilarUnaPeliculaMayorA18AUnMenor.class)
	public void queSeNoSePuedaAlquilarUnPeliculaAUnMenor()
			throws NoSePudoAgregarElProducto, NoSePudoAgregarElCliente, NoSeEncontroElCliente, ProductoNoEncontrado,
			ProductoNoAlquilable, ProductoNoDisponible, NoSeLePuedeAlquilarUnaPeliculaMayorA18AUnMenor {
		// Preparaci�n
		final Integer CODIGO_ESPERADO = 1;
		final String DESCRIPCION_ESPERADA = "El Cisne Negro";
		final Genero GENERO_ESPERADO = Genero.SUSPENSO;
		final Integer ANO_DE_ESTRENO_ESPERADO = 2010;
		final String DIRECTOR_ESPERADO = "Darren Aronofsky";
		final String ACTOR_1_ESPERADO = "Natalie Portman";
		final String NOMBRE_VIDEOCLUB = "Blockbuster";
		final Integer CODIGO_CLIENTE_ESPERADO = 1;
		final String NOMBRE_ESPERADO = "Camila";
		final String APELLIDO_ESPERADO = "Privado";
		final Integer EDAD_ESPERADA = 15;
		final Estado ESTADO_INICIAL_ESPERADO = Estado.DISPONIBLE;
		final Estado ESTADO_FINAL_ESPERADO = Estado.ALQUILADO;

		// Ejecucion
		Videoclub video = new Videoclub(NOMBRE_VIDEOCLUB);
		Producto nuevoProducto = new Pelicula(CODIGO_ESPERADO, DESCRIPCION_ESPERADA, ESTADO_INICIAL_ESPERADO,
				GENERO_ESPERADO, ANO_DE_ESTRENO_ESPERADO, DIRECTOR_ESPERADO, 200d, Clasificacion.MayorA18);
		Cliente nuevoCliente = new Cliente(CODIGO_ESPERADO, APELLIDO_ESPERADO, NOMBRE_ESPERADO, EDAD_ESPERADA);

		video.agregarProducto(nuevoProducto);
		video.agregarCliente(nuevoCliente);

		video.alquilar(nuevoProducto, nuevoCliente);
	}

	@Test
	public void queSePuedaObtenerLosProductosOrdenadosPorTipoAlfabeticamente() throws NoSePudoAgregarElProducto {
		final String NOMBRE_VIDEOCLUB = "Blockbuster";
		Videoclub video = new Videoclub(NOMBRE_VIDEOCLUB);

		Producto peli = new Pelicula(1, "La La Land", Estado.DISPONIBLE, Genero.COMEDIA, 2016, "Yo", 2500d,
				Clasificacion.ATP);
		Producto juego = new Videojuego(2, "Los Sims 4", Estado.DISPONIBLE, TipoDeConsola.PC, 1651651651651d,
				Clasificacion.MayorA18);
		Producto libro = new Libro(3, "FNAF: Toy Chica", Estado.DISPONIBLE, "Deimoss", "Deimoss Producciones");
		Producto manzana = new Comestible(4, "Manzana", Estado.DISPONIBLE);

		video.agregarProducto(peli);
		video.agregarProducto(juego);
		video.agregarProducto(libro);
		video.agregarProducto(manzana);

		/*
		 * c l p v
		 */

		TreeSet<Producto> productosOrdenados = video.obtenerLosProductosOrdenadosPorTipoAlfabeticamente();
		Producto primerProductoActual = productosOrdenados.first();
		Producto ultimoProductoActual = productosOrdenados.last();

		assertEquals(manzana, primerProductoActual);
		assertEquals(juego, ultimoProductoActual);
		assertEquals(4, productosOrdenados.size());
	}

}
