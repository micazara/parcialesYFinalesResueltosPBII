package ar.edu.unlam.pb2;

public class Caramelo extends Agrandador {

	public Caramelo(String nombre, Integer id, Double precio) {
		super(nombre, id, precio);
		// TODO Auto-generated constructor stub
	}

}
