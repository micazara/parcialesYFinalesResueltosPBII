package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

public class TestCases {

	/*
	 * 1) Que, al comprar un alimento, se descuente el dinero disponible 2) Que no
	 * se exceda del dinero disponible 3) Que, al consumir un alimento, verificar
	 * que se agrande 4) Que al consumir un alimento verificar que se encoja 5) Que
	 * al consumir alimentos verificar que no se pueda agrandar más de 280cm 6) Que
	 * al consumir alimentos verificar que no se pueda achicar menos de 50cm 7)
	 * Verificar que la colección de alimentos quede ordenada por nombre de manera
	 * descendente
	 */

	@Test
	public void queAlComprarUnAlimentoSeDescuenteElDineroDisponible() throws DineroInsuficiente {
		Double dinero = 500d;
		Alicia alicia = new Alicia("Alicia", dinero, 20, 180d, 50d);

		Supermercado mercado = new Supermercado("El chino");
		Achicador masita = new Masita("Masita", 1, 50d);
		Achicador alfajor = new Alfajor("Jorgito", 2, 100d);
		mercado.agregarAlimentoAchicador(masita);
		mercado.agregarAlimentoAchicador(alfajor);

		mercado.comprar(alicia, masita);
		mercado.comprar(alicia, alfajor);
		Double dineroActual = alicia.getDinero();
		Double dineroEsperado = 350d;

		assertEquals(dineroEsperado, dineroActual);
	}

	@Test
	public void queNoSeExcedaDelDineroDisponible() throws DineroInsuficiente {
		Double dinero = 500d;
		Alicia alicia = new Alicia("Alicia", dinero, 20, 180d, 50d);

		Supermercado mercado = new Supermercado("El chino");
		Achicador masita = new Masita("Masita", 1, 50d);
		Achicador alfajor = new Alfajor("Jorgito", 2, 100d);
		mercado.agregarAlimentoAchicador(masita);
		mercado.agregarAlimentoAchicador(alfajor);

		mercado.comprar(alicia, masita);
		mercado.comprar(alicia, alfajor);

		Double dineroActual = alicia.getDinero();
		Double dineroEsperado = 350d;

		assertEquals(dineroEsperado, dineroActual);
		// si estan en su inventario quiere decir que los compro, entonces, que no se
		// excedio
		assertTrue(alicia.getInventario().contains(masita));
		assertTrue(alicia.getInventario().contains(alfajor));
	}

	@Test
	public void queAlConsumirUnAlimentoVerificarQueSeAgrande()
			throws DineroInsuficiente, AlimentoInexistenteEnElInventario, AlturaMaximaSuperada, AlturaMinimaSuperada {
		Double dinero = 500d;
		Alicia alicia = new Alicia("Alicia", dinero, 20, 180d, 50d);

		Supermercado mercado = new Supermercado("El chino");
		Agrandador gomita = new Gomita("Gomita", 1, 150d);
		mercado.agregarAlimentoAgrandador(gomita);

		mercado.comprar(alicia, gomita);

		alicia.consumirAlimento(gomita);

		Double alturaActual = alicia.getAltura();
		Double alturaEsperada = 230d;

		assertEquals(alturaEsperada, alturaActual);
	}

	@Test
	public void queAlConsumirUnAlimentoVerificarQueSeEncoja()
			throws DineroInsuficiente, AlimentoInexistenteEnElInventario, AlturaMaximaSuperada, AlturaMinimaSuperada {
		Double dinero = 500d;
		Alicia alicia = new Alicia("Alicia", dinero, 20, 180d, 50d);

		Supermercado mercado = new Supermercado("El chino");
		Achicador alfajor = new Alfajor("Jorgito", 1, 100d);
		mercado.agregarAlimentoAchicador(alfajor);

		mercado.comprar(alicia, alfajor);

		alicia.consumirAlimento(alfajor);

		Double alturaActual = alicia.getAltura();
		Double alturaEsperada = 130d;

		assertEquals(alturaEsperada, alturaActual);
	}

	// Que al consumir alimentos verificar que no se pueda agrandar más de 280cm
	@Test(expected = AlturaMaximaSuperada.class)
	public void queAlConsumiAlimentoVerificarQueNoSePuedaAgrandaMasDe280Cm()
			throws AlimentoInexistenteEnElInventario, DineroInsuficiente, AlturaMaximaSuperada, AlturaMinimaSuperada {
		Double dinero = 25500d;
		Alicia alicia = new Alicia("Alicia", dinero, 20, 180d, 50d);

		Supermercado mercado = new Supermercado("El chino");
		Agrandador gomita = new Gomita("Gomita", 1, 150d);
		Agrandador caramelo = new Caramelo("Caramelo", 2, 100d);
		Agrandador bocaditoDeChocolate = new BocaditoDeChocolate("BocoChoco", 3, 200d);
		Agrandador mogul = new Gomita("Mogul", 4, 150d);
		Agrandador carameloDeMiel = new Caramelo("Caramelo de Miel", 5, 100d);
		Agrandador gomitasAcidas = new Gomita("Gomitas Acidas", 6, 150d);
		mercado.agregarAlimentoAgrandador(gomita);
		mercado.agregarAlimentoAgrandador(caramelo);
		mercado.agregarAlimentoAgrandador(bocaditoDeChocolate);
		mercado.agregarAlimentoAgrandador(mogul);
		mercado.agregarAlimentoAgrandador(carameloDeMiel);

		mercado.comprar(alicia, gomita);
		mercado.comprar(alicia, caramelo);
		mercado.comprar(alicia, bocaditoDeChocolate);
		mercado.comprar(alicia, mogul);
		mercado.comprar(alicia, carameloDeMiel);

		alicia.consumirAlimento(gomita);
		alicia.consumirAlimento(caramelo);
		alicia.consumirAlimento(bocaditoDeChocolate);
		alicia.consumirAlimento(mogul);
		alicia.consumirAlimento(carameloDeMiel);
		alicia.consumirAlimento(gomitasAcidas);
		// en total todos estos agrandarian la altura de alicia hasta 430.
	}

	@Test(expected = AlturaMinimaSuperada.class)
	public void queAlConsumirAlimentosVerificarQueNoSePuedaAchicarMenosDe50Cm()
			throws DineroInsuficiente, AlimentoInexistenteEnElInventario, AlturaMaximaSuperada, AlturaMinimaSuperada {
		Double dinero = 500d;
		Alicia alicia = new Alicia("Alicia", dinero, 20, 180d, 50d);

		Supermercado mercado = new Supermercado("El chino");
		Achicador masita = new Masita("Masita", 1, 50d);
		Achicador alfajor = new Alfajor("Jorgito", 2, 100d);
		Achicador bagel = new Bagel("Bagel", 3, 50d);
		mercado.agregarAlimentoAchicador(masita);
		mercado.agregarAlimentoAchicador(alfajor);
		mercado.agregarAlimentoAchicador(bagel);

		mercado.comprar(alicia, masita);
		mercado.comprar(alicia, alfajor);
		mercado.comprar(alicia, bagel);

		alicia.consumirAlimento(masita);
		alicia.consumirAlimento(alfajor);
		alicia.consumirAlimento(bagel);
	}

	// Verificar que la colección de alimentos quede ordenada por nombre de manera
	// descendente
	@Test
	public void queLaColeccionDeAlimentosQuedeOrdenadaPorNombreDeManeraDescendente() {
		Supermercado mercado = new Supermercado("El chino");
		Achicador masita = new Masita("Masita", 1, 50d);
		Achicador alfajor = new Alfajor("Jorgito", 2, 100d);
		Achicador bagel = new Bagel("Bagel", 3, 50d);
		mercado.agregarAlimentoAchicador(masita);
		mercado.agregarAlimentoAchicador(alfajor);
		mercado.agregarAlimentoAchicador(bagel);
		TreeSet<Achicador> achicadoresOrdenados = mercado.obtenerAchicadoresOrdenados();
		Achicador primerAchicadorActual = achicadoresOrdenados.first();
		Achicador ultimoAchicadorActual = achicadoresOrdenados.last();
		assertEquals(masita, primerAchicadorActual);
		assertEquals(bagel, ultimoAchicadorActual);
	}
}
