package ar.edu.unlam.pb2;

import java.util.Objects;

public class Alimento {

	public String nombre;
	public Integer id;
	public Double precio;

	public Alimento(String nombre, Integer id, Double precio) {
		this.nombre = nombre;
		this.id = id;
		this.precio = precio;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Alimento other = (Alimento) obj;
		return Objects.equals(id, other.id);
	}

	Integer getId() {
		return id;
	}

	void setId(Integer id) {
		this.id = id;
	}

	Double getPrecio() {
		return precio;
	}

	void setPrecio(Double precio) {
		this.precio = precio;
	}

}
