package ar.edu.unlam.pb2;

public class Agrandador extends Alimento {
	
	private final Double parametroParaAgrandar;

	public Agrandador(String nombre, Integer id, Double precio) {
		super(nombre, id, precio);
		this.parametroParaAgrandar = 40d;

	}

	public Double agrandar(Double alturaDeAlicia) {
		alturaDeAlicia += this.parametroParaAgrandar;
		return alturaDeAlicia;
	}

	Double getParametroParaAgrandar() {
		return parametroParaAgrandar;
	}
	
	

	
}
