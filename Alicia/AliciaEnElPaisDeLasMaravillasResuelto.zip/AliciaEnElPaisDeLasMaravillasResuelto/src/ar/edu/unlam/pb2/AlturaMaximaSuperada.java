package ar.edu.unlam.pb2;

public class AlturaMaximaSuperada extends Exception {

}
