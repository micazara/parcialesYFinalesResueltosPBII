package ar.edu.unlam.pb2;

public class Bagel extends Achicador {

	public Bagel(String nombre, Integer id, Double precio) {
		super(nombre, id, precio);
		// TODO Auto-generated constructor stub
	}

}
