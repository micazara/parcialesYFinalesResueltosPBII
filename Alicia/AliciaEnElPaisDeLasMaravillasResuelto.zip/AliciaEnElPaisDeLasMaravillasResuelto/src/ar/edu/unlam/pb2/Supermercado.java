package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Supermercado {

	private Set<Achicador> alimentosAchicadores;
	private Set<Agrandador> alimentosAgrandadores;
	private String nombre;

	public Supermercado(String nombre) {
		this.alimentosAchicadores = new TreeSet<Achicador>(new OrdenPorNombre());
		this.alimentosAgrandadores = new HashSet<Agrandador>();
		this.nombre = nombre;
	}

	Set<Achicador> getAlimentosAchicadores() {
		return alimentosAchicadores;
	}

	public TreeSet<Achicador> obtenerAchicadoresOrdenados() {
		TreeSet<Achicador> achicadoresOrdenados = new TreeSet<Achicador>(new OrdenPorNombre());
		achicadoresOrdenados.addAll(this.alimentosAchicadores);
		return achicadoresOrdenados;
	}

	void setAlimentosAchicadores(Set<Achicador> alimentosAchicadores) {
		this.alimentosAchicadores = alimentosAchicadores;
	}

	Set<Agrandador> getAlimentosAgrandadores() {
		return alimentosAgrandadores;
	}

	void setAlimentosAgrandadores(Set<Agrandador> alimentosAgrandadores) {
		this.alimentosAgrandadores = alimentosAgrandadores;
	}

	public void agregarAlimentoAchicador(Alimento achicador) {
		if (achicador instanceof Achicador) {
			this.alimentosAchicadores.add((Achicador) achicador);

		}
	}

	public void comprar(Alicia alicia, Alimento aComprar) throws DineroInsuficiente {
		// si la masita esta en el super la puede comprar
		if (this.alimentosAchicadores.contains(aComprar) || this.alimentosAgrandadores.contains(aComprar)) {
			// verificar que el precio del alimento no sea mayor al dinero de alicia
			if (aComprar.getPrecio() > alicia.getDinero()) {
				throw new DineroInsuficiente();
			} else {
				// alicia realiza la compra
				// lo que compra se guarda en su inventario que son los alimentos disponibles
				// para comer
				alicia.comprar(aComprar);
				alicia.actualizarDineroDespuesDeComprar(aComprar.getPrecio());
			}
		}

	}

	public void agregarAlimentoAgrandador(Alimento agrandador) {
		if (agrandador instanceof Agrandador) {
			this.alimentosAgrandadores.add((Agrandador) agrandador);
		}
	}

	public Integer obtenerCantidadDeAgrandadores() {
		return this.alimentosAgrandadores.size();
	}

}
