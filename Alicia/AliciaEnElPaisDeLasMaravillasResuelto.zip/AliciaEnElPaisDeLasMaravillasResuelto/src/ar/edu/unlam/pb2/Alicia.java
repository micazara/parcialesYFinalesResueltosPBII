package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Set;

public class Alicia {

	private String nombre;
	private Double dinero;
	private Integer edad;
	private Double altura;
	private Double peso;
	private Set<Alimento> inventario;
	private Double alturaMaxima;
	private Double alturaMinima;

	public Alicia(String nombre, Double dinero, Integer edad, Double altura, Double peso) {
		this.nombre = nombre;
		this.dinero = dinero;
		this.edad = edad;
		this.altura = altura;
		this.peso = peso;
		this.inventario = new HashSet<Alimento>();
		this.alturaMaxima = 280d;
		this.alturaMinima = 50d;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Double getDinero() {
		return dinero;
	}

	void setDinero(Double dinero) {
		this.dinero = dinero;
	}

	Integer getEdad() {
		return edad;
	}

	void setEdad(Integer edad) {
		this.edad = edad;
	}

	Double getAltura() {
		return altura;
	}

	void setAltura(Double altura) {
		this.altura = altura;
	}

	Double getPeso() {
		return peso;
	}

	void setPeso(Double peso) {
		this.peso = peso;
	}

	Set<Alimento> getInventario() {
		return inventario;
	}

	void setInventario(Set<Alimento> inventario) {
		this.inventario = inventario;
	}

	public void consumirAlimento(Alimento aConsumir)
			throws AlimentoInexistenteEnElInventario, AlturaMaximaSuperada, AlturaMinimaSuperada {
		Alimento buscado = buscarAlimento(aConsumir);
		if (buscado instanceof Achicador) {
			if ((this.altura - ((Achicador) buscado).getParametroParaAchicar()) >= this.alturaMinima) {
				this.altura = ((Achicador) buscado).achicar(this.altura);
				actualizarInventario(buscado);
			} else if ((this.altura - ((Achicador) buscado).getParametroParaAchicar()) < this.alturaMinima) {
				throw new AlturaMinimaSuperada();
			}

		} else if (buscado instanceof Agrandador) {
			if (this.altura + ((Agrandador) buscado).getParametroParaAgrandar() <= 280) {
				this.altura = ((Agrandador) buscado).agrandar(altura);
				actualizarInventario(buscado);
			} else if (this.altura + ((Agrandador) buscado).getParametroParaAgrandar() > 280) {
				throw new AlturaMaximaSuperada();
			}

		}
	}

	private void actualizarInventario(Alimento buscado) {
		this.inventario.remove(buscado);
	}

	private Alimento buscarAlimento(Alimento aConsumir) throws AlimentoInexistenteEnElInventario {
		for (Alimento actual : this.inventario) {
			if (actual.getId().equals(aConsumir.getId())) {
				return actual;
			}
		}

		throw new AlimentoInexistenteEnElInventario();
	}

	public void comprar(Alimento alimento) {
		this.inventario.add(alimento);
	}

	public Integer obtenerCantidadDeAlimentosEnElInventarioDeAlicia() {

		return this.inventario.size();
	}

	public void actualizarDineroDespuesDeComprar(Double montoADescontar) {
		this.dinero -= montoADescontar;

	}

}
