package ar.edu.unlam.pb2;

public class Achicador extends Alimento {

	private final Double parametroParaAchicar;

	public Achicador(String nombre, Integer id, Double precio) {
		super(nombre, id, precio);
		this.parametroParaAchicar = 50d;
	}

	public Double achicar(Double alturaDeAlicia) {
		alturaDeAlicia -= this.parametroParaAchicar;
		return alturaDeAlicia;
	}

	Double getParametroParaAchicar() {
		return parametroParaAchicar;
	}

}
