package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCases {

	/*
	 * queSePuedanAlmacenarLosDistintosTiposDeTransacciones LISTO
	 * queSePuedanAlmacenarLosDistintosTiposDePersonas listo
	 * queSePuedanAsociadACadaPersonaSusMedios listo 
	 * queSePuedanRealizarCompras listo 
	 * queSePuedanRealizarTransferencias listo
	 * queSeLanceUnaExcepcionSiElSaldoDeLaTarjetaEsInsuficienteParaHacerUnaCompra listo
	 * queSeLanceUnaExcepcionSiElSaldoDeLaCuentaVirtualEsInsuficienteParaHacerUnaCompra LISTO
	 * queSeLanceUnaExcepcionSiElLimiteDeCompraDeLaTarjetaEsInsuficienteParaHacerUnaCompra LISTO
	 * queSeLanceUnaExcepcionSiElSaldoDeLaCuentaEsInsuficienteParaHacerUnaTransferencia LISTO
	 * queDesdeUnaCuentaCorrienteSePuedaRealizarUnaTransferenciaPorEncimaDeSuSaldo
	 * 
	 */

//	@Test
//	public void queSePuedanAlmacenarLosDistintosTiposDeTransacciones() {
//		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");
//
//		Persona vendedor = new PersonaJuridica("Mica", 132465789l);
//		Persona comprador = new PersonaFisica("Franco", 99999999l);
//
//		Transaccion compra = new Compra(20.0, vendedor, comprador, "celu");
//		Transaccion transferencia = new Compra(20.0, vendedor, comprador, "celu");
//
//		billetera.guardarTransacciones(compra);
//		billetera.guardarTransacciones(transferencia);
//
//		Integer cantidadDeTransaccionesActual = billetera.obtenerCantidadDeTransaccionesGuardadas();
//		Integer cantidadDeTransaccionesEsperada = 2;
//
//		assertEquals(cantidadDeTransaccionesEsperada, cantidadDeTransaccionesActual);
//
//		Transaccion transaccionActual = billetera.getTransacciones().get(0);
//		assertEquals(compra, transaccionActual);
//	}
//
//	@Test
//	public void queSePuedanAlmacenarLosDistintosTiposDePersonas() {
//		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");
//
//		Medio cuentaBancaria = new CuentaBancaria();
//
//		Persona vendedor = new PersonaJuridica("Mica", 132465789l);
//		Persona comprador = new PersonaFisica("Franco", 99999999l);
//
//		billetera.agregarPersonaJuridica((PersonaJuridica) vendedor);
//		billetera.agregarPersonaFisica((PersonaFisica) comprador);
//
//		Integer cantidadActualDePersonasJuridicas = billetera.obtenerCantidadDePersonasJuridicas();
//		Integer cantidadActualDePersonasFisicas = billetera.obtenerCantidadDePersonasFisicas();
//
//		Integer cantidadEsperadaDePersonasJuridicas = 1;
//		Integer cantidadEsperadaDePersonasFisicas = 1;
//
//		assertEquals(cantidadEsperadaDePersonasJuridicas, cantidadActualDePersonasJuridicas);
//		assertEquals(cantidadEsperadaDePersonasFisicas, cantidadActualDePersonasFisicas);
//	}
//
//	@Test
//	public void queSePuedanAsociadACadaPersonaSusMedios() {
//		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");
//
//		Persona vendedor = new PersonaJuridica("Mica", 132465789l);
//
//		billetera.agregarPersonaJuridica((PersonaJuridica) vendedor);
//
//		Medio medio = new TarjetaCredito();
//		vendedor.asociarMedio(medio);
//
//		assertEquals((Integer) 1, vendedor.obtenerCantidadDeMedios());
//	}

	@Test
	public void queSePuedanRealizarCompras() throws NoSeEncontroElMedio, PersonaJuridicaInexistente, MedioInexistente,
			SaldoInsuficienteException, TipoDeOperacionIncompatible, ExcedeLimitDeCompraException {
		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");

		Persona vendedor = new PersonaJuridica("Mica", 132465789l);

		billetera.agregarPersonaJuridica((PersonaJuridica) vendedor);

		Medio medio = new TarjetaCredito("21321312", 200d);

		billetera.agregarMedio(medio);

		billetera.asociarMedioAUnaPersonaJuridica((PersonaJuridica) vendedor, medio);

		Double monto = 150d;
		billetera.realizarCompra(vendedor, medio, monto);

		Medio medioActual = vendedor.buscarMedio(medio);
		Medio medioEsperado = medio;

//		me fijo que en el historial de la tarjeta de credito se haya guardado la compra correctamente
		Integer cantidadDeComprasRealizadasActual = ((TarjetaCredito) medioActual).obtenerCantidadDeComprasRealizadas();
		Integer cantidadDeComprasRealizadasEsperada = 1;
		assertEquals(cantidadDeComprasRealizadasEsperada, cantidadDeComprasRealizadasActual);
		// me fijo que el medio que se guardo en el vendedor sea el mismo q agregue a la
		// billetera
		assertEquals(medioEsperado, medioActual);

	}

	@Test(expected = SaldoInsuficienteException.class)
	public void queSeLanceUnaExcepcionSiElSaldoDeLaTarjetaEsInsuficienteParaHacerUnaCompra()
			throws PersonaJuridicaInexistente, MedioInexistente, SaldoInsuficienteException,
			TipoDeOperacionIncompatible, NoSeEncontroElMedio, ExcedeLimitDeCompraException {
		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");

		Persona vendedor = new PersonaJuridica("Mica", 132465789l);

		billetera.agregarPersonaJuridica((PersonaJuridica) vendedor);

		Medio medio = new TarjetaDebito("21321312", 200d);

		billetera.agregarMedio(medio);

		billetera.asociarMedioAUnaPersonaJuridica((PersonaJuridica) vendedor, medio);

		Double monto = 300d;
		billetera.realizarCompra(vendedor, medio, monto);

	}

	@Test(expected = ExcedeLimitDeCompraException.class)
	public void queSeLanceUnaExcepcionSiElLimiteDeCompraDeLaTarjetaEsInsuficienteParaHacerUnaCompra()
			throws PersonaJuridicaInexistente, MedioInexistente, SaldoInsuficienteException,
			TipoDeOperacionIncompatible, ExcedeLimitDeCompraException {
		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");

		Persona vendedor = new PersonaJuridica("Mica", 132465789l);

		billetera.agregarPersonaJuridica((PersonaJuridica) vendedor);

		Medio medio = new TarjetaCredito("21321312", 200d);

		billetera.agregarMedio(medio);

		billetera.asociarMedioAUnaPersonaJuridica((PersonaJuridica) vendedor, medio);

		Double monto = 300d;
		billetera.realizarCompra(vendedor, medio, monto);

	}

	@Test
	public void queSePuedanRealizarTransferencias() throws NoSeEncontroElMedio, PersonaJuridicaInexistente,
			MedioInexistente, SaldoInsuficienteException, TipoDeOperacionIncompatible, PersonaFisicaInexistente {
		// para realizar una transferencia voy a necesitar dos personas, una q
		// transfiere y la otra q recibe la transferencia. Entonces tmabien voy a
		// necesitar dos medios transferibles asociados a las personas.

		// dos personas
		// dos medios
		// necesito que la persona q va a transferir tenga saldo en su cuenta
		// la persona q recibe puede o no tener saldo en su cuenta
		//
		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");

		Persona emisorDeTransferencia = new PersonaJuridica("Mica", 132465789l);
		Persona receptorDeTransferencia = new PersonaFisica("Franco", 333333333l);

		billetera.agregarPersonaJuridica((PersonaJuridica) emisorDeTransferencia);
		billetera.agregarPersonaFisica((PersonaFisica) receptorDeTransferencia);

		CuentaBancaria cajaDeAhorro = new CajaDeAhorro("556456", 200d, 500d);
		Medio cuentaVirtual = new CuentaVirtual("0123654", 2500d);

		billetera.agregarMedio(cajaDeAhorro);
		billetera.agregarMedio(cuentaVirtual);

		billetera.asociarMedioAUnaPersonaJuridica((PersonaJuridica) emisorDeTransferencia, cajaDeAhorro);
		billetera.asociarMedioAUnaPersonaFisica((PersonaFisica) receptorDeTransferencia, cuentaVirtual);

		Double montoATransferir = 150d;
		billetera.transferir(emisorDeTransferencia, receptorDeTransferencia, montoATransferir, cajaDeAhorro,
				cuentaVirtual);

		// para ver si la transferencia se realizo correctamente me fijo que en el
		// receptor se haya depositado correctamente
		Double saldoDelReceptorActual = ((CuentaVirtual) cuentaVirtual).getSaldo();
		Double saldoDelReceptorEsperado = 2650d;

		Double saldoDelEmisorActual = ((CuentaBancaria) cajaDeAhorro).getSaldo();
		Double saldoDelEmisorEsperado = 50d;

		assertEquals(saldoDelReceptorEsperado, saldoDelReceptorActual);
		assertEquals(saldoDelEmisorEsperado, saldoDelEmisorActual);

	}

	@Test(expected = SaldoInsuficienteException.class)
	public void queSeLanceUnaExcepcionSiElSaldoDeLaCuentaVirtualEsInsuficienteParaHacerUnaCompra()
			throws PersonaJuridicaInexistente, MedioInexistente, SaldoInsuficienteException,
			TipoDeOperacionIncompatible, ExcedeLimitDeCompraException {
		// tengo que comprar con una cuenta virtual
		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");

		Persona vendedor = new PersonaJuridica("Mica", 132465789l);

		billetera.agregarPersonaJuridica((PersonaJuridica) vendedor);

		Medio medio = new CuentaVirtual("21321312", 200d);

		billetera.agregarMedio(medio);

		billetera.asociarMedioAUnaPersonaJuridica((PersonaJuridica) vendedor, medio);

		Double monto = 300d;
		billetera.realizarCompra(vendedor, medio, monto);

	}
	
	@Test (expected = SaldoInsuficienteException.class)
	public void queSeLanceUnaExcepcionSiElSaldoDeLaCuentaEsInsuficienteParaHacerUnaTransferencia() throws NoSeEncontroElMedio, PersonaJuridicaInexistente,
			MedioInexistente, SaldoInsuficienteException, TipoDeOperacionIncompatible, PersonaFisicaInexistente {
		// para realizar una transferencia voy a necesitar dos personas, una q
		// transfiere y la otra q recibe la transferencia. Entonces tmabien voy a
		// necesitar dos medios transferibles asociados a las personas.

		// dos personas
		// dos medios
		// necesito que la persona q va a transferir tenga saldo en su cuenta
		// la persona q recibe puede o no tener saldo en su cuenta
		//
		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");

		Persona emisorDeTransferencia = new PersonaJuridica("Mica", 132465789l);
		Persona receptorDeTransferencia = new PersonaFisica("Franco", 333333333l);

		billetera.agregarPersonaJuridica((PersonaJuridica) emisorDeTransferencia);
		billetera.agregarPersonaFisica((PersonaFisica) receptorDeTransferencia);

		CuentaBancaria cajaDeAhorro = new CajaDeAhorro("556456", 200d, 500d);
		Medio cuentaVirtual = new CuentaVirtual("0123654", 2500d);

		billetera.agregarMedio(cajaDeAhorro);
		billetera.agregarMedio(cuentaVirtual);

		billetera.asociarMedioAUnaPersonaJuridica((PersonaJuridica) emisorDeTransferencia, cajaDeAhorro);
		billetera.asociarMedioAUnaPersonaFisica((PersonaFisica) receptorDeTransferencia, cuentaVirtual);

		Double montoATransferir = 300d;
		billetera.transferir(emisorDeTransferencia, receptorDeTransferencia, montoATransferir, cajaDeAhorro,
				cuentaVirtual);
}
	
	@Test
	public void queDesdeUnaCuentaCorrienteSePuedaRealizarUnaTransferenciaPorEncimaDeSuSaldo() throws NoSeEncontroElMedio, PersonaJuridicaInexistente,
			MedioInexistente, SaldoInsuficienteException, TipoDeOperacionIncompatible, PersonaFisicaInexistente {
		MercadoUnlam billetera = new MercadoUnlam("Mercado Unlam");

		Persona emisorDeTransferencia = new PersonaJuridica("Mica", 132465789l);
		Persona receptorDeTransferencia = new PersonaFisica("Franco", 333333333l);

		billetera.agregarPersonaJuridica((PersonaJuridica) emisorDeTransferencia);
		billetera.agregarPersonaFisica((PersonaFisica) receptorDeTransferencia);

		CuentaBancaria cuentaCorriente = new CuentaCorriente("556456", 200d, 500d);
		Medio cuentaVirtual = new CuentaVirtual("0123654", 2500d);

		billetera.agregarMedio(cuentaCorriente);
		billetera.agregarMedio(cuentaVirtual);

		billetera.asociarMedioAUnaPersonaJuridica((PersonaJuridica) emisorDeTransferencia, cuentaCorriente);
		billetera.asociarMedioAUnaPersonaFisica((PersonaFisica) receptorDeTransferencia, cuentaVirtual);

		Double montoATransferir = 300d;
		billetera.transferir(emisorDeTransferencia, receptorDeTransferencia, montoATransferir, cuentaCorriente,
				cuentaVirtual);
		
		Double saldoDelReceptorActual = ((CuentaVirtual) cuentaVirtual).getSaldo();
		Double saldoDelReceptorEsperado = 2800d;

		Boolean resultado = cuentaCorriente.extraer(montoATransferir);
		assertEquals(saldoDelReceptorEsperado, saldoDelReceptorActual);
		assertTrue(resultado);
}
}
