package ar.edu.unlam.pb2;

public class CajaDeAhorro extends CuentaBancaria {

	public CajaDeAhorro(String CBU, Double saldoDisponible, Double sobregiro) {
		super(CBU, saldoDisponible, sobregiro);
		// TODO Auto-generated constructor stub
	}



}
