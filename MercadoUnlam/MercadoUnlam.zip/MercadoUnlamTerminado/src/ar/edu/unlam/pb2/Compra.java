package ar.edu.unlam.pb2;

public class Compra extends Transaccion {

	private Persona vendedor;

	public Compra(Double monto, Persona vendedor) {
		super(monto);
		this.vendedor = vendedor;
	}

	@Override
	public String toString() {
		return "Compra [vendedor=" + vendedor + "]";
	}

	

}
