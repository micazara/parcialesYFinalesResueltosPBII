package ar.edu.unlam.pb2;

public class Transferencia extends Transaccion {

	public Transferencia(Double monto) {
		super(monto);
		// TODO Auto-generated constructor stub
	}



}
