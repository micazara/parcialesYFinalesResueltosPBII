package ar.edu.unlam.pb2;

import java.util.Objects;

public abstract class Medio {

	protected String id;

	public Medio(String id) {
		this.id = id;
	}

	String getId() {
		return id;
	}

	void setId(String id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Medio other = (Medio) obj;
		return Objects.equals(id, other.id);
	}

}
