package ar.edu.unlam.pb2;

public class CuentaCorriente extends CuentaBancaria {

	public CuentaCorriente(String CBU, Double saldoDisponible, Double sobregiro) {
		super(CBU, saldoDisponible, sobregiro);
		// TODO Auto-generated constructor stub
	}

}
