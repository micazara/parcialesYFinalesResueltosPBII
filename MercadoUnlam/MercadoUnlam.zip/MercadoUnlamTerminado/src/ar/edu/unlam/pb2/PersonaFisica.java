package ar.edu.unlam.pb2;

public class PersonaFisica extends Persona implements Comparable<PersonaFisica> {

	private Long cuil;

	public PersonaFisica(String nombre, Long cuil) {
		super(nombre);
		this.cuil = cuil;
	}

	Long getcuil() {
		return cuil;
	}

	void setcuil(Long cuil) {
		this.cuil = cuil;
	}

	@Override
	public int compareTo(PersonaFisica o) {
		return this.getcuil().compareTo(o.getcuil());
	}

}
