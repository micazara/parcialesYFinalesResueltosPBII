package ar.edu.unlam.pb2;

public class CuentaBancaria extends Medio implements Transferible {

	private Double saldoDisponible;
	private Double sobregiro;

	public CuentaBancaria(String CBU, Double saldoDisponible, Double sobregiro) {
		super(CBU);
		this.saldoDisponible = saldoDisponible;
		this.sobregiro = sobregiro;
	}

	@Override
	public Double getSaldo() {
		return this.saldoDisponible;
	}

	@Override
	public void depositar(Double importe) throws SaldoInsuficienteException {
		if (importe <= this.saldoDisponible) {
			this.saldoDisponible += importe;
		} 
		throw new SaldoInsuficienteException();


	}

	@Override
	public Boolean extraer(Double importe) {
		if (importe <= this.saldoDisponible + this.sobregiro) {
			this.saldoDisponible -= importe;
			return true;
		} else {
			return false;
		}
	}

}
