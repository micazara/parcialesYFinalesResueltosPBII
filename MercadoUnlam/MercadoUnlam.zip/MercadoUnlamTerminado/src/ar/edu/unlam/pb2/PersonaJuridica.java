package ar.edu.unlam.pb2;

public class PersonaJuridica extends Persona implements Comparable<PersonaJuridica> {

	private Long cuit;

	public PersonaJuridica(String nombre, Long cuit) {
		super(nombre);
		this.cuit = cuit;
	}

	Long getCuit() {
		return cuit;
	}

	void setCuit(Long cuit) {
		this.cuit = cuit;
	}

	@Override
	public int compareTo(PersonaJuridica o) {
		return this.getCuit().compareTo(o.getCuit());
	}

}
