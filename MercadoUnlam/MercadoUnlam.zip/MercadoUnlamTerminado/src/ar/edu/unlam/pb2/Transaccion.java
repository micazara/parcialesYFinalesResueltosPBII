package ar.edu.unlam.pb2;

public abstract class Transaccion {

	public Double monto;

	public Transaccion(Double monto) {
		this.monto = monto;
	}

	Double getMonto() {
		return monto;
	}

	void setMonto(Double monto) {
		this.monto = monto;
	}

}
