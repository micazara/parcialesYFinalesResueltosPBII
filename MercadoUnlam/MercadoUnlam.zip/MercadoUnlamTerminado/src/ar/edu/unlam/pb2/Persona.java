package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class Persona {
	private List<Medio> medios;
	private String nombre;

	public Persona(String nombre) {
		this.medios = new ArrayList<Medio>();
		this.nombre = nombre;
	}

	List<Medio> getMedios() {
		return medios;
	}

	void setMedios(List<Medio> medios) {
		this.medios = medios;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void asociarMedio(Medio medio) {
		this.medios.add(medio);

	}

	public Integer obtenerCantidadDeMedios() {
		return this.medios.size();
	}

	public String generarQR(Compra compra) {
		return compra.toString();
	}

	public Medio buscarMedio(Medio buscado) throws NoSeEncontroElMedio {
		for (Medio medio : medios) {
			if (medio.getId().equals(buscado.getId())) {
				return medio;
			}
		}
		throw new NoSeEncontroElMedio();

	}

}
