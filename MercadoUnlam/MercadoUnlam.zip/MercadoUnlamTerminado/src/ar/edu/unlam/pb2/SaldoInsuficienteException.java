package ar.edu.unlam.pb2;

public class SaldoInsuficienteException extends Exception {

}
