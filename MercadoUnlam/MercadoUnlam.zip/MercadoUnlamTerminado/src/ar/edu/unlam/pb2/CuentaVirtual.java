package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class CuentaVirtual extends Medio implements Pagadora, Transferible {

	private Double saldoDisponible;
	private List<Compra> historialDeCompras;

	public CuentaVirtual(String cvu, Double saldoDisponible) {
		super(cvu);
		this.saldoDisponible = saldoDisponible;
		this.historialDeCompras = new ArrayList<Compra>();
	}

	@Override
	public Double getSaldo() {
		return this.saldoDisponible;
	}

	@Override
	public void depositar(Double importe) {
		this.saldoDisponible += importe;

	}

	@Override
	public Boolean extraer(Double importe) throws SaldoInsuficienteException {
		if (importe <= this.saldoDisponible) {
			this.saldoDisponible -= importe;
			return true;
		} else {
			throw new SaldoInsuficienteException();
		}
	}

	@Override
	public Boolean pagar(Persona vendedor, Double importe) throws SaldoInsuficienteException {
		if (this.saldoDisponible>=importe) {
			Compra nueva = new Compra(importe, vendedor);
			vendedor.generarQR(nueva);
			this.historialDeCompras.add(nueva);
			return true;
		} else {
			throw new SaldoInsuficienteException();
		}
	}


}
