package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TarjetaCredito extends Medio implements Pagadora {

	private Double limiteDeCompra;
	private List<Compra> historialDeCompras;

	public TarjetaCredito(String numero, Double limiteDeCompra) {
		super(numero);
		this.limiteDeCompra = limiteDeCompra;
		this.historialDeCompras = new ArrayList<Compra>();
	}

	@Override
	public Boolean pagar(Persona vendedor, Double importe) throws ExcedeLimitDeCompraException {
		if (importe <= this.limiteDeCompra) {
			Compra nueva = new Compra(importe, vendedor);
			this.historialDeCompras.add(nueva);
			vendedor.generarQR(nueva);
			return true;
		} else {
			// ExcedeLimiteDeCompraException: Cuando se desea realizar una compra con tarjeta de crédito, pero se excede el límite disponible en esa tarjeta.
			throw new ExcedeLimitDeCompraException();
		}

	}

	Double getLimiteDeCompra() {
		return limiteDeCompra;
	}

	void setLimiteDeCompra(Double limiteDeCompra) {
		this.limiteDeCompra = limiteDeCompra;
	}

	List<Compra> getHistorial() {
		return historialDeCompras;
	}

	void setHistorial(List<Compra> historial) {
		this.historialDeCompras = historial;
	}

	public Integer obtenerCantidadDeComprasRealizadas() {
		return this.historialDeCompras.size();
	}
}
