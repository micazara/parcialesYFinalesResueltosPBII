package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class MercadoUnlam {

	private String nombre;
	private List<Transaccion> transacciones;
	private Set<PersonaJuridica> personasJuridicas;
	private Set<PersonaFisica> personasFisicas;
	private Set<Medio> medios;

	public MercadoUnlam(String nombre) {
		this.nombre = nombre;
		this.transacciones = new ArrayList<Transaccion>();
		this.personasJuridicas = new TreeSet<PersonaJuridica>();
		this.personasFisicas = new TreeSet<PersonaFisica>();
		this.medios = new HashSet<Medio>();
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void guardarTransacciones(Transaccion nueva) {
		this.transacciones.add(nueva);

	}

	public Integer obtenerCantidadDeTransaccionesGuardadas() {
		return this.transacciones.size();

	}

	List<Transaccion> getTransacciones() {
		return transacciones;
	}

	void setTransacciones(List<Transaccion> transacciones) {
		this.transacciones = transacciones;
	}

	public void agregarPersonaJuridica(PersonaJuridica nueva) {
		this.personasJuridicas.add(nueva);

	}

	public void agregarPersonaFisica(PersonaFisica nueva) {
		this.personasFisicas.add(nueva);
	}

	public Integer obtenerCantidadDePersonasJuridicas() {
		return this.personasJuridicas.size();
	}

	public Integer obtenerCantidadDePersonasFisicas() {
		return this.personasFisicas.size();
	}

	public void agregarMedio(Medio medio) {
		this.medios.add(medio);

	}

	public Integer obtenerCantidadDeMedios() {
		return this.medios.size();
	}

	public void asociarMedioAUnaPersonaJuridica(PersonaJuridica vendedor, Medio medio)
			throws PersonaJuridicaInexistente, MedioInexistente {
		PersonaJuridica buscada = buscarPersonaJuridica(vendedor);
		Medio buscado = buscarMedio(medio);
		buscada.asociarMedio(buscado);

	}

	private Medio buscarMedio(Medio medio) throws MedioInexistente {
		for (Medio actual : this.medios) {
			if (actual.getId().equals(medio.getId())) {
				return actual;
			}
		}
		throw new MedioInexistente();
	}

	private PersonaJuridica buscarPersonaJuridica(PersonaJuridica vendedor) throws PersonaJuridicaInexistente {
		for (PersonaJuridica actual : this.personasJuridicas) {
			if (actual.getCuit().equals(vendedor.getCuit())) {
				return actual;
			}
		}

		throw new PersonaJuridicaInexistente();
	}

	public void realizarCompra(Persona vendedor, Medio medio, Double monto) throws PersonaJuridicaInexistente,
			MedioInexistente, SaldoInsuficienteException, TipoDeOperacionIncompatible, ExcedeLimitDeCompraException {
		PersonaJuridica buscada = buscarPersonaJuridica((PersonaJuridica) vendedor);
		Medio buscado = buscarMedio(medio);

		if (buscado instanceof Pagadora) {
			((Pagadora) buscado).pagar(vendedor, monto);
		} else {
			throw new TipoDeOperacionIncompatible();
		}

	}

	public void asociarMedioAUnaPersonaFisica(PersonaFisica personaFisica, Medio medio)
			throws MedioInexistente, PersonaFisicaInexistente {
		PersonaFisica buscada = buscarPersonaFisica(personaFisica);
		Medio buscado = buscarMedio(medio);
		buscada.asociarMedio(buscado);
	}

	private PersonaFisica buscarPersonaFisica(PersonaFisica personaFisica) throws PersonaFisicaInexistente {
		for (PersonaFisica actual : this.personasFisicas) {
			if (actual.getcuil().equals(personaFisica.getcuil())) {
				return actual;
			}
		}

		throw new PersonaFisicaInexistente();
	}

	public void transferir(Persona emisorDeTransferencia, Persona receptorDeTransferencia, Double monto,
			Medio medioDelEmisor, Medio medioDelReceptor)
			throws PersonaJuridicaInexistente, PersonaFisicaInexistente, MedioInexistente, SaldoInsuficienteException {
		if (emisorDeTransferencia instanceof PersonaJuridica) {
			PersonaJuridica emisor = buscarPersonaJuridica((PersonaJuridica) emisorDeTransferencia);
		} else {
			PersonaFisica emisor = buscarPersonaFisica((PersonaFisica) emisorDeTransferencia);
		}

		if (receptorDeTransferencia instanceof PersonaJuridica) {
			PersonaJuridica receptor = buscarPersonaJuridica((PersonaJuridica) receptorDeTransferencia);
		} else {
			PersonaFisica receptor = buscarPersonaFisica((PersonaFisica) receptorDeTransferencia);
		}

		Medio medioDelEmisorBuscado = buscarMedio(medioDelEmisor);
		Medio medioDelReceptorBuscado = buscarMedio(medioDelReceptor);

		if (medioDelEmisorBuscado instanceof Transferible && medioDelReceptorBuscado instanceof Transferible) {
			((Transferible) medioDelReceptorBuscado).depositar(monto);

			Double saldoDelEmisor = ((Transferible) medioDelEmisorBuscado).getSaldo();

			if (monto <= saldoDelEmisor) {
				((Transferible) medioDelEmisorBuscado).extraer(monto);
			} else if (monto >= saldoDelEmisor && medioDelEmisorBuscado instanceof CuentaCorriente) {
				((Transferible) medioDelEmisorBuscado).extraer(monto);
			} else {
				throw new SaldoInsuficienteException();
			}

		}

	}

}
