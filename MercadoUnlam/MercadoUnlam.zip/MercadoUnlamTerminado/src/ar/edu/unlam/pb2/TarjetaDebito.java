package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class TarjetaDebito extends Medio implements Pagadora {

	public Double saldoDisponible;
	public List<Compra> historialDeCompras;

	public TarjetaDebito(String numero, Double saldoDisponible) {
		super(numero);
		this.saldoDisponible = saldoDisponible;
		this.historialDeCompras = new ArrayList<Compra>();
	}

	@Override
	public Boolean pagar(Persona vendedor, Double importe) throws SaldoInsuficienteException {
		if (importe <= this.saldoDisponible) {
			Compra nueva = new Compra(importe, vendedor);
			this.historialDeCompras.add(nueva);
			vendedor.generarQR(nueva);
		}
		throw new SaldoInsuficienteException();
	}

	Double getSaldoDisponible() {
		return saldoDisponible;
	}

	void setSaldoDisponible(Double saldoDisponible) {
		this.saldoDisponible = saldoDisponible;
	}

	List<Compra> getHistorialDeCompras() {
		return historialDeCompras;
	}

	void setHistorialDeCompras(List<Compra> historialDeCompras) {
		this.historialDeCompras = historialDeCompras;
	}

}
