package ar.edu.unlam.pb2;

public class PersonaFisicaInexistente extends Exception {

}
