package ar.edu.unlam.pb2;

public class Hierba extends Planta {

	private final double gananciaHierbaMata = 1.2;

	public Hierba(int codigo, String nombre, Double precioBase, int stock) {
		super(codigo, nombre, precioBase, stock);
	}

	@Override
	public Double obtenerPrecioFinal() {
		return this.gananciaHierbaMata * this.getPrecioBase();
	}

}
