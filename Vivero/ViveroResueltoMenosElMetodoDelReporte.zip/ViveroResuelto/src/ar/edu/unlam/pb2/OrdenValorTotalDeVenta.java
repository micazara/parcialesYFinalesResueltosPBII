package ar.edu.unlam.pb2;

import java.util.Comparator;

public class OrdenValorTotalDeVenta implements Comparator<Venta> {

	@Override
	public int compare(Venta o1, Venta o2) {
		return o1.obtenerValorTotal().compareTo(o2.obtenerValorTotal());
	}

}
