package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Vivero {

	private String nombre;

	// No se pueden registrar plantas duplicadas. 2 plantas son iguales cuando tiene
	// el mismo Id
	private Set<Planta> plantas;
	private List<Venta> ventas;

	public Vivero(String nombre) {
		this.plantas = new HashSet<Planta>();
		this.ventas = new ArrayList<Venta>();
	}

	// No puede haber 2 plantas con el mismo Id , Si se duplica lanza una Exception
	// Planta Duplicada Exception
	public void agregarPlanta(Planta planta) throws PlantaDuplicadaException {
		if (!this.plantas.add(planta)) {
			throw new PlantaDuplicadaException();
		}
	}

	public Integer obtenerCantidadDePlantas() {
		return this.plantas.size();
	}

	/*
	 * Registra una venta y descuenta del stock de la planta la cantidad deseada. Si
	 * no se encuentra la planta lanza una exception Planta Inexistente. Si no hay
	 * Stock Lanza Una Exception ProdutoSinStockException
	 */
	public void venderPlanta(Integer codigoPlanta, Integer cantidadAVender)
			throws PlantaInexistente, ProductoSinStockException {
		Planta plantaBuscada = buscarPlanta(codigoPlanta);
		int stockDeLaPlantaBuscada = plantaBuscada.getStock();

		if (cantidadAVender > stockDeLaPlantaBuscada) {
			throw new ProductoSinStockException();
		} else {
			actualizarStock(cantidadAVender, plantaBuscada, stockDeLaPlantaBuscada);
			this.ventas.add(new Venta(1, cantidadAVender, plantaBuscada, plantaBuscada.obtenerPrecioFinal()));
		}

	}

	private void actualizarStock(Integer cantidadAVender, Planta plantaBuscada, int stockDeLaPlantaBuscada) {
		int nuevoStock = stockDeLaPlantaBuscada -= cantidadAVender;
		plantaBuscada.setStock(nuevoStock);
	}

	/*
	 * Obtener un listado de todos los arboles vendidos ordenados por el total de
	 * venta (Cantidad * precioDeLaPlanta)
	 * 
	 */
	public List<Venta> obtenerTodasLasVentasDeArbolesOrdenadosPorElValorTotalDeLaVenta() {
		// Como tengo que obtener las ventas de arboles, me fijo si la planta de la
		// venta q se realizo es un arbol. Si es asi, añado la venta actual a la lista
		// que ordena a traves de un comparator.
		List<Venta> ventasOrdenadas = new ArrayList<Venta>();
		// buscar si se vendio un arbol
		for (Venta actual : this.ventas) {
			if (actual.getPlanta() instanceof Arbol) {
				ventasOrdenadas.add(actual);
			}
		}
		// cantidad * precio me va a dar el valor total de venta porque
		ventasOrdenadas.sort(new OrdenValorTotalDeVenta());
		return ventasOrdenadas;
	}

	public Integer obtenerCantidadDeVentas() {
		return this.ventas.size();
	}

	private Planta buscarPlanta(Integer codigoPlanta) throws PlantaInexistente {
		for (Planta actual : this.plantas) {
			if (actual.getCodigo().equals(codigoPlanta)) {
				return actual;
			}
		}
		throw new PlantaInexistente();
	}

	/*
	 * Obtener Un reporte de las plantas vendidas agrupados por tipo Plantas
	 * 
	 * 
	 * Ejemplo: para una key "arbol", debemos completar las plantas de este tipo
	 * 
	 */

	public Map<String, Set<Planta>> obtenerReporteDePlantasAgrupadasPorTipo() {
		// si ingreso la key arbol, en el set de plantas tengo q tener arboles.
		Map<String, Set<Planta>> reporteDePlantas = new HashMap<String, Set<Planta>>();
		// para cada planta en el conjunto plantas de esta clase 
		for (Planta actual : this.plantas) {
			// obteneme el valor segun la key y guardalo en el set. la key es el nombre del tipo de planta
			Set<Planta> valor = reporteDePlantas.get(actual.getClass().getName());
			// si el valor es nulo, crea un nuevo hashset y agregale la planta actual en el bucle
			if (valor == null) {
				Set<Planta> item = new HashSet<Planta>();
				item.add(actual);
				// agrega al mapa elnombre de la planta y la planta
				reporteDePlantas.put(actual.getClass().getName(), item);
			} else {
				// si si existe agrega al valor del mapa la planta actual en el bucle
				valor.add(actual);
				// agrega al mapa el nombre del tipo de la planta y el valor, que es la planta
				reporteDePlantas.put(actual.getClass().getName(), valor);
			}
		}

		return reporteDePlantas;
	}

	/**
	 * Obtener una lista de plantas que implementen la interfaz correspondiente
	 */
	public List<Florales> obtenerTodasLasPlantasFlorales() {
		// Si la planta es floral (si implementa la interfaz floral)
		List<Florales> plantasFlorales = new ArrayList<Florales>();

		for (Planta actual : plantas) {
			if (actual instanceof Florales) {
				plantasFlorales.add((Florales) actual);
			}
		}

		return plantasFlorales;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Set<Planta> getPlantas() {
		return plantas;
	}

	void setPlantas(Set<Planta> plantas) {
		this.plantas = plantas;
	}

	List<Venta> getVentas() {
		return ventas;
	}

	void setVentas(List<Venta> ventas) {
		this.ventas = ventas;
	}

	public TreeSet<Planta> obtenerTodasLasPlantasOrdenadasPorOrdenAlfabetico() {

		TreeSet<Planta> plantasOrdenadasAlfabeticamente = new TreeSet<Planta>(new OrdenAlfabeticoDePlantas());

		plantasOrdenadasAlfabeticamente.addAll(this.plantas);

		return plantasOrdenadasAlfabeticamente;
	}

	public TreeSet<Arbol> obtenerPrecioDeFloralesEnEstadoDeFloracion() {
		// 2 condiciones: que la planta implemente la interfaz florales y que su estado
		// de floracion sea menor o igual al 100.
		TreeSet<Arbol> precioDeFlorales = new TreeSet<Arbol>(new precioDeFloralesOrdenados());
		for (Planta actual : this.plantas) {
			if (actual instanceof Florales && ((Arbol) actual).getEstadoFloracion() < 100) {
				precioDeFlorales.add((Arbol) actual);
			}
		}
		return precioDeFlorales;
	}

	public TreeSet<Arbol> obtenerPrecioDeFloralesEnEstadoDeProduccion() {
		TreeSet<Arbol> precioDeFlorales = new TreeSet<Arbol>(new precioDeFloralesOrdenados());
		for (Planta actual : this.plantas) {
			if (actual instanceof Florales && ((Arbol) actual).getEstadoFloracion() == 100
					&& ((Arbol) actual).getMadurezFrutos() >= 1) {
				precioDeFlorales.add((Arbol) actual);
			}
		}

		return precioDeFlorales;

	}

}
