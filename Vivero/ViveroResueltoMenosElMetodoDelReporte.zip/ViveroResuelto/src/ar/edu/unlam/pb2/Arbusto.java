package ar.edu.unlam.pb2;

public class Arbusto extends Planta {
	private final double GANANCIA_ARBUSTO = 1.6;

	public Arbusto(int codigo, String nombre, Double precioBase, int stock) {
		super(codigo, nombre, precioBase, stock);
	}

	@Override
	public Double obtenerPrecioFinal() {
		return this.GANANCIA_ARBUSTO * this.getPrecioBase();
	}

}
