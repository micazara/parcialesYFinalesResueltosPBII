package ar.edu.unlam.pb2;

public class PlantaInexistente extends Exception {

}
