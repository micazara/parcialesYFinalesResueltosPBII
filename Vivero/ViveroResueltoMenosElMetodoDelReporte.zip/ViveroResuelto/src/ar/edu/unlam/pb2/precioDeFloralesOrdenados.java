package ar.edu.unlam.pb2;

import java.util.Comparator;

public class precioDeFloralesOrdenados implements Comparator<Arbol> {

	@Override
	public int compare(Arbol o1, Arbol o2) {
		return o1.obtenerPrecioFinal().compareTo(o2.obtenerPrecioFinal());
	}

}
