package ar.edu.unlam.pb2;

import java.util.Comparator;

public class OrdenAlfabeticoDePlantas implements Comparator<Planta> {

	@Override
	public int compare(Planta o1, Planta o2) {
		return o1.getNombre().compareTo(o2.getNombre());
	}

}
