package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

public class TestCases {

	@Test
	public void queSePuedaAgregarUnaPlanta() throws PlantaDuplicadaException {
		Planta jacaranda = new Arbol(1, "Jacaranda", 25d, 10);
		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(jacaranda);

		Integer cantidadDePlantasAgregadas = viveroDeMica.obtenerCantidadDePlantas();
		assertEquals((Integer) 1, cantidadDePlantasAgregadas);
		assertTrue(viveroDeMica.getPlantas().contains(jacaranda));

	}

	@Test
	public void queSePuedaCalcularCorrectamenteLaFloracionDeUnArbol() {
		Planta jacaranda = new Arbol(1, "Jacaranda", 25d, 10);

		((Arbol) jacaranda).florar();

		Double precioFinalActual = jacaranda.obtenerPrecioFinal();
		Double precioFinalEsperado = 60.37;

		assertEquals(precioFinalEsperado, precioFinalActual, 0.1);
	}

	@Test(expected = PlantaDuplicadaException.class)
	public void queNoSePuedanAgregarPlantasDuplicadas() throws PlantaDuplicadaException {
		Planta jacaranda = new Arbol(1, "Jacaranda", 25d, 10);
		Planta sauce = new Arbol(1, "Sauce", 55d, 48);
		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(jacaranda);
		viveroDeMica.agregarPlanta(sauce);

	}

	@Test
	public void queSePuedaVenderUnaPlanta()
			throws PlantaDuplicadaException, PlantaInexistente, ProductoSinStockException {
		int stockDeLaPlanta = 10;
		int codigoDeLaPlanta = 1;
		Planta jacaranda = new Arbol(codigoDeLaPlanta, "Jacaranda", 25d, stockDeLaPlanta);
		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(jacaranda);

		Integer cantidadAVender = 5;
		viveroDeMica.venderPlanta(codigoDeLaPlanta, 5);

		Integer cantidadDeVentas = viveroDeMica.obtenerCantidadDeVentas();

		// verifico q se haya realizado una venta
		assertEquals((Integer) 1, cantidadDeVentas);
		// verifico que la planta q se vendio sea la misma q agregue al vivero
		assertEquals(jacaranda, viveroDeMica.getVentas().get(0).getPlanta());
		// verifico que el stock se haya actualizado correctamente
		assertEquals(5, jacaranda.getStock());
	}

	@Test
	public void queSePuedanObtenerTodasLasPlantasFlorales() throws PlantaDuplicadaException {
		Planta jacaranda = new Arbol(1, "Jacaranda", 25d, 10);
		Planta eucalipto = new Arbol(2, "Eucalipto", 66d, 50);
		Planta roble = new Arbol(3, "Roble", 49d, 15);
		Planta yuyito = new Hierba(4, "yuyito", 3d, 10);

		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(jacaranda);
		viveroDeMica.agregarPlanta(eucalipto);
		viveroDeMica.agregarPlanta(roble);
		viveroDeMica.agregarPlanta(yuyito);

		List<Florales> plantasFlorales = viveroDeMica.obtenerTodasLasPlantasFlorales();

		assertTrue(plantasFlorales.contains(jacaranda));
		assertFalse(plantasFlorales.contains(yuyito));
		assertEquals(3, plantasFlorales.size());
	}

	@Test
	public void queSePuedanObtenerTodasLasPlantasPorOrdenAlfabetico() throws PlantaDuplicadaException {
		Planta jacaranda = new Arbol(1, "Jacaranda", 25d, 10);
		Planta eucalipto = new Arbol(2, "Eucalipto", 66d, 50);
		Planta roble = new Arbol(3, "Roble", 49d, 15);
		Planta yuyito = new Hierba(4, "yuyito", 3d, 10);
		Planta hortencia = new Arbusto(5, "Hortencia", 36d, 50);

		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(jacaranda);
		viveroDeMica.agregarPlanta(eucalipto);
		viveroDeMica.agregarPlanta(roble);
		viveroDeMica.agregarPlanta(yuyito);
		viveroDeMica.agregarPlanta(hortencia);
		/*
		 * POR ORDEN ALFABETICO LAS PLANTAS DEBERIAN VERSE ASI: E H J R Y
		 */

		TreeSet<Planta> plantasOrdenadas = viveroDeMica.obtenerTodasLasPlantasOrdenadasPorOrdenAlfabetico();

		Planta primerPlanta = plantasOrdenadas.first();
		Planta ultimaPlanta = plantasOrdenadas.last();

		assertEquals(eucalipto, primerPlanta);
		assertEquals(yuyito, ultimaPlanta);
	}

	@Test
	public void queSePuedanObtenerTodasLasVentasDeArbolesOrdenadosPorElValorTotalDeLaVenta()
			throws PlantaDuplicadaException, PlantaInexistente, ProductoSinStockException {
		// necesito arboles
		Planta sauce = new Arbol(1, "Sauce", 25d, 10);
		Planta eucalipto = new Arbol(2, "Eucalipto", 66d, 50);
		Planta roble = new Arbol(3, "Roble", 49d, 15);

		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(sauce);
		viveroDeMica.agregarPlanta(eucalipto);
		viveroDeMica.agregarPlanta(roble);

		// necesito vender arboles
		viveroDeMica.venderPlanta(1, 3);
		viveroDeMica.venderPlanta(2, 25);
		viveroDeMica.venderPlanta(3, 5);

		List<Venta> ventasOrdenadas = viveroDeMica.obtenerTodasLasVentasDeArbolesOrdenadosPorElValorTotalDeLaVenta();
		Planta primerPlantaEnLasVentasOrdenadas = ventasOrdenadas.get(0).getPlanta();
		Planta ultimaPlantaEnLasVentasOrdenadas = ventasOrdenadas.get(2).getPlanta();

		assertEquals(sauce, primerPlantaEnLasVentasOrdenadas);
		assertEquals(eucalipto, ultimaPlantaEnLasVentasOrdenadas);
	}

	@Test
	public void queSePuedanObtenerLasPlantasAgrupadasPorTipo() throws PlantaDuplicadaException {
		Planta sauce = new Arbol(1, "Sauce", 25d, 10);
		Planta eucalipto = new Arbol(2, "Eucalipto", 66d, 50);
		Planta roble = new Arbol(3, "Roble", 49d, 15);
		Planta yuyito = new Hierba(4, "yuyito", 3d, 10);

		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(sauce);
		viveroDeMica.agregarPlanta(eucalipto);
		viveroDeMica.agregarPlanta(roble);
		viveroDeMica.agregarPlanta(yuyito);

		Map<String, Set<Planta>> reporteDePlantas = viveroDeMica.obtenerReporteDePlantasAgrupadasPorTipo();

		Set<Planta> valor = reporteDePlantas.get("Arbol");
		System.out.println(valor);
	}

	@Test
	public void obtenerPrecioDeFloralesEnEstadoDeFloracion() throws PlantaDuplicadaException {
		Planta eucalipto = new Arbol(2, "Eucalipto", 66d, 50);
		Planta roble = new Arbol(3, "Roble", 49d, 15);

		((Arbol) roble).setEstadoFloracion(25d);

		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(eucalipto);
		viveroDeMica.agregarPlanta(roble);

		TreeSet<Arbol> precioDeFlorales = viveroDeMica.obtenerPrecioDeFloralesEnEstadoDeFloracion();

		Arbol primero = precioDeFlorales.first(); // roble
		Arbol ultimo = precioDeFlorales.last(); // eucalipto

		assertEquals(roble, primero);
		assertEquals(eucalipto, ultimo);
	}

	@Test
	public void obtenerPrecioDeFloralesEnEstadoDeProduccion() throws PlantaDuplicadaException {
		// ESTADO D PRODUCCION: estadoDeFloracion=100
		Planta eucalipto = new Arbol(2, "Eucalipto", 66d, 50);
		((Arbol) eucalipto).setEstadoFloracion(100d);
		((Arbol) eucalipto).florar();

		Planta roble = new Arbol(3, "Roble", 49d, 15);
		((Arbol) roble).setEstadoFloracion(100d);
		((Arbol) roble).florar();

		Vivero viveroDeMica = new Vivero("Vivero de Mica");

		viveroDeMica.agregarPlanta(eucalipto);
		viveroDeMica.agregarPlanta(roble);

		TreeSet<Arbol> precioDeFlorales = viveroDeMica.obtenerPrecioDeFloralesEnEstadoDeProduccion();

		Arbol primero = precioDeFlorales.first(); // roble
		Arbol ultimo = precioDeFlorales.last(); // eucalipto

		assertEquals(roble, primero);
		assertEquals(eucalipto, ultimo);
	}
}
