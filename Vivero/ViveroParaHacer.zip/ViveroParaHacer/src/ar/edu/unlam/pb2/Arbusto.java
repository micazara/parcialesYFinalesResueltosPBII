package ar.edu.unlam.pb2;

public class Arbusto extends Planta{
	
	private final double GANANCIA_ARBUSTO = 1.6;

	public Arbusto(int codigo, String nombre, Double precio, int stock) {
		super(codigo, nombre, precio, stock);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double obtenerPrecio() {
		// TODO Auto-generated method stub
		return null;
	}

}
