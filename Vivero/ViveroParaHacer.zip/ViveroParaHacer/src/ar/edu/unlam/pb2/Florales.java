package ar.edu.unlam.pb2;

public interface Florales {
	void florar();
	void producirFrutos();
}
