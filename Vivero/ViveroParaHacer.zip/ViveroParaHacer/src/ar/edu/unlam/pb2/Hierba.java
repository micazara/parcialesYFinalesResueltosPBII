package ar.edu.unlam.pb2;

public class Hierba extends Planta{
	private final double gananciaHierbaMata = 1.2;

	public Hierba(int codigo, String nombre, double precio, int stock) {
		super(codigo, nombre, precio, stock);
	}

	@Override
	public Double obtenerPrecio() {
		// TODO Auto-generated method stub
		return null;
	}
}
