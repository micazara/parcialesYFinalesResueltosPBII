package ar.edu.unlam.pb2;


public class Venta {
	private Integer id;
	private Integer unidades;
	private Planta planta;
	public Double precioUnitario; 
	// Precio final de la planta al momento de realizar la venta

	public Venta(Integer id, Integer unidades, Planta planta, Double precioUnitario) {
		this.id = id;
		this.unidades = unidades;
		this.planta = planta;
		this.precioUnitario = precioUnitario;
	}
	
	Integer getId() {
		return id;
	}
	void setId(Integer id) {
		this.id = id;
	}
	Integer getUnidades() {
		return unidades;
	}
	void setUnidades(Integer unidades) {
		this.unidades = unidades;
	}
	Planta getPlanta() {
		return planta;
	}
	void setPlanta(Planta planta) {
		this.planta = planta;
	}
	Double getPrecioUnitario() {
		return precioUnitario;
	}
	void setPrecioUnitario(Double precioUnitario) {
		this.precioUnitario = precioUnitario;
	}
}
