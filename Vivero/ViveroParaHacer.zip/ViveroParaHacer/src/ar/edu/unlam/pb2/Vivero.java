package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Vivero {
	private String nombre;

	// No se pueden registrar plantas duplicadas. 2 plantas son iguales cuando tiene
	// el mismo Id
	private Set<Planta> plantas;
	private List<Venta> ventas;

	public Vivero(String nombre) {
		this.plantas = new HashSet<Planta>();
		this.ventas = new ArrayList<Venta>();
	}

	// No puede haber 2 plantas con el mismo Id , Si se duplica lanza una Exception
	// Planta Duplicada Exception
	public Boolean agregarPlanta(Planta planta) throws PlantaDuplicadException {
		

	}

	public Integer obtenerCantidadDePlantas() {
		return this.plantas.size();
	}
	

	/*
	 * Registra una venta y descuenta del stock de la planta la cantidad deseada. Si
	 * no se encuentra la planta lanza una exception Planta Inexistente. Si no hay
	 * Stock Lanza Una Exception ProdutoSinStockException
	 */
	public void venderPlanta(Integer codigoPlanta, Integer cantidadAVender)
			throws PlantaInexistente, ProdutoSinStockException {

	}

	public Integer obtenerCantidadDeVentas() {
		return this.ventas.size();
	}

	private Planta buscarPlanta(Integer codigoPlanta) throws PlantaInexistente {
		
	}

	/*
	 * Obtener un listado de todos los arboles vendidos ordenados por el total de
	 * venta (Cantidad * precioDeLaPlanta)
	 * 
	 */
	public TreeSet<Venta> obtenerTodasLasVentasDeArbolesOrdenadosPorElValorTotalDeLaVenta() {

	}

	/*
	 * Obtener Un reporte de las plantas vendidas agrupados por tipo Plantas
	 * 
	 * 
	 * Ejemplo: para una key "arbol", debemos completar las plantas de este tipo
	 * 
	 */

	public Map<String, Set<Planta>> obtenerReporteDePlantasAgrupadasPorTipo() {
		Map<String, Set<Planta>> plantasAgrupadas = new HashMap<String, Set<Planta>>();

		
	}

	/**
	 * Obtener una lista de plantas que implementen la interfaz correspondiente
	 */
	public List<Florales> obtenerTodasLasPlantasFlorales() {
		
	}

	Set<Planta> getPlantas() {
		return plantas;
	}

	void setPlantas(Set<Planta> plantas) {
		this.plantas = plantas;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	List<Venta> getVentas() {
		return ventas;
	}

	void setVentas(List<Venta> ventas) {
		this.ventas = ventas;
	}

	@Override
	public String toString() {
		return "Vivero [nombre=" + nombre + ", plantas=" + plantas + ", ventas=" + ventas
				+ ", obtenerReporteDePlantasAgrupadasPorTipo()=" + obtenerReporteDePlantasAgrupadasPorTipo() + "]";
	}

	public TreeSet<Planta> obtenerTodasLasPlantasOrdenadasAlfabeticamente() {
		TreeSet<Planta> plantasOrdenadasAlfabeticamente = new TreeSet<Planta>(new PlantasOrdenadasAlfabeticamente());
		plantasOrdenadasAlfabeticamente.addAll(this.plantas);
		return plantasOrdenadasAlfabeticamente;

	}
}
