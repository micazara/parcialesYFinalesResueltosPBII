package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCases {

//	 * TESTS A REALIZAR
//	 * obtenerPrecioDeUnaPlanta(); 
////	 * obtenerPrecio() de alguna clase que implemente la interfaz Florales en estado de floracion LISTO 
//	 * obtenerPrecio() de alguna clase que implemente la interfaz Florales en estado de produccion LISTO
//	 * queSePuedaAgregarUnaPlanta(); LISTO 
//	 * venderPlanta(); LISTO
//	 * obtenerTodasLasVentasDeArbolesOrdenadosPorElValorTotalDeLaVenta(); LISTO
//	 * @;
//	 * queSePuedanObtenerTodasLasPlantasFlorales(); LISTO
//	 * queSePuedanObtenerTodasLasPlantasPorOrdenAlfabetico(); LISTO
//	 */
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

