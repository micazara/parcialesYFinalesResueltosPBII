package ar.edu.unlam.pb2;

import java.util.Objects;

public abstract class Vehiculo {

	public Integer codigo;
	public Double cantKmRecorridos;
	public Chofer chofer;

	public Vehiculo(Double cantKmRecorrido, Integer codigo) {
		this.cantKmRecorridos = cantKmRecorrido;
		this.codigo = codigo;

	}

	public abstract void asignarChofer(Chofer chofer);

	public abstract void cambiarChofer(Chofer nuevo);
	
	public abstract void asignarPasajero(Pasajero nuevo) throws CantidadExcedidaDePasajeros;

	Double getCantKmRecorridos() {
		return cantKmRecorridos;
	}

	void setCantKmRecorridos(Double cantKmRecorridos) {

		this.cantKmRecorridos = cantKmRecorridos;
	}

	Chofer getChofer() {
		return chofer;
	}

	Integer getCodigo() {
		return codigo;
	}

	void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(codigo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Vehiculo other = (Vehiculo) obj;
		return Objects.equals(codigo, other.codigo);
	}

}
