package ar.edu.unlam.pb2;

public class Moto extends Vehiculo {

	private Pasajero acompaniante;

	public Moto(Double cantKmRecorrido, Integer codigo) {
		super(cantKmRecorrido, codigo);
	}

	@Override
	public void asignarChofer(Chofer chofer) {
		if (this.chofer == null) {
			this.chofer = chofer;
		}

	}

	@Override
	public void cambiarChofer(Chofer nuevo) {
		if (!nuevo.equals(this.getChofer())) {
			this.chofer = nuevo;
		}

	}

	Pasajero getAcompaniante() {
		return acompaniante;
	}

	void setAcompaniante(Pasajero acompaniante) {
		this.acompaniante = acompaniante;
	}

	@Override
	public void asignarPasajero(Pasajero nuevo) {
		this.setAcompaniante(nuevo);

	}

}
