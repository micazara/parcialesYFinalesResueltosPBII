package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Set;

public class Automovil extends Vehiculo {

	private Set<Pasajero> pasajeros;

	public Automovil(Double cantKmRecorrido, Integer codigo) {
		super(cantKmRecorrido, codigo);
		this.pasajeros = new HashSet<Pasajero>();
	}

	@Override
	public void asignarChofer(Chofer chofer) {
		if (this.chofer == null) {
			this.chofer = chofer;
		}

	}

	@Override
	public void cambiarChofer(Chofer nuevo) {
		if (!nuevo.equals(this.getChofer())) {
			this.chofer = nuevo;
		}

	}

	Set<Pasajero> getPasajeros() {
		return pasajeros;
	}

	void setPasajeros(Set<Pasajero> pasajeros) {
		this.pasajeros = pasajeros;
	}

	@Override
	public void asignarPasajero(Pasajero nuevo) throws CantidadExcedidaDePasajeros {
	    if (cantidadDePasajeros() >= 3) {
	        throw new CantidadExcedidaDePasajeros();
	    } else {
	        this.pasajeros.add(nuevo);
	    }
	}

	private Integer cantidadDePasajeros() {
		return this.pasajeros.size();
	}

}
