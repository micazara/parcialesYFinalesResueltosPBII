package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Set;

public class Empresa {

	public String nombre;
	public Set<Vehiculo> flota;
	public Set<Pasajero> pasajeros;
	public Set<Chofer> choferes;

	public Empresa(String nombre) {
		this.nombre = nombre;
		this.flota = new HashSet<Vehiculo>();
		this.pasajeros = new HashSet<Pasajero>();
		this.choferes = new HashSet<Chofer>();
	}

	public void registrarVehiculo(Vehiculo auto) {
		this.flota.add(auto);

	}

	public Integer obtenerCantidadDeVehiculosEnLaFlota() {
		return this.flota.size();
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Set<Vehiculo> getFlota() {
		return flota;
	}

	void setFlota(Set<Vehiculo> flota) {
		this.flota = flota;
	}

	public void asignarPasajerosAUnVehiculo(Pasajero pasajero, Vehiculo vehiculo)
			throws CantidadExcedidaDePasajeros, VehiculoInexistente, PasajeroInexistente {
		Pasajero pasajeroBuscado = buscarPasajero(pasajero);
		Vehiculo vehiculoBuscado = buscarVehiculo(vehiculo);

		vehiculoBuscado.asignarPasajero(pasajeroBuscado);

	}

	public void asignarUnChoferAUnVehiculo(Chofer chofer, Vehiculo vehiculo)
			throws VehiculoInexistente, ChoferInexistente {
		Chofer choferBuscado = buscarChofer(chofer);
		Vehiculo vehiculoBuscado = buscarVehiculo(vehiculo);

		vehiculoBuscado.asignarChofer(choferBuscado);
	}

	public Chofer buscarChofer(Chofer chofer) throws ChoferInexistente {
		for (Chofer actual : this.choferes) {
			if (actual.getCodigo().equals(chofer.getCodigo())) {
				return actual;
			}
		}
		throw new ChoferInexistente();
	}

	public Vehiculo buscarVehiculo(Vehiculo vehiculo) throws VehiculoInexistente {
		for (Vehiculo actual : this.flota) {
			if (actual.getCodigo().equals(vehiculo.getCodigo())) {
				return actual;
			}
		}
		throw new VehiculoInexistente();
	}

	public Pasajero buscarPasajero(Pasajero pasajero) throws PasajeroInexistente {
		for (Pasajero actual : this.pasajeros) {
			if (actual.getCodigo().equals(pasajero.getCodigo())) {
				return actual;
			}
		}
		throw new PasajeroInexistente();
	}

	public void registrarPasajeros(Pasajero nuevo) throws PasajeroYaExistente {
		if (!this.pasajeros.add(nuevo))

			throw new PasajeroYaExistente();
	}

	public void registrarChofer(Chofer nuevo) throws ChoferYaExistente {
		if (!this.choferes.add(nuevo))

			throw new ChoferYaExistente();
	}

	public Integer obtenerCantidadDePasajeros() {
		return this.pasajeros.size();
	}

	public void cambiarElChoferDeUnVehiculo(Chofer nuevo, Vehiculo vehiculo)
			throws ChoferInexistente, VehiculoInexistente {
		Chofer buscado = buscarChofer(nuevo);
		Vehiculo vehiculoBuscado = buscarVehiculo(vehiculo);

		vehiculoBuscado.cambiarChofer(buscado);
	}

}
