package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class Autobus extends Vehiculo {

	private List<Pasajero> pasajeros;

	public Autobus(Double cantKmRecorrido, Integer codigo) {
		super(cantKmRecorrido, codigo);
		this.pasajeros = new ArrayList<Pasajero>();
	}

	List<Pasajero> getPasajeros() {
		return pasajeros;
	}

	void setPasajeros(List<Pasajero> pasajeros) {
		this.pasajeros = pasajeros;
	}

	@Override
	public void asignarPasajero(Pasajero nuevo) throws CantidadExcedidaDePasajeros {
		if (cantidadDePasajeros() <= 20) {
			this.pasajeros.add(nuevo);
		} else {
			throw new CantidadExcedidaDePasajeros();
		}

	}

	private Integer cantidadDePasajeros() {
		return this.getPasajeros().size();
	}

	@Override
	public void asignarChofer(Chofer chofer) {
		if (this.chofer == null) {
			this.chofer = chofer;
		}

	}

	@Override
	public void cambiarChofer(Chofer nuevo) {
		if (!nuevo.equals(this.getChofer())) {
			this.chofer = nuevo;
		}

	}

}
