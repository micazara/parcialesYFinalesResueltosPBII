package ar.edu.unlam.pb2;

public class VehiculoInexistente extends Exception {

}
