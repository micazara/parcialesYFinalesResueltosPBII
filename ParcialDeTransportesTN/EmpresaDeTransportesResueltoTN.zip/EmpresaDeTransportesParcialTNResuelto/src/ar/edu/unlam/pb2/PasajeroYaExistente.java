package ar.edu.unlam.pb2;

public class PasajeroYaExistente extends Exception {

}
