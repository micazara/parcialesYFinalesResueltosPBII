package ar.edu.unlam.pb2;

import java.util.Objects;

public class Chofer {

	private String nombre;
	private Integer codigo;

	public Chofer(String nombre, Integer codigo) {
		this.nombre = nombre;
		this.codigo = codigo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(codigo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Chofer other = (Chofer) obj;
		return Objects.equals(codigo, other.codigo);
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Integer getCodigo() {
		return codigo;
	}

	void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	
	

}
