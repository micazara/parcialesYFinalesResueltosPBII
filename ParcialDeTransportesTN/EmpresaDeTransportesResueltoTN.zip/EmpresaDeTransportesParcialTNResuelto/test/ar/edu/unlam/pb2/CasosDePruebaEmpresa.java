package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class CasosDePruebaEmpresa {

	@Test
	public void queSePuedaCrearUnaEmpresa() {
		Empresa empresa = new Empresa("Vroom Vroom");
		String nombreActual = empresa.getNombre();
		String nombreEsperado = "Vroom Vroom";

		assertNotNull(empresa);
		assertEquals(nombreEsperado, nombreActual);
	}

	@Test
	public void queSePuedaGuardarDistintosTiposDeVehiculosEnLaEmpresa() {
		Empresa empresa = new Empresa("Vroom Vroom");

		Vehiculo auto = new Automovil(46151615d, 1);
		Vehiculo moto = new Moto(4646313d, 2);
		Vehiculo autobus = new Autobus(131d, 3);
		Vehiculo corsa = new Automovil(36534143d, 4);

		empresa.registrarVehiculo(auto);
		empresa.registrarVehiculo(moto);
		empresa.registrarVehiculo(autobus);
		empresa.registrarVehiculo(corsa);

		Integer cantidadActualDeVehiculos = empresa.obtenerCantidadDeVehiculosEnLaFlota();
		Integer cantidadEsperadaDeVehiculos = 4;

		assertEquals(cantidadEsperadaDeVehiculos, cantidadActualDeVehiculos);
	}

	@Test
	public void queSePuedaGuardarUnPasajeroEnLaEmpresa() throws Exception {
		Empresa empresa = new Empresa("Vroom Vroom");
		Pasajero pasajero = new Pasajero("Mica", 1);
		empresa.registrarPasajeros(pasajero);

		Integer cantidadActualDePasajeros = empresa.obtenerCantidadDePasajeros();
		Integer cantidadEsperadaDePasajeros = 1;

		assertEquals(cantidadEsperadaDePasajeros, cantidadActualDePasajeros);
	}

	@Test

	public void queSePuedaAsignarUnAcompanianteAUnaMoto()
			throws PasajeroYaExistente, CantidadExcedidaDePasajeros, VehiculoInexistente, PasajeroInexistente {
		Empresa empresa = new Empresa("Vroom Vroom");
		Pasajero pancho = new Pasajero("Pancho", 1);

		empresa.registrarPasajeros(pancho);

		Vehiculo moto = new Moto(564654d, 1);

		empresa.registrarVehiculo(moto);

		empresa.asignarPasajerosAUnVehiculo(pancho, moto);

		Pasajero acompanianteActual = ((Moto) empresa.buscarVehiculo(moto)).getAcompaniante();
		Pasajero acompanianteEsperado = pancho;

		assertEquals(acompanianteEsperado, acompanianteActual);
	}

	@Test
	public void queSePuedaAsignarChoferAUnAutobus() throws ChoferYaExistente, VehiculoInexistente, ChoferInexistente {
		Empresa empresa = new Empresa("Vroom Vroom");

		Chofer pepe = new Chofer("Pepe", 1);
		empresa.registrarChofer(pepe);

		Vehiculo autobus = new Autobus(6565646456d, 1);
		empresa.registrarVehiculo(autobus);

		empresa.asignarUnChoferAUnVehiculo(pepe, autobus);

		Chofer choferActual = empresa.buscarVehiculo(autobus).getChofer();
		Chofer choferEsperado = pepe;

		assertEquals(choferEsperado, choferActual);

	}

	@Test
	public void queSePuedaAsignarDosAcompaniantesAUnAutomovil() throws Exception {
		Empresa empresa = new Empresa("Vroom Vroom");

		Pasajero acompaniante1 = new Pasajero("Mica", 1);
		Pasajero acompaniante2 = new Pasajero("Franco", 2);
		empresa.registrarPasajeros(acompaniante1);
		empresa.registrarPasajeros(acompaniante2);

		Vehiculo auto = new Automovil(4643643d, 1);
		empresa.registrarVehiculo(auto);

		empresa.asignarPasajerosAUnVehiculo(acompaniante1, auto);
		empresa.asignarPasajerosAUnVehiculo(acompaniante2, auto);

		assertTrue(((Automovil) empresa.buscarVehiculo(auto)).getPasajeros().contains(acompaniante1));
		assertTrue(((Automovil) empresa.buscarVehiculo(auto)).getPasajeros().contains(acompaniante2));

	}

	@Test
	public void queSePuedanAgregarVariosPasajerosAUnAutobus()
			throws PasajeroYaExistente, CantidadExcedidaDePasajeros, VehiculoInexistente, PasajeroInexistente {
		Empresa empresa = new Empresa("Vroom Vroom");

		Pasajero pancho = new Pasajero("Pancho", 1);
		Pasajero franco = new Pasajero("Franco", 2);
		empresa.registrarPasajeros(pancho);
		empresa.registrarPasajeros(franco);

		Vehiculo autobus = new Autobus(4697631d, 1);

		empresa.registrarVehiculo(autobus);

		empresa.asignarPasajerosAUnVehiculo(pancho, autobus);
		empresa.asignarPasajerosAUnVehiculo(franco, autobus);

		Pasajero primerPasajeroActual = ((Autobus) empresa.buscarVehiculo(autobus)).getPasajeros().get(0);
		Pasajero primerPasajeroEsperado = pancho;

		Pasajero segundoPasajeroActual = ((Autobus) empresa.buscarVehiculo(autobus)).getPasajeros().get(1);
		Pasajero segundoPasajeroEsperado = franco;

		assertTrue(((Autobus) empresa.buscarVehiculo(autobus)).getPasajeros().contains(pancho));
		assertTrue(((Autobus) empresa.buscarVehiculo(autobus)).getPasajeros().contains(franco));
		assertEquals(primerPasajeroEsperado, primerPasajeroActual);
		assertEquals(segundoPasajeroEsperado, segundoPasajeroActual);

	}

	@Test(expected = CantidadExcedidaDePasajeros.class)
	public void queCuandoSeExcedaLaCantidadMaximaDeUnAutobusSeLanceUnaExcepcion() throws Exception {
		Empresa empresa = new Empresa("Vroom Vroom");

		Pasajero pancho = new Pasajero("Pancho", 1);
		Pasajero franco = new Pasajero("Franco", 2);
		Pasajero a = new Pasajero("Franco", 3);
		Pasajero b = new Pasajero("Franco", 4);
		Pasajero c = new Pasajero("Franco", 5);
		Pasajero d = new Pasajero("Franco", 6);
		Pasajero e = new Pasajero("Franco", 7);
		Pasajero f = new Pasajero("Franco", 8);
		Pasajero g = new Pasajero("Franco", 9);
		Pasajero h = new Pasajero("Franco", 10);
		Pasajero i = new Pasajero("Franco", 11);
		Pasajero j = new Pasajero("Franco", 12);
		Pasajero l = new Pasajero("Franco", 13);
		Pasajero m = new Pasajero("Franco", 14);
		Pasajero n = new Pasajero("Franco", 15);
		Pasajero o = new Pasajero("Franco", 16);
		Pasajero p = new Pasajero("Franco", 17);
		Pasajero q = new Pasajero("Franco", 18);
		Pasajero r = new Pasajero("Franco", 19);
		Pasajero s = new Pasajero("Franco", 20);
		Pasajero t = new Pasajero("Franco", 21);
		Pasajero u = new Pasajero("Franco", 22);
		Pasajero v = new Pasajero("Franco", 23);
		Pasajero sdgsdg = new Pasajero("Franco", 24);

		empresa.registrarPasajeros(pancho);
		empresa.registrarPasajeros(franco);
		empresa.registrarPasajeros(a);
		empresa.registrarPasajeros(b);
		empresa.registrarPasajeros(c);
		empresa.registrarPasajeros(d);
		empresa.registrarPasajeros(e);
		empresa.registrarPasajeros(f);
		empresa.registrarPasajeros(g);
		empresa.registrarPasajeros(h);
		empresa.registrarPasajeros(i);
		empresa.registrarPasajeros(j);
		empresa.registrarPasajeros(m);
		empresa.registrarPasajeros(l);
		empresa.registrarPasajeros(n);
		empresa.registrarPasajeros(o);
		empresa.registrarPasajeros(p);
		empresa.registrarPasajeros(q);
		empresa.registrarPasajeros(r);
		empresa.registrarPasajeros(s);
		empresa.registrarPasajeros(t);
		empresa.registrarPasajeros(u);
		empresa.registrarPasajeros(v);
		empresa.registrarPasajeros(sdgsdg);

		Vehiculo autobus = new Autobus(4697631d, 1);

		empresa.registrarVehiculo(autobus);

		empresa.asignarPasajerosAUnVehiculo(pancho, autobus);
		empresa.asignarPasajerosAUnVehiculo(franco, autobus);
		empresa.asignarPasajerosAUnVehiculo(a, autobus);
		empresa.asignarPasajerosAUnVehiculo(b, autobus);
		empresa.asignarPasajerosAUnVehiculo(c, autobus);
		empresa.asignarPasajerosAUnVehiculo(d, autobus);
		empresa.asignarPasajerosAUnVehiculo(e, autobus);
		empresa.asignarPasajerosAUnVehiculo(f, autobus);
		empresa.asignarPasajerosAUnVehiculo(g, autobus);
		empresa.asignarPasajerosAUnVehiculo(h, autobus);
		empresa.asignarPasajerosAUnVehiculo(i, autobus);
		empresa.asignarPasajerosAUnVehiculo(j, autobus);
		empresa.asignarPasajerosAUnVehiculo(l, autobus);
		empresa.asignarPasajerosAUnVehiculo(m, autobus);
		empresa.asignarPasajerosAUnVehiculo(n, autobus);
		empresa.asignarPasajerosAUnVehiculo(o, autobus);
		empresa.asignarPasajerosAUnVehiculo(p, autobus);
		empresa.asignarPasajerosAUnVehiculo(q, autobus);
		empresa.asignarPasajerosAUnVehiculo(r, autobus);
		empresa.asignarPasajerosAUnVehiculo(s, autobus);
		empresa.asignarPasajerosAUnVehiculo(t, autobus);
		empresa.asignarPasajerosAUnVehiculo(sdgsdg, autobus);
	}

	@Test
	public void queSePuedaCambiarElChoferDeUnAutobus() throws Exception {
		Empresa empresa = new Empresa("Vroom Vroom");

		Chofer pepe = new Chofer("Pepe", 1);
		empresa.registrarChofer(pepe);

		Vehiculo autobus = new Autobus(6565646456d, 1);
		empresa.registrarVehiculo(autobus);

		empresa.asignarUnChoferAUnVehiculo(pepe, autobus);

		Chofer roberto = new Chofer("Roberto", 2);
		empresa.registrarChofer(roberto);

		empresa.cambiarElChoferDeUnVehiculo(roberto, autobus);

		assertTrue(empresa.buscarVehiculo(autobus).getChofer().equals(roberto));
	}

	@Test(expected = CantidadExcedidaDePasajeros.class)
	public void queAlAsignarMasDeTresAcompaniantesAUnAutomovilSeLanceUnaExcepcion()
			throws PasajeroYaExistente, CantidadExcedidaDePasajeros, VehiculoInexistente, PasajeroInexistente {
		Empresa empresa = new Empresa("Vroom Vroom");

		Pasajero acompaniante1 = new Pasajero("Mica", 1);
		Pasajero acompaniante2 = new Pasajero("Franco", 2);
		Pasajero acompaniante3 = new Pasajero("Pancho", 3);
		Pasajero acompaniante4 = new Pasajero("Coki", 4);

		empresa.registrarPasajeros(acompaniante1);
		empresa.registrarPasajeros(acompaniante2);
		empresa.registrarPasajeros(acompaniante3);
		empresa.registrarPasajeros(acompaniante4);

		Vehiculo auto = new Automovil(4643643d, 1);

		empresa.registrarVehiculo(auto);

		empresa.asignarPasajerosAUnVehiculo(acompaniante1, auto);
		empresa.asignarPasajerosAUnVehiculo(acompaniante2, auto);
		empresa.asignarPasajerosAUnVehiculo(acompaniante3, auto);
		empresa.asignarPasajerosAUnVehiculo(acompaniante4, auto);
	}
}
