package dominio;

public class patenteInvalida extends Exception {
	public patenteInvalida(String mensaje) {
		super(mensaje);
	}

}
