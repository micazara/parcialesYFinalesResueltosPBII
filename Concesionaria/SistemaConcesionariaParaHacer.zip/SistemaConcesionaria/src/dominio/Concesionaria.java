package dominio;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class Concesionaria {

	private String nombre;
	private Set<Coche> coches;

	public Concesionaria(String nombre) {
		this.nombre = nombre;
		this.coches = new TreeSet<>();
	}

	public void agregarCoche(Coche auto) {
		this.coches.add(auto);

	}

	public Integer obtenerCantidadDeCoches() {
		return this.coches.size();
	}

	public void eliminarCoche(Coche auto) {
		this.coches.remove(auto);

	}

	public String mostrarCoches() {
		// TODO Auto-generated method stub
		return this.coches.toString();
	}

	public Coche buscarPorPatente(String patente) throws patenteNoExisteException, patenteInvalida {
		// recorro el TreeSet de coches y si su patente es igual a la que yo llamo por
		// parametro y es una patente valida entonces devuelvo ese array, sino hago un
		// Exception donde no encuntre la patente
		
	}

	public ArrayList<Coche> buscarPorMarca(String marca) {
		// creo una coleccion de autos encontrados, lo recorro y si la marca de ese auto
		// q estoy por registrar es igual a la marca que le paso por parametro entonces
		// agreco ese coche a la coleccion y retorno la coleccion.
		
	}

	public boolean patenteValida(String patente) throws patenteInvalida {
		// si la patente tiene un tama�o mayor a nueve caracteres, es una patente valida sino
		// llamo al throw de Exception q avise
		
	}

	public TreeSet<Coche> ordenarPorMarcaYModelo() {
		// no se no entiendo el parametro TreeSet, ahi busco en google
		// lucas; si una clase implementa la interfaz comparator, los objetos creados a
		// partir de esa clase se pueden ordenar.
		// creo un arbol con autos ordenados, los autos van a estar ordenados porque ya
		// se instancia con la clase Ordenar.
		// es como usar un metodo ordenar de concesionaria con la diferencia de que es
		// mas efizcas usar una interfaz que los ordene por marca y modelo
		
		// agrego todos los autos a autosOrdenados
		
	}

	public TreeSet<Coche> ordenarPorPrecioYPatente() {
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
