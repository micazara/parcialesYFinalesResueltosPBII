package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.junit.Test;

import dominio.Coche;
import dominio.Concesionaria;
import dominio.patenteInvalida;
import dominio.patenteNoExisteException;

public class TestConcesionaria {

	@Test
	public void crearConcesionaria() {
		

	}

	@Test
	public void crearCoche() {
		// patente, marca, modelo, precio
		
	}

	@Test
	public void queSePuedaAgregarUnAutoALaConcesionaria() {
		

	}

	@Test
	public void queSePuedaEliminarUnAutoALaConcesionaria() {
		

	}

	@Test
	public void queSePuedanMostrarTodosLosCochesDeLaConcesionaria() {
		

	}

	@Test
	public void queNoSePuedaAgregarDosAutosConLaMismaPatente() {
		

	}

	@Test
	public void queSePuedaBuscarUnAutoPorPatente() throws patenteNoExisteException, patenteInvalida {
		
	}

	@Test
	public void queSePuedaBuscarAutosPorMarca() {
		
	}

	@Test
	public void queSePuedaOrdenarPorMarcaYModelo() {
		
	}

	@Test
	public void queSePuedaOrdenarCochesPorPrecioYPatente() {
		
	}

	@Test(expected = patenteInvalida.class)
	public void validarQueSeProduzcaUnaExcepcionSiLaPatenteEsInvalida() throws patenteInvalida {
		

	}

	@Test(expected = patenteNoExisteException.class)
	public void queAnteUnAutoInexistenteTermineConPatenteNoExisteException()
			throws patenteNoExisteException, patenteInvalida {
		

	}

	@Test(expected = patenteNoExisteException.class)
	public void queNoSePuedaBuscarUnAutoPorPatenteSiLaPatenteNoExiste()
			throws patenteNoExisteException, patenteInvalida {
		
	}

//	@Test
//	public void testAEleccion() {
//		Coche auto = new Coche("AF 546 HJ", "BMW", "M3", 130000.0);
//		Coche auto2 = new Coche("AE 223 DG", "Volkswagen", "Scirocco", 35000.0);
//		Coche auto3 = new Coche("AA 420 EG", "Mercedez", "A45", 65000.0);
//
//		Map<String, Coche> coches = new HashMap<>();
//		List<Coche> cochesMayorA10000 = new ArrayList<>();
//
//		coches.put("A", auto);
//		coches.put("B", auto2);
//		coches.put("C", auto3);
//		// map necesita una clave y un valor. se agrega con put de forma ordenada. el
//		// for recorre ese mapa y si su precio es mayor a diez mil entonces agrego esos
//		// coches mayores a 10000
//		for (Coche coche : coches.values()) {
//			if (coche.getPrecio() > 10000.0) {
//				cochesMayorA10000.add(coche);
//			}
//		}
//		// System.out.println();
//		// assertEquals(coches.get("a"), m4);
//
//	}
}
