package ar.edu.unlam.pb2;

public class NoSePuedenPrestarMasDeDosLibros extends Exception {

}
