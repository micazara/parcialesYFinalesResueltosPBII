package ar.edu.unlam.pb2;

public class LibroGeografia extends Libro implements Fotocopiable{

	public LibroGeografia(String autor, String nombre, Integer cod, Estado estado) {
		super(autor, nombre, cod, estado);
	}

	@Override
	public String fotocopiar() {
		return this.nombre;
	}

}
