package ar.edu.unlam.pb2;

public class LibroMatematica extends Libro {

	public LibroMatematica(String autor, String nombre, Integer cod, Estado estado) {
		super(autor, nombre, cod, estado);
	}

}
