package ar.edu.unlam.pb2;

import java.util.Objects;

public class Estudiante {

	public String apellido;
	public Long dni;
	public String nombre;

	public Estudiante(String apellido, Long dni, String nombre) {
		this.apellido = apellido;
		this.dni = dni;
		this.nombre = nombre;
	}

	String getApellido() {
		return apellido;
	}

	void setApellido(String apellido) {
		this.apellido = apellido;
	}

	Long getDni() {
		return dni;
	}

	void setDni(Long dni) {
		this.dni = dni;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Estudiante other = (Estudiante) obj;
		return Objects.equals(dni, other.dni);
	}

	@Override
	public String toString() {
		return "Estudiante [apellido=" + apellido + ", dni=" + dni + ", nombre=" + nombre + "]";
	}
	
	

}
