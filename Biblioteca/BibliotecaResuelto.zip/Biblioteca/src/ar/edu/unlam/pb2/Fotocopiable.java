package ar.edu.unlam.pb2;

public interface Fotocopiable {
	String fotocopiar();
}
