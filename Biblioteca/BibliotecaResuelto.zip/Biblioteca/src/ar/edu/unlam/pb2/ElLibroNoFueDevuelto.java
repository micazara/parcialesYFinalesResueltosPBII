package ar.edu.unlam.pb2;

public class ElLibroNoFueDevuelto extends Exception {

}
