package ar.edu.unlam.pb2;

public class NoSeEncontroElPrestamo extends Exception {

}
