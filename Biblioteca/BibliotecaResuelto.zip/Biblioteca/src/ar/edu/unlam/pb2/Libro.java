package ar.edu.unlam.pb2;

import java.util.Objects;

public class Libro {

	public String autor;
	public String nombre;
	public Integer cod;
	public Estado estado;

	public Libro(String autor, String nombre, Integer cod, Estado estado) {
		this.autor = autor;
		this.nombre = nombre;
		this.cod = cod;
		this.estado = estado;
	}

	String getAutor() {
		return autor;
	}

	void setAutor(String autor) {
		this.autor = autor;
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Integer getCod() {
		return cod;
	}

	void setCod(Integer cod) {
		this.cod = cod;
	}

	Estado getEstado() {
		return estado;
	}

	void setEstado(Estado estado) {
		this.estado = estado;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cod);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Libro other = (Libro) obj;
		return Objects.equals(cod, other.cod);
	}

}
