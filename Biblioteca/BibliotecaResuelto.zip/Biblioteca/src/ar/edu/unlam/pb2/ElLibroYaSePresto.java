package ar.edu.unlam.pb2;

public class ElLibroYaSePresto extends Exception {

}
