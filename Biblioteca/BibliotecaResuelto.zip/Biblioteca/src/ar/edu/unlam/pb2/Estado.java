package ar.edu.unlam.pb2;

public enum Estado {
DISPONIBLE, PRESTADO
}
