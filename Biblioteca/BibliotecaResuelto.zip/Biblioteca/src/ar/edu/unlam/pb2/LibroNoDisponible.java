package ar.edu.unlam.pb2;

public class LibroNoDisponible extends Exception {

}
