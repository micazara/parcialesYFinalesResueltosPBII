package ar.edu.unlam.pb2;

public class LibroHistoria extends Libro implements Fotocopiable {

	public LibroHistoria(String autor, String nombre, Integer cod, Estado estado) {
		super(autor, nombre, cod, estado);
	}

	@Override
	public String fotocopiar() {
		return this.nombre;
	}

}
