package ar.edu.unlam.pb2;

import java.util.Comparator;

public class EstudiantesOrdenadosPorApellido implements Comparator<Estudiante> {

	@Override
	public int compare(Estudiante o1, Estudiante o2) {
		// si dos apellidos son iguales
		if (o1.getApellido().compareTo(o2.getApellido()) == 0) {
			// compara por nombre
			return o1.getNombre().compareTo(o2.getNombre());
		} else {
			// sino compara por apellido
			return o1.getApellido().compareTo(o2.getApellido());
		}
	}
}
//	/**
//	 * 0> si el obj 1 es > obj2
//	 * 0< si el obj1 es < obj2
//	 * =0 cuando obj = obj2
//	 ** /
