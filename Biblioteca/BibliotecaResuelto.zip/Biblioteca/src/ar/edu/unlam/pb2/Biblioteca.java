package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Biblioteca {

	public String nombre;
	public Set<Libro> libros;
	public Set<Estudiante> estudiantes;
	private Set<Prestamo> prestamos;
	public Long idPrestamo;

	public Biblioteca(String nombre) {
		this.nombre = nombre;
		this.libros = new HashSet<Libro>();
		this.estudiantes = new HashSet<Estudiante>();
		this.prestamos = new HashSet<Prestamo>();
		this.idPrestamo = 0l;
	}

	public void agregarLibro(Libro libro) throws NoSePudoAgregarElLibro {
		if (!this.libros.add(libro)) {
			throw new NoSePudoAgregarElLibro();
		}

	}

	public Integer obtenerCantidadDeLibrosAgregados() {
		return this.libros.size();
	}

	public void agregarEstudiante(Estudiante estudiante) throws NoSePudoAgregarElEstudiante {
		if (!this.estudiantes.add(estudiante)) {
			throw new NoSePudoAgregarElEstudiante();
		}

	}

	public Integer cantidadDeEstudiantesAgregados() {
		return this.estudiantes.size();
	}

	public Boolean realizarPrestamo(Long dni, Integer codLibro)
			throws NoSePudoEncontrarElEstudiante, NoSePudoEncontrarElLibro, NoPuedenPrestarseMasDeDosLibros,
			ElLibroYaSePresto, ElLibroNoFueDevuelto, LibroNoDisponible {

		Estudiante estudianteBuscado = buscarEstudiante(dni);
		Libro libroBuscado = buscarLibro(codLibro);

		if (cantidadDeLibrosPrestados(estudianteBuscado) > 2) {
			throw new NoPuedenPrestarseMasDeDosLibros();
		} else if (elLibroEstaDisponible(libroBuscado)) {
			crearPrestamo(estudianteBuscado, libroBuscado);
			incrementarIdPrestamo();
			actualizarEstadoDelLibroLuegoDelPrestamo(libroBuscado);
			return true;
		}

		throw new LibroNoDisponible();
	}

	private Boolean elLibroEstaDisponible(Libro libroBuscado) {
		for (Prestamo prestamo : this.prestamos) {
			if (prestamo.getSolicitado().equals(libroBuscado) && libroBuscado.getEstado().equals(Estado.PRESTADO)) {
				return false;
			}
		}

		return true;
	}

	public Integer cantidadDeLibrosPrestados(Estudiante estudianteBuscado) {
		int conteo = 0;
		for (Prestamo actual : this.prestamos) {
			if (actual.getSolicitante().equals(estudianteBuscado)) {
				conteo++;
			}
		}
		return conteo;
	}

	private void actualizarEstadoDelLibroLuegoDelPrestamo(Libro solicitado) {
		solicitado.setEstado(Estado.PRESTADO);
	}

	private void crearPrestamo(Estudiante solicitante, Libro solicitado) {
		this.prestamos.add(new Prestamo(this.idPrestamo, solicitante, solicitado));
	}

	private void incrementarIdPrestamo() {
		this.idPrestamo++;
	}

	public Integer obtenerCantidadDePrestamosRealizados() {
		return this.prestamos.size();
	}

	private Libro buscarLibro(Integer cod) throws NoSePudoEncontrarElLibro {
		for (Libro actual : this.libros) {
			if (actual.getCod().equals(cod)) {
				return actual;
			}
		}

		throw new NoSePudoEncontrarElLibro();
	}

	private Estudiante buscarEstudiante(Long dni) throws NoSePudoEncontrarElEstudiante {
		for (Estudiante actual : this.estudiantes) {
			if (actual.getDni().equals(dni)) {
				return actual;
			}
		}

		throw new NoSePudoEncontrarElEstudiante();
	}

	Long getIdPrestamo() {
		return idPrestamo;
	}

	void setIdPrestamo(Long idPrestamo) {
		this.idPrestamo = idPrestamo;
	}

	public Boolean devolverLibro(Long dni, Integer codLibro)
			throws ElLibroNoSePresto, NoSePudoEncontrarElLibro, ElLibroNoSeEncontroEnNingunPrestamo,
			NoSePudoEncontrarElEstudiante, ElLibroNoFuePrestado, NoSeEncontroElPrestamo {
		Estudiante estudianteBuscado = buscarEstudiante(dni);
		Libro libroBuscado = buscarLibro(codLibro);

		if (elLibroFuePrestado(estudianteBuscado, libroBuscado)) {
			Prestamo prestamo = obtenerPrestamoActivo(estudianteBuscado, libroBuscado);
			this.prestamos.remove(prestamo);
			actualizarEstadoDelLibroLuegoDeLaDevolucion(libroBuscado);
			return true;
		} else {
			return false;
		}

	}

	private Prestamo obtenerPrestamoActivo(Estudiante estudianteBuscado, Libro libroBuscado)
			throws NoSeEncontroElPrestamo {
		for (Prestamo actual : this.prestamos) {
			if (actual.getSolicitado().equals(libroBuscado) && actual.getSolicitante().equals(estudianteBuscado)) {
				return actual;
			}
		}

		throw new NoSeEncontroElPrestamo();
	}

	private void actualizarEstadoDelLibroLuegoDeLaDevolucion(Libro libroBuscado) {
		libroBuscado.setEstado(Estado.DISPONIBLE);

	}

	private Boolean elLibroFuePrestado(Estudiante estudianteBuscado, Libro libroBuscado) throws ElLibroNoFuePrestado {
		for (Prestamo prestamo : this.prestamos) {
			if (prestamo.getSolicitante().equals(estudianteBuscado) && prestamo.getSolicitado().equals(libroBuscado)
					&& prestamo.getSolicitado().getEstado().equals(Estado.PRESTADO)) {
				return true;
			}
		}

		throw new ElLibroNoFuePrestado();
	}

	String getNombre() {
		return nombre;
	}

	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Set<Libro> getLibros() {
		return libros;
	}

	void setLibros(Set<Libro> libros) {
		this.libros = libros;
	}

	Set<Estudiante> getEstudiantes() {
		return estudiantes;
	}

	void setEstudiantes(Set<Estudiante> estudiantes) {
		this.estudiantes = estudiantes;
	}

	Set<Prestamo> getPrestamos() {
		return prestamos;
	}

	void setPrestamos(Set<Prestamo> prestamos) {
		this.prestamos = prestamos;
	}

	public TreeSet<Estudiante> ordenarLosEstudiantesPorApellido() {
		TreeSet<Estudiante> estudiantesOrdenados = new TreeSet<Estudiante>(new EstudiantesOrdenadosPorApellido());
		estudiantesOrdenados.addAll(this.estudiantes);
		return estudiantesOrdenados;

	}

	public TreeSet<Libro> obtenerLosLibrosQuePidioPrestadoUnEstudiantePorOrdenAlfabetico(Estudiante estudiante) {
		TreeSet<Libro> librosOrdenadosPorNombre = new TreeSet<Libro>(new LibrosOrdenadosPorNombre());
		for (Prestamo actual : this.prestamos) {
			if (actual.getSolicitante().equals(estudiante)) {
				Libro libroSolicitado = actual.getSolicitado();
				librosOrdenadosPorNombre.add(libroSolicitado);
			}

		}

		return librosOrdenadosPorNombre;

	}

}
