package ar.edu.unlam.pb2;

public class ElLibroNoSePresto extends Exception {

}
