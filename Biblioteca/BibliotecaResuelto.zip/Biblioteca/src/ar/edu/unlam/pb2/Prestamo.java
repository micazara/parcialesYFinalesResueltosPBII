package ar.edu.unlam.pb2;

import java.util.Objects;
import java.util.Set;

public class Prestamo {

	public Long id;
	public Estudiante solicitante;
	public Libro solicitado;

	public Prestamo(Long id, Estudiante solicitante, Libro solicitado) {
		this.id = id;
		this.solicitante = solicitante;
		this.solicitado = solicitado;
	}

	Long getId() {
		return id;
	}

	void setId(Long id) {
		this.id = id;
	}

	Estudiante getSolicitante() {
		return solicitante;
	}

	void setSolicitante(Estudiante solicitante) {
		this.solicitante = solicitante;
	}

	Libro getSolicitado() {
		return solicitado;
	}

	void setSolicitado(Libro solicitado) {
		this.solicitado = solicitado;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
//		if (getClass() != obj.getClass())
//			return false;
		Prestamo other = (Prestamo) obj;
		return Objects.equals(id, other.id);
	}

}
