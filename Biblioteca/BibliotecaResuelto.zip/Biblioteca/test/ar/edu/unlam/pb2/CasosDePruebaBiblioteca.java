package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import java.util.TreeSet;

import org.junit.Test;

public class CasosDePruebaBiblioteca {

	@Test
	public void queSePuedaAgregarunLibroALaBiblioteca() throws NoSePudoAgregarElLibro {
		Biblioteca b = new Biblioteca("b");

		Libro libro = new LibroGeografia("Mica", "Montanias y mas", 1, Estado.DISPONIBLE);
		b.agregarLibro(libro);
		Integer cantidadDeLibrosActual = b.obtenerCantidadDeLibrosAgregados();
		Integer cantidadDeLibrosEsperada = 1;

		assertEquals(cantidadDeLibrosEsperada, cantidadDeLibrosActual);
		assertTrue(b.getLibros().contains(libro));
	}

	@Test
	public void queSePuedaAgregarUnEstudianteAUnaBiblioteca() throws NoSePudoAgregarElEstudiante {
		Biblioteca b = new Biblioteca("b");

		Estudiante estudiante = new Estudiante("Zara", 44892966l, "Micaela");

		b.agregarEstudiante(estudiante);

		Integer cantidadDeEstudiantesActual = b.cantidadDeEstudiantesAgregados();
		Integer cantidadDeEstudiantesEsperada = 1;

		assertEquals(cantidadDeEstudiantesEsperada, cantidadDeEstudiantesActual);
		assertTrue(b.getEstudiantes().contains(estudiante));

	}

	@Test
	public void queSePuedaRealizarUnPrestamo() throws NoSePudoAgregarElLibro, NoSePudoAgregarElEstudiante,
			NoSePudoEncontrarElEstudiante, NoSePudoEncontrarElLibro, NoPuedenPrestarseMasDeDosLibros, ElLibroYaSePresto,
			ElLibroNoFueDevuelto, LibroNoDisponible {
		Biblioteca b = new Biblioteca("b");

		Integer cod1 = 1;
		Libro libro = new LibroGeografia("Mica", "Montanias y mas", cod1, Estado.DISPONIBLE);
		b.agregarLibro(libro);

		Long dni = 44892966l;
		Estudiante estudiante = new Estudiante("Zara", dni, "Micaela");
		b.agregarEstudiante(estudiante);

		Boolean resultado = b.realizarPrestamo(dni, cod1);

		Integer cantidadDePrestamosActual = b.obtenerCantidadDePrestamosRealizados();
		Integer cantidadDePrestamosEsperada = 1;

		Estado ESTADO_FINAL_ESPERADO = Estado.PRESTADO;

		assertEquals(cantidadDePrestamosEsperada, cantidadDePrestamosActual);
		assertTrue(resultado);
		assertEquals(libro.getEstado(), ESTADO_FINAL_ESPERADO);
	}

	@Test(expected = LibroNoDisponible.class)
	public void queNoSePuedaVolverAPrestarElMismoLibro() throws NoSePudoEncontrarElEstudiante, NoSePudoEncontrarElLibro,
			NoPuedenPrestarseMasDeDosLibros, ElLibroYaSePresto, NoSePudoAgregarElEstudiante, NoSePudoAgregarElLibro,
			ElLibroNoFueDevuelto, LibroNoDisponible {

		Biblioteca b = new Biblioteca("b");

		Integer cod1 = 1;
		Libro libro = new LibroGeografia("Mica", "Montanias y mas", cod1, Estado.DISPONIBLE);
		b.agregarLibro(libro);

		Long dni = 44892966l;
		Estudiante estudiante = new Estudiante("Zara", dni, "Micaela");
		b.agregarEstudiante(estudiante);

		b.realizarPrestamo(dni, cod1);

		// ahora otro estudiante quiere pedir prestados esos libros
		Estudiante estudiante2 = new Estudiante("gdfgdfg", 999999l, "dfgdfgd");
		b.agregarEstudiante(estudiante2);

		b.realizarPrestamo(999999l, cod1);

	}

	@Test
	public void queSePuedaDevolverUnLibro() throws NoSePudoAgregarElLibro, NoSePudoAgregarElEstudiante,
			NoSePudoEncontrarElEstudiante, NoSePudoEncontrarElLibro, NoPuedenPrestarseMasDeDosLibros, ElLibroYaSePresto,
			ElLibroNoFueDevuelto, ElLibroNoSePresto, ElLibroNoSeEncontroEnNingunPrestamo, LibroNoDisponible,
			ElLibroNoFuePrestado, NoSeEncontroElPrestamo {
		// si se realizo un prestamo de ese libro, lo devuelvo
		Biblioteca b = new Biblioteca("b");

		Integer cod1 = 1;
		Libro libro = new LibroGeografia("Mica", "Montanias y mas", cod1, Estado.DISPONIBLE);
		b.agregarLibro(libro);

		Long dni = 44892966l;
		Estudiante estudiante = new Estudiante("Zara", dni, "Micaela");
		b.agregarEstudiante(estudiante);

		b.realizarPrestamo(dni, cod1);

		b.devolverLibro(dni, cod1);

		Integer cantidadActualDePrestamos = b.obtenerCantidadDePrestamosRealizados();
		Integer cantidadEsperadaDePretamos = 0;

		Estado estadoEsperadoDelLibro = Estado.DISPONIBLE;
		Estado estadoActualDelLibro = libro.getEstado();
		assertEquals(cantidadEsperadaDePretamos, cantidadActualDePrestamos);
		assertEquals(estadoEsperadoDelLibro, estadoActualDelLibro);
	}

	@Test
	public void queSePuedanOrdenarLosEstudiantesPorApellido() throws NoSePudoAgregarElEstudiante {
		Biblioteca b = new Biblioteca("b");
		Estudiante estudiante = new Estudiante("Zara", 1l, "Micaela");
		Estudiante estudiante2 = new Estudiante("Sepulveda", 2l, "Franco");
		Estudiante estudiante3 = new Estudiante("A", 3l, "B");

		b.agregarEstudiante(estudiante);
		b.agregarEstudiante(estudiante2);
		b.agregarEstudiante(estudiante3);

		TreeSet<Estudiante> estudiantesOrdenados = b.ordenarLosEstudiantesPorApellido();
		Estudiante primerEstudiante = estudiantesOrdenados.first();
		Estudiante ultimoEstudiante = estudiantesOrdenados.last();

		assertEquals(primerEstudiante, estudiante3);
		assertEquals(ultimoEstudiante, estudiante);
	}

	@Test
	public void queCuandoDosApellidosSonIgualesSeOrdenePorNombre() throws NoSePudoAgregarElEstudiante {
		Biblioteca b = new Biblioteca("b");
		Estudiante estudiante = new Estudiante("Zara", 1l, "Micaela");
		Estudiante estudiante2 = new Estudiante("A", 2l, "Franco");
		Estudiante estudiante3 = new Estudiante("A", 3l, "B");

		b.agregarEstudiante(estudiante);
		b.agregarEstudiante(estudiante2);
		b.agregarEstudiante(estudiante3);

		TreeSet<Estudiante> estudiantesOrdenados = b.ordenarLosEstudiantesPorApellido();

		Estudiante primerEstudianteEsperado = estudiantesOrdenados.first();
		Estudiante ultimoEstudianteEsperado = estudiantesOrdenados.last();

		assertEquals(primerEstudianteEsperado, estudiante3);
		assertEquals(ultimoEstudianteEsperado, estudiante);
	}

	@Test
	public void queSePuedaObtenerLaCantidadDeLibrosPrestadosAUnEstudiante() throws NoSePudoAgregarElLibro,
			NoSePudoAgregarElEstudiante, NoSePudoEncontrarElEstudiante, NoSePudoEncontrarElLibro,
			NoPuedenPrestarseMasDeDosLibros, ElLibroYaSePresto, ElLibroNoFueDevuelto, LibroNoDisponible {
		Biblioteca b = new Biblioteca("b");

		Integer cod1 = 1;
		Libro geografia = new LibroGeografia("Mica", "Montanias y mas", cod1, Estado.DISPONIBLE);
		Integer cod2 = 2;
		Libro matematica = new LibroMatematica("Pitagoras", "La vida de Pitagoras", cod2, Estado.DISPONIBLE);
		b.agregarLibro(geografia);
		b.agregarLibro(matematica);

		Long dni = 44892966l;
		Estudiante estudiante = new Estudiante("Zara", dni, "Micaela");
		Long dni2 = 123456789l;
		Estudiante estudiante2 = new Estudiante("Sepulveda", dni2, "Franco");
		b.agregarEstudiante(estudiante);
		b.agregarEstudiante(estudiante2);

		// el estudiante dos realiza dos prestamos
		b.realizarPrestamo(dni2, cod1);
		b.realizarPrestamo(dni2, cod2);

		Integer cantidadDeLibrosPrestadosActual = b.cantidadDeLibrosPrestados(estudiante2);
		assertEquals((Integer) 2, cantidadDeLibrosPrestadosActual);
	}

	@Test
	public void queSePuedanObtenerLosLibrosQuePidioPrestadoUnEstudiantePorOrdenAlfabetico()
			throws NoSePudoAgregarElLibro, NoSePudoAgregarElEstudiante, NoSePudoEncontrarElEstudiante, NoSePudoEncontrarElLibro, NoPuedenPrestarseMasDeDosLibros, ElLibroYaSePresto, ElLibroNoFueDevuelto, LibroNoDisponible {
		
		Biblioteca b = new Biblioteca("b");

		Integer cod1 = 1;
		Libro geografia = new LibroGeografia("Mica", "Montanias y mas", cod1, Estado.DISPONIBLE);
		Integer cod2 = 2;
		Libro matematica = new LibroMatematica("Pitagoras", "La vida de Pitagoras", cod2, Estado.DISPONIBLE);

		b.agregarLibro(geografia);
		b.agregarLibro(matematica);

		Long dni = 44892966l;
		Estudiante estudiante = new Estudiante("Zara", dni, "Micaela");

		b.agregarEstudiante(estudiante);

		b.realizarPrestamo(dni, cod1);
		b.realizarPrestamo(dni, cod2);
		
		TreeSet<Libro> librosOrdenados = b.obtenerLosLibrosQuePidioPrestadoUnEstudiantePorOrdenAlfabetico(estudiante);
		Libro primerLibro = librosOrdenados.first();
		Libro ultimoLibro = librosOrdenados.last();
		
		assertEquals(matematica, primerLibro);
		assertEquals(geografia, ultimoLibro);
	}

}
