package ar.edu.unlam.pb2;

import static org.junit.Assert.*;
import java.util.PrimitiveIterator;
import java.util.TreeSet;

import org.junit.Test;

public class TestCase {

	@Test
	public void queSePuedaRegistrarUnaPelicula() throws PeliculaExistenteException {

		Cine cine = new Cine("hoyts");

		Integer codigoPelicula = 1;

		String descripcion = "Duro De matar";
		Integer duracion = 105; // minutos

		Pelicula pelicula = new Pelicula(descripcion, duracion);
		cine.registrarPelicula(codigoPelicula, pelicula);

		assertEquals((Integer) 1, cine.obtenerCantidadDePeliculasRegistradas());
	}

	@Test(expected = PeliculaExistenteException.class)
	public void queAlRegistrarUnaPeliculaDuplicadaLanceUnaExpcionPeliculaDuplicadaException()
			throws PeliculaExistenteException {

		Cine cine = new Cine("hoyts");
		Integer codigoPelicula = 1;
		String descripcion = "Duro De matar";
		Integer duracion = 105; // minutos

		Pelicula pelicula = new Pelicula(descripcion, duracion);
		cine.registrarPelicula(codigoPelicula, pelicula);

		Pelicula pelicula2 = new Pelicula("Instinto", 95);

		cine.registrarPelicula(codigoPelicula, pelicula2);

	}

	@Test
	public void queSePuedaRegistrarUnaSalaEnElCine() throws SalaDuplicadaException {
		Cine cine = new Cine("hoyts");
		String nombreSala = "sala 1";
		Sala salaProyeccion = new SalaProyeccion(nombreSala);
		cine.registrarSala(salaProyeccion);

		assertEquals((Integer) 1, cine.obtenerCantidadDeSalasRegistradas());
	}

	@Test
	public void queSePuedaAsignarUnaPeliculaEnUnaSalaProyecciones()
			throws PeliculaExistenteException, SalaDuplicadaException, PeliculaInexistente, SalaInexistente,
			TipoDeSalaNoCompatible, NoSePudoEncontrarLaPeliculaQueSeProyecta {

		Cine cine = new Cine("hoyts");

		Pelicula pelicula = new Pelicula("Instinto", 95);

		Integer codigoPelicula = 1;
		cine.registrarPelicula(codigoPelicula, pelicula);

		String nombreSala = "sala 1";
		Sala salaProyeccion = new SalaProyeccion(nombreSala);

		cine.registrarSala(salaProyeccion);

		cine.registrarPeliculaAUnaSala(codigoPelicula, nombreSala);

		Pelicula peliculaRegistrarEnLaSalaProyeccion = ((SalaProyeccion) salaProyeccion).obtenerPeliculaQueSeProyecta();

		assertEquals(pelicula, peliculaRegistrarEnLaSalaProyeccion);

	}

	@Test
	public void queSePuedaAsignarUnaPeliculaEnUnaSalaProyecionTienda() throws PeliculaExistenteException,
			SalaDuplicadaException, PeliculaInexistente, SalaInexistente, TipoDeSalaNoCompatible {

		Cine cine = new Cine("hoyts");

		Pelicula pelicula = new Pelicula("Instinto", 95);
		Integer codigoPelicula = 1;
		cine.registrarPelicula(codigoPelicula, pelicula);

		String nombreSalaTienda = "Tienda";
		SalaTienda salaTienda = new SalaTienda(nombreSalaTienda);

		String nombreSalaProyeccion = "Proyeccion";
		SalaProyeccion salaProyeccion = new SalaProyeccion(nombreSalaProyeccion);

		String nombreSalaTiendaProyeccion = "ProyeccionTienda";
		Sala salaProyecionTienda = new ProyeccionTienda(nombreSalaTiendaProyeccion, salaTienda, salaProyeccion);

		cine.registrarSala(salaProyecionTienda);

		cine.registrarPeliculaAUnaSala(codigoPelicula, nombreSalaTiendaProyeccion);

		Pelicula peliculaQueSeProyectaEnSalaProyeccionTienda = ((ProyeccionTienda) salaProyecionTienda)
				.getSalaProyeccion().obtenerPeliculaQueSeProyecta();

		assertEquals(pelicula, peliculaQueSeProyectaEnSalaProyeccionTienda);
	}

	@Test
	public void queSePuedaAlRegistrarUnaVentaEnSalaTienda()
			throws SalaDuplicadaException, SalaInexistente, TipoDeSalaNoCompatible {

		Cine cine = new Cine("hoyts");

		String nombre = "sala 1";
		Sala salaTienda = new SalaTienda(nombre);

		cine.registrarSala(salaTienda);

		Integer numeroVenta = 1;
		Double monto = 100d;
		Venta venta = new Venta(numeroVenta, monto);
		cine.registrarVentaAUnaSala(nombre, venta);

		SalaTienda salaEncontrada = (SalaTienda) cine.buscarSalaTienda(nombre);
		Integer cantidadDeVentasRegistradas = salaEncontrada.obtenerCantidadDeVentasRegistradas();

		assertEquals((Integer) 1, cantidadDeVentasRegistradas);
		assertEquals((Integer) 1, cine.obtenerCantidadDeSalasRegistradas());

	}

	@Test
	public void queSePuedaAlRegistrarUnaVentaEnSalaProyeccionTienda()
			throws SalaDuplicadaException, SalaInexistente, TipoDeSalaNoCompatible {

		Cine cine = new Cine("hoyts");

		SalaTienda tienda = new SalaTienda("Tienda");
		SalaProyeccion salaproyeccion = new SalaProyeccion("proyeccion");

		String nombresala = "ProyeccionTienda";
		Sala salaProyeccionTienda = new ProyeccionTienda(nombresala, tienda, salaproyeccion);

		cine.registrarSala(salaProyeccionTienda);

		Integer numeroVenta = 1;

		Double monto = 100d;
		Venta venta = new Venta(numeroVenta, monto);

		cine.registrarVentaAUnaSala(nombresala, venta);

		Double montoEsperado = ((ProyeccionTienda) salaProyeccionTienda).getSalaTienda().obtenerTotalDeVenta();
		Venta ventaEsperada = ((ProyeccionTienda) salaProyeccionTienda).getSalaTienda().ventas.get(0);

		assertEquals(venta.getMonto(), montoEsperado);
		assertEquals(venta, ventaEsperada);

	}

	@Test
	public void queSeCalculeCorrectamenteElTotalDeVentasDeTodasLasSalasDetipoTiendas()
			throws SalaInexistente, TipoDeSalaNoCompatible, SalaDuplicadaException {

		Cine cine = new Cine("hoyts");

		String nombre = "sala Tienda";
		Sala salaTienda = new SalaTienda(nombre);

		cine.registrarSala(salaTienda);

		Integer numeroVenta = 1;
		Double monto = 100d;
		Venta venta = new Venta(numeroVenta, monto);
		cine.registrarVentaAUnaSala(nombre, venta);

		SalaTienda tienda = new SalaTienda("Tienda");
		SalaProyeccion salaproyeccion = new SalaProyeccion("proyeccion");

		String nombreProyeccionTienda = "salaMixta";
		Sala salaProyeccionTienda = new ProyeccionTienda(nombreProyeccionTienda, tienda, salaproyeccion);

		cine.registrarSala(salaProyeccionTienda);

		Integer numeroVenta2 = 2;
		Double monto2 = 300d;
		Venta venta2 = new Venta(numeroVenta2, monto2);
		cine.registrarVentaAUnaSala(nombreProyeccionTienda, venta2);

		Double valorEsperado = 400d;
		Double valorObtenido = cine.obtenerElTotalDeVentasDeTodasLasSalasTiendas();
		assertEquals(valorEsperado, valorObtenido);

	}

	@Test
	public void queSePuedaObtenerLasPeliculasQueSeProyectaEnTodasLasSalasOrdenasPorNombre()
			throws PeliculaExistenteException, SalaDuplicadaException, PeliculaInexistente, SalaInexistente,
			TipoDeSalaNoCompatible {
		Cine cine = new Cine("hoyts");
		Pelicula pelicula = new Pelicula("ZZZZZZ", 95);

		Integer codigoPelicula = 1;
		cine.registrarPelicula(codigoPelicula, pelicula);

		String nombreSala = "sala 1";
		Sala salaProyeccion = new SalaProyeccion(nombreSala);

		cine.registrarSala(salaProyeccion);

		cine.registrarPeliculaAUnaSala(codigoPelicula, nombreSala);

		Pelicula pelicula2 = new Pelicula("La La Land", 120);

		Integer codigoPelicula2 = 2;
		cine.registrarPelicula(codigoPelicula2, pelicula2);

		String nombreSala2 = "sala 2";
		Sala salaProyeccion2 = new SalaProyeccion(nombreSala2);

		cine.registrarSala(salaProyeccion2);

		cine.registrarPeliculaAUnaSala(codigoPelicula2, nombreSala2);

		TreeSet<Pelicula> peliculasOrdenadasPorNombre = cine.obtenerTodasLasPeliculasQueSeProyectanOrdenadasPorNombre();

		Pelicula primerPelicula = peliculasOrdenadasPorNombre.first();
		Pelicula ultimaPelicula = peliculasOrdenadasPorNombre.last();

		assertEquals(pelicula2, primerPelicula);
		assertEquals(pelicula, ultimaPelicula);
	}
}
