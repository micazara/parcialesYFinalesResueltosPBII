package ar.edu.unlam.pb2;

import java.util.Comparator;

public class PeliculasOrdenadasPorNombre implements Comparator<Pelicula> {

	@Override
	public int compare(Pelicula o1, Pelicula o2) {
		return o1.getDescripcion().compareTo(o2.getDescripcion());
	}

}
