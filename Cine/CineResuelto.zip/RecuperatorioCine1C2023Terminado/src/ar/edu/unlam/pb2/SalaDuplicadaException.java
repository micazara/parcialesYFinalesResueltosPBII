package ar.edu.unlam.pb2;

public class SalaDuplicadaException extends Exception {

}
