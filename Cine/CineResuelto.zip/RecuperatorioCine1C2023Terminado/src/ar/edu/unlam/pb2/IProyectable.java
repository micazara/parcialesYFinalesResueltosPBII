package ar.edu.unlam.pb2;

public interface IProyectable {

	void asiganarPelicula(Pelicula pelicula);

	Pelicula obtenerPeliculaQueSeProyecta();
}
