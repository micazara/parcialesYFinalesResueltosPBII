package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Set;

public class SalaProyeccion extends Sala implements IProyectable {

	public Set<Pelicula> peliculasQueSeProyectan;
	private Pelicula peliculaQueSeProyecta;

	public SalaProyeccion(String nombre) {
		super(nombre);
		this.peliculasQueSeProyectan = new HashSet<Pelicula>();
	}

	@Override
	public void asiganarPelicula(Pelicula pelicula) {
		this.peliculaQueSeProyecta = pelicula;
		this.peliculasQueSeProyectan.add(pelicula);
	}

	@Override
	public Pelicula obtenerPeliculaQueSeProyecta() {
		return this.peliculaQueSeProyecta;
	}

}
