package ar.edu.unlam.pb2;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Cine {
	// EN Los cines hay 3 tipos de salas Proyectables , Tiendas, ProyectablesTiendas

	// No cambisar
	private Map<Integer, Pelicula> peliculas;

	// No pueden existir 2 Salas con el mismo nombre
	private Set<Sala> salas;

	private String nombre;

	/*
	 * Busca la sala Por nombre. y registra la venta en en dicha sala\ en caso de no
	 * encontrar la tienda lanza una excpetion. Las ventas solamente se registran en
	 * las salas Tienda y en las TiendasPreyectables. Las salas Proyectables no
	 * registranventas. En caso que se quiera Asiganar una venta en estos tipos de
	 * salas lanza una exception VentaSalaException
	 */

	public Cine(String nombre) {
		this.nombre = nombre;
		this.peliculas = new HashMap<Integer, Pelicula>();
		this.salas = new HashSet<Sala>();

	}

	/*
	 * busca la sala por nombre y registra La Venta en caso que se registre una
	 * venta en una sala de proyeccion lanza una exception SalaException
	 * 
	 */
	public void registrarVentaAUnaSala(String nombreDeSalaABuscar, Venta venta)
			throws SalaInexistente, TipoDeSalaNoCompatible {
		// me tiene q devolver una sala tienda
		Sala salaTiendaBuscada = buscarSalaTienda(nombreDeSalaABuscar);
		if (esUnaSalaTienda(salaTiendaBuscada)) {
			((iTienda) salaTiendaBuscada).registrarVenta(venta);
		} else {
			throw new TipoDeSalaNoCompatible();
		}
	}

	private boolean esUnaSalaTienda(Sala buscada) {
		return buscada instanceof iTienda;
	}

	public Sala buscarSalaTienda(String nombreDeSalaABuscar) throws SalaInexistente {
		for (Sala actual : this.salas) {
			if (actual.getNombre().equals(nombreDeSalaABuscar)) {
				return actual;
			}
		}
		throw new SalaInexistente();
	}

	public Double obtenerElTotalDeVentasDeTodasLasSalasTiendas() throws SalaInexistente {
		// para cada sala tienda tengo q obtener el monto de la venta y acumularlo
		Double totalDeVenta = 0.0;
		for (Sala actual : this.salas) {
			if (actual instanceof iTienda) {
				totalDeVenta += ((iTienda) actual).obtenerTotalDeVenta();
			}
		}
		return totalDeVenta;
	}

	// Si el codigo Pelicula esta duplicado Lanza una Exception
	// PeliculaExistenteExeption
	public void registrarPelicula(Integer codigo, Pelicula pelicula) throws PeliculaExistenteException {
		if (this.peliculas.containsKey(codigo)) {
			throw new PeliculaExistenteException();
		}
		this.peliculas.put(codigo, pelicula);

	}

	public Integer obtenerCantidadDePeliculasRegistradas() {
		return this.peliculas.size();
	}

	/*
	 * registra Una sala No se pueden registrar 2 salas con el mismo nombre, en caso
	 * que este se repita lanza Una Exception SalaDuplicadaException
	 * 
	 */
	public void registrarSala(Sala sala) throws SalaDuplicadaException {
		if (!this.salas.add(sala)) {
			throw new SalaDuplicadaException();
		}

	}

	public Integer obtenerCantidadDeSalasRegistradas() {
		return this.salas.size();
	}

	/*
	 * Registra una pelicula en las salas de proyecciones en caso que la pelicula no
	 * existe lanza exception en caso que la sala no exista launa excpetion
	 * salaInixistennte xception
	 */

	// Registrar Una pelicula en una sala donde se preyectan una Pelicula
	// en caso que se registre una pelicula en una sala de tienda lanza una
	// exception SalaException
	public void registrarPeliculaAUnaSala(Integer codigoPelicula, String nombreSala)
			throws PeliculaInexistente, SalaInexistente, TipoDeSalaNoCompatible {

		// 1) Buscar pelicula
		Pelicula peliculaBuscada = buscarPelicula(codigoPelicula);
		// 2) Buscar sala
		Sala salaDeProyeccionBuscada = buscarSalaDeProyeccion(nombreSala);

		if (esProyectable(salaDeProyeccionBuscada)) {
			((IProyectable) salaDeProyeccionBuscada).asiganarPelicula(peliculaBuscada);
		} else {
			throw new TipoDeSalaNoCompatible();
		}
	}

	private boolean esProyectable(Sala salaDeProyeccionBuscada) {
		return salaDeProyeccionBuscada instanceof IProyectable;
	}

	private Sala buscarSalaDeProyeccion(String nombreSala) throws SalaInexistente {
		for (Sala actual : this.salas) {
			if (actual.getNombre().equals(nombreSala)) {
				return actual;
			}
		}
		throw new SalaInexistente();
	}

	private Pelicula buscarPelicula(Integer codigoPelicula) throws PeliculaInexistente {
		if (this.peliculas.containsKey(codigoPelicula)) {
			return this.peliculas.get(codigoPelicula);
		}
		throw new PeliculaInexistente();
	}

	public TreeSet<Pelicula> obtenerTodasLasPeliculasQueSeProyectanOrdenadasPorNombre() {
		// si la sala es iproyectable
		TreeSet<Pelicula> peliculasOrdenadasPorNombre = new TreeSet<Pelicula>(new PeliculasOrdenadasPorNombre());
		for (Sala actual : this.salas) {
			if (esProyectable(actual)) {
				Pelicula pelicula = ((IProyectable) actual).obtenerPeliculaQueSeProyecta();
				peliculasOrdenadasPorNombre.add(pelicula);
			}
		}
		return peliculasOrdenadasPorNombre;

	}

}
