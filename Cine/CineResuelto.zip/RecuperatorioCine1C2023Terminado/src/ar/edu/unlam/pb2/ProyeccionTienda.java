package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class ProyeccionTienda extends Sala implements IProyectable, iTienda {

	public Set<Pelicula> peliculasQueSeProyectan;
	public List<Venta> ventas;
	public SalaProyeccion salaProyeccion;
	public SalaTienda salaTienda;
	public Pelicula peliculaQueSeProyecta;

	public ProyeccionTienda(String nombreSala, SalaTienda salaTienda, SalaProyeccion salaProyeccion) {
		super(nombreSala);
		this.peliculasQueSeProyectan = new HashSet<Pelicula>();
		this.ventas = new LinkedList<Venta>();
		this.salaTienda = salaTienda;
		this.salaProyeccion = salaProyeccion;
	}

	@Override
	public void registrarVenta(Venta venta) {
		this.salaTienda.registrarVenta(venta);

	}

	@Override
	public Double obtenerTotalDeVenta() {
		return this.salaTienda.obtenerTotalDeVenta();
	}

	@Override
	public void asiganarPelicula(Pelicula pelicula) {
		salaProyeccion.asiganarPelicula(pelicula);
	}

	@Override
	public Pelicula obtenerPeliculaQueSeProyecta() {
		return salaProyeccion.obtenerPeliculaQueSeProyecta();

	}

	Set<Pelicula> getPeliculasQueSeProyectan() {
		return peliculasQueSeProyectan;
	}

	void setPeliculasQueSeProyectan(Set<Pelicula> peliculasQueSeProyectan) {
		this.peliculasQueSeProyectan = peliculasQueSeProyectan;
	}

	List<Venta> getVentas() {
		return ventas;
	}

	void setVentas(List<Venta> ventas) {
		this.ventas = ventas;
	}

	SalaProyeccion getSalaProyeccion() {
		return salaProyeccion;
	}

	void setSalaProyeccion(SalaProyeccion salaProyeccion) {
		this.salaProyeccion = salaProyeccion;
	}

	SalaTienda getSalaTienda() {
		return salaTienda;
	}

	void setSalaTienda(SalaTienda salaTienda) {
		this.salaTienda = salaTienda;
	}

	Pelicula getPeliculaQueSeProyecta() {
		return peliculaQueSeProyecta;
	}

	void setPeliculaQueSeProyecta(Pelicula peliculaQueSeProyecta) {
		this.peliculaQueSeProyecta = peliculaQueSeProyecta;
	}

}
