package ar.edu.unlam.pb2;

import java.util.LinkedList;
import java.util.List;

public class SalaTienda extends Sala implements iTienda {

	List<Venta> ventas;

	public SalaTienda(String nombre) {
		super(nombre);
		this.ventas = new LinkedList<Venta>();
	}

	@Override
	public void registrarVenta(Venta venta) {
		this.ventas.add(venta);

	}

	@Override
	public Double obtenerTotalDeVenta() {
		Double totalDeVenta = 0.0;
		for (Venta actual : this.ventas) {
			totalDeVenta += actual.getMonto();
		}
		return totalDeVenta;
	}

	public Integer obtenerCantidadDeVentasRegistradas() {
		return this.ventas.size();
	}

}
