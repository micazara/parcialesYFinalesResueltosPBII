package ar.edu.unlam.pb2;

public interface iTienda {
	void registrarVenta(Venta venta);

	Double obtenerTotalDeVenta();
}
