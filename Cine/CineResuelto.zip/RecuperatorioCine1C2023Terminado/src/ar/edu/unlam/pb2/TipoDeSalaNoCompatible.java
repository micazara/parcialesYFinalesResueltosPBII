package ar.edu.unlam.pb2;

public class TipoDeSalaNoCompatible extends Exception {

}
