package ar.edu.unlam.pb2;

public class Pelicula {

	public String descripcion;
	public Integer duracion;

	public Pelicula(String descripcion, Integer duracion) {
		this.descripcion = descripcion;
		this.duracion = duracion;
	}

	String getDescripcion() {
		return descripcion;
	}

	void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	Integer getDuracion() {
		return duracion;
	}

	void setDuracion(Integer duracion) {
		this.duracion = duracion;
	}
	
	
}
