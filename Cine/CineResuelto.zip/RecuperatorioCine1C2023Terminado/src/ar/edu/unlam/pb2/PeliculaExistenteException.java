package ar.edu.unlam.pb2;

public class PeliculaExistenteException extends Exception {

}
