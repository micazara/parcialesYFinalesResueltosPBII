package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestSistema {

	@Test
	public void testQueRegistroUnBanco() throws NoSePudoAgregarElBanco {
		// vreo una vigilancia
		Vigilancia vigilancia = new Vigilancia("Nombre De la Compania de Vigilancia");

		// creo el banco que recibe una id y un nombre como atributos
		Integer idbanco = 1;
		Banco banco = new Banco(idbanco, "la Casa de Papel");
		// le agrego a la vigilancia el banco
		vigilancia.agregarBanco(banco);

		Integer idBancoAgregadoEsperado = 1;
		final Integer cantDeBancosAgregadosEsperada = 1;

		assertEquals(idBancoAgregadoEsperado, idbanco);
		assertEquals(cantDeBancosAgregadosEsperada, vigilancia.obtenerCantidadDeBancos());
	}

	@Test
	public void quePuedaRegistrarUnAtracador() throws PersonaDuplicadaException {

		// creo vigilancia
		Vigilancia vigilancia = new Vigilancia("Nombre De la Compania de Vigilancia");

		// creo banda
		Integer idbanda = 1;
		String nombre = "La Casa de Papel";
		Banda banda = new Banda(idbanda, nombre);

		// creo atracador que es un tipo de persona
		Integer dni = 1;
		String nombrePersona = "Ursula";
		String apellido = "Corbero";
		String apodo = "Tokio";

		// No Cambiar esta Linea
		Persona atracador = new Atracador(dni, nombrePersona, apellido, apodo, banda);
		// el atracador se registra en la vigilancia
		vigilancia.registrarPersona(atracador);

		Integer cantidadEsperadaDePersonasAgregadas = 1;
		Integer cantidadEsperadaDeAtracadoresAgregados = 1;

		// Compleatar el Assert
		assertEquals(cantidadEsperadaDePersonasAgregadas, vigilancia.obtenerCantidadDePersonasAgregadas());
		assertEquals(cantidadEsperadaDeAtracadoresAgregados, vigilancia.obtenerCantidadDeAtracadoresAgregados());

	}

	@Test(expected = PersonaDuplicadaException.class)
	public void queCuandoSeRegistre2PersonasConElMismoDNiLanceUnaExpcionPersonaDuplicadaException()
			throws PersonaDuplicadaException {
		// creo vigilancia
		Vigilancia vigilancia = new Vigilancia("Nombre De la Compania de Vigilancia");

		// Creo Vigilante
		Persona vigilante = new Vigilante(1, "Pepito", "Pistolero", new Banco(1, "LA Casa De Papel"));
		vigilancia.registrarPersona(vigilante);

		// Creo Banda
		Integer idBanda = 1;
		String nombre = "La Casa de Papel";
		Banda banda = new Banda(idBanda, nombre);

		// Creo Atracador
		Integer dni = 1;
		nombre = "Ursula";
		String apellido = "Corbero";
		String apodo = "Tokio";

		// No Cambiar esta Linea
		Persona atracador = new Atracador(dni, nombre, apellido, apodo, banda);
		vigilancia.registrarPersona(atracador);

	}

	@Test
	public void queSePuedaRegistraUnAtraco() throws PersonaDuplicadaException, NoSePudoAgregarElBanco,
			NoSeEncuentraAtracadorException, BancoNoEncontradoExcecption, ClaveInexistenteException {
// creo vigilancia
		Vigilancia vigilancia = new Vigilancia("Nombre De la Compania de Vigilancia");
		// creo banda
		Integer idBanda = 1;
		String nombre = "La Casa de Papel";
		Banda banda = new Banda(idBanda, nombre);
// creo atracador
		Integer dni = 1;
		nombre = "Ursula";
		String apellido = "Corbero";
		String apodo = "Tokio";
		// No Cambiar esta Linea
		Persona atracador = new Atracador(dni, nombre, apellido, apodo, banda);
		// registro atracador
		vigilancia.registrarPersona(atracador);
// creo banco
		Integer idBanco = 1;
		Banco banco = new Banco(idBanco, "la Casa de Papel");
		// registro banco
		vigilancia.agregarBanco(banco);

		vigilancia.registrarAtraco(dni, idBanco);
		Integer valorEsperado = 1;

		Integer claveAtraco = 1;
		Atraco atraco = vigilancia.buscarAtracoPorClave(claveAtraco);

		Banco bancoEsperado = new Banco(idBanco, "la Casa de Papel");

		// No cambiar
		assertTrue(bancoEsperado.equals(atraco.getBanco()));

	}

	// inicialmente no se quiere ordenar los atracadores. Este orden surge apartir
	// de una necesidad en concreto por lo que no es el orden natural.
	@Test
	public void queSePuedaObtenerLosAtracadoresOrdenadosPorApodos() throws PersonaDuplicadaException {

		// necesito una vigilancia
		Vigilancia vigilancia = new Vigilancia("Nombre De la Compania de Vigilancia");

		// necesito banda
		Integer idBanda = 1;
		String nombre = "La Casa de Papel";
		Banda banda = new Banda(idBanda, nombre);

		// necesito atracores
		// atracador 1
		Persona atracador1 = new Atracador(1, "Ursula", "Corbero", "Tokio", banda);

		// atracador 2
		Persona atracador2 = new Atracador(2, "Micaela", "Zara", "Miku", banda);

		// atracador 3
		Persona atracador3 = new Atracador(3, "Copito", "Zara Sepulveda", "Copi", banda);

		// necesito agregar los atracadores a la vigilancia
		vigilancia.registrarPersona(atracador1);
		vigilancia.registrarPersona(atracador2);
		vigilancia.registrarPersona(atracador3);

		// 1) Copi, 2) Miku, 3) Tokio
		assertEquals(atracador3, vigilancia.obtenerAtracadoresOrdenados(new OrdenPorApodos()).first());
		assertEquals(atracador1, vigilancia.obtenerAtracadoresOrdenados(new OrdenPorApodos()).last());

	}

//Cree un 3 test a su eleccion para que pruebe el resto de las funcionalidades
	@Test
	public void queSePuedaObtenerLasPersonasOrdenadasPorDNIDescendente() throws PersonaDuplicadaException {

		// necesito una vigilancia
		Vigilancia vigilancia = new Vigilancia("Nombre De la Compania de Vigilancia");

		// necesito banda
		Integer idBanda = 1;
		String nombre = "La Casa de Papel";
		Banda banda = new Banda(idBanda, nombre);

		// necesito personas
		Persona atracador1 = new Atracador(26231502, "Ursula", "Corbero", "Tokio", banda);
		Persona atracador2 = new Atracador(44892966, "Micaela", "Zara", "Miku", banda);
		Persona atracador3 = new Atracador(78231523, "Copito", "Zara Sepulveda", "Copi", banda);
		Persona vigilante1 = new Vigilante(48231236, "Pepito", "Pistolero", new Banco(1, "LA Casa De Papel"));
		Persona vigilante2 = new Vigilante(56482367, "Dalas", "Puto", new Banco(1, "LA Casa De Papel"));

		// necesito agregar todas las personas a la vigilancia
		vigilancia.registrarPersona(atracador1);
		vigilancia.registrarPersona(atracador2);
		vigilancia.registrarPersona(atracador3);
		vigilancia.registrarPersona(vigilante1);
		vigilancia.registrarPersona(vigilante2);

		// ahora tengo que ordenarlas por dni descendente
		assertEquals(atracador1, vigilancia.obtenerPersonasOrdenadasPorDNIDescendente().last());
		assertEquals(atracador3, vigilancia.obtenerPersonasOrdenadasPorDNIDescendente().first());

	}

	@Test
	public void queSePuedaBuscarUnaPersonaPorNombre() throws PersonaDuplicadaException, NoSePudoEncontrarLaPersona {
		// necesito una vigilancia
		Vigilancia vigilancia = new Vigilancia("Nombre De la Compania de Vigilancia");

		// necesito banda
		Integer idBanda = 1;
		String nombre = "La Casa de Papel";
		Banda banda = new Banda(idBanda, nombre);

		// personas
		Persona atracador1 = new Atracador(26231502, "Ursula", "Corbero", "Tokio", banda);
		Persona atracador2 = new Atracador(44892966, "Micaela", "Zara", "Miku", banda);

// agrego personas a la vigilancia
		vigilancia.registrarPersona(atracador1);
		vigilancia.registrarPersona(atracador2);
		
		assertEquals(atracador2, vigilancia.buscarPersonaPorNombre("Micaela"));
	}
//	
//	@Test
//	private void testSignificativo3() {
//		
//	}
//	

}
