package ar.edu.unlam.pb2;

import java.util.Comparator;

public class OrdenPorDniDescendente implements Comparator<Persona> {

	@Override
	public int compare(Persona o1, Persona o2) {
		return o2.getDni().compareTo(o1.getDni());
	}

}
