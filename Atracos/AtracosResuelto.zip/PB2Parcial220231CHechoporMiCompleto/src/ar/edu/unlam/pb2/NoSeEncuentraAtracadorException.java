package ar.edu.unlam.pb2;

public class NoSeEncuentraAtracadorException extends Exception {

}
