package ar.edu.unlam.pb2;

public class Atracador extends Persona {

	private String apodo;
	private Banda banda;

	public Atracador(Integer dni, String nombre, String apellido, String apodo, Banda banda) {
		super(dni, nombre, apellido);
		this.apodo = apodo;
		this.banda = banda;
	}

	String getApodo() {
		return apodo;
	}

	void setApodo(String apodo) {
		this.apodo = apodo;
	}

	Banda getBanda() {
		return banda;
	}

	void setBanda(Banda banda) {
		this.banda = banda;
	}

	@Override
	public String toString() {
		return "Atracador [apodo=" + apodo + ", banda=" + banda + ", dni=" + dni + ", nombre=" + nombre + ", apellido="
				+ apellido + "]";
	}

}
