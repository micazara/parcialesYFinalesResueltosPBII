package ar.edu.unlam.pb2;

public class Banda {

	public Banda(Integer idbanda, String nombre) {

		

	}

}
