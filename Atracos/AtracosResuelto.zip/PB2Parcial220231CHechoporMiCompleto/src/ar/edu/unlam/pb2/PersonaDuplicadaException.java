package ar.edu.unlam.pb2;

public class PersonaDuplicadaException extends Exception {

}
