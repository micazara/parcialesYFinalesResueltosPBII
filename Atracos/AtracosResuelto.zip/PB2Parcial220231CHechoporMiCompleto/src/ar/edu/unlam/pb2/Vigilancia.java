package ar.edu.unlam.pb2;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Vigilancia {

	private String nombre;

	// Colocar el tipo de coleccion que corresponda
	private Set<Persona> personas;
	// Colocar el tipo de coleccion que corresponda
	private Set<Banco> bancos;
	// No se puede cambiar
	private Map<Integer, Atraco> atracos;

	public Vigilancia(String nombre) {
		this.nombre = nombre;
		this.personas = new HashSet<Persona>();
		this.bancos = new HashSet<Banco>();
		this.atracos = new HashMap<Integer, Atraco>();
	}

	public void agregarBanco(Banco banco) throws NoSePudoAgregarElBanco {

		if (!this.bancos.add(banco)) {
			throw new NoSePudoAgregarElBanco();
		}

		;

	}

	/*
	 * Registra tanto como Vigiladores como atracadores. No permite registrar 2
	 * personas con el mismo DNI. Si esto sucede lanza una exception
	 * PersonaDuplicadaException
	 * 
	 */
	public void registrarPersona(Persona nueva) throws PersonaDuplicadaException {
		if (!this.personas.add(nueva)) {
			throw new PersonaDuplicadaException();
		}

	}

	public Integer obtenerCantidadDeBancos() {
		return this.bancos.size();
	}

	public Integer obtenerCantidadDePersonasAgregadas() {
		return this.personas.size();
	}

	public Integer obtenerCantidadDeAtracadoresAgregados() {
		Integer cantidadDeAtracadores = 0;
		for (Persona actual : this.personas) {
			if (actual instanceof Atracador) {
				cantidadDeAtracadores++;
			}
		}

		return cantidadDeAtracadores;
	}

	/*
	 * Este Metodo lanza las siguientes Excepciones NoSeEncuentraAtracadorException
	 * BancoNoEncontradoExcecption
	 * 
	 */

	public void registrarAtraco(Integer dniAtracador, Integer idBanco)
			throws NoSeEncuentraAtracadorException, BancoNoEncontradoExcecption {
// 1) busco un atracador y un banco que existan en la vigilancia, es decir, que se hayan registrado
		Atracador atracador = buscarAtracadorPorDNI(dniAtracador);
		Banco banco = buscarBanco(idBanco);

// 2) a partir de los que se encontraron, creo el atraco
		Atraco atraco = new Atraco(atracador, banco);

// 3) Se debe agregar un atraco al Mapa a partir del atraco que se creo

		Integer claveAtraco = 1;
		this.atracos.put(claveAtraco, atraco);
		claveAtraco++;
	}

	// Si la clave no existe lanza ClaveInexistenteException
	public Atraco buscarAtracoPorClave(Integer claveAtraco) throws ClaveInexistenteException {
		// a partir de la clave de una atraco (su key) quiere obtener un atraco (value)

		Atraco encontrado = this.atracos.get(claveAtraco);

		if (encontrado == null) {
			throw new ClaveInexistenteException();
		}

		return encontrado;
	}

//
//	public Vigilante obtenerElVigiladorDeUnAtraco(Integer claveAtraco) {
//
//		Vigilante vigilante;
//
//		return vigilante;
//
//	}
//
	public TreeSet<Atracador> obtenerAtracadoresOrdenados(OrdenPorApodos ordenPorApodo) {
// hasta aca esta vacio, solo sabe ordenar
		TreeSet<Atracador> atracadoresOrdenadados = new TreeSet<Atracador>(ordenPorApodo);

		// hashset que va a guardar los atracadores desordenados

		HashSet<Atracador> atracadoresDesordenados = new HashSet<Atracador>();

		for (Persona actual : this.personas) {
			if (actual instanceof Atracador) {
				atracadoresDesordenados.add((Atracador) actual);
			}
		}
		atracadoresOrdenadados.addAll(atracadoresDesordenados);

//		mostrarAtracadoresOrdenados(atracadoresOrdenadados);

		return atracadoresOrdenadados;
	}

	private void mostrarAtracadoresOrdenados(TreeSet<Atracador> atracadoresOrdenadados) {
		for (Atracador actual : atracadoresOrdenadados) {
			System.out.println(actual.toString());
		}
	}

	private Banco buscarBanco(Integer idBanco) throws BancoNoEncontradoExcecption {
		for (Banco actual : bancos) {
			if (actual.getIdBanco().equals(idBanco)) {
				return actual;
			}
		}
		throw new BancoNoEncontradoExcecption();
	}

	private Atracador buscarAtracadorPorDNI(Integer dniAtracador) throws NoSeEncuentraAtracadorException {

		for (Persona actual : this.personas) {
			if (actual.getDni().equals(dniAtracador) && actual instanceof Atracador) {
				return (Atracador) actual;
			}
		}
		throw new NoSeEncuentraAtracadorException();
	}

	public TreeSet<Persona> obtenerPersonasOrdenadasPorDNIDescendente() {

		// a partir de mi hashset original de personas, tengo que crear un treeset que
		// sea capaz de ordenar por dni y llenarlo de todas las personas que tengo en el
		// hashset.

		TreeSet<Persona> personasOrdenadas = new TreeSet<Persona>(new OrdenPorDniDescendente());

		personasOrdenadas.addAll(this.personas);

//		mostrarPersonasOrdenadas(personasOrdenadas);

		return personasOrdenadas;

	}

	private void mostrarPersonasOrdenadas(TreeSet<Persona> personasOrdenadas) {
		for (Persona actual : personasOrdenadas) {
			System.out.println(actual.toString());
		}
	}

	public Persona buscarPersonaPorNombre(String nombreParaBuscar) throws NoSePudoEncontrarLaPersona {
		// recorro en donde tengo todas las personas
		for (Persona actual : this.personas) {
			if (actual.getNombre().equals(nombreParaBuscar)) {
				return actual;
			}
		}

		throw new NoSePudoEncontrarLaPersona();

	}

}
