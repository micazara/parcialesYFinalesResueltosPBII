package ar.edu.unlam.pb2;

public class NoSePudoEncontrarLaPersona extends Exception {

}
