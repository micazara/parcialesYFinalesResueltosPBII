package ar.edu.unlam.pb2;

public class NoSePudoAgregarElBanco extends Exception {

}
